SONG 131: "From Beginning to End"

Canción 131: Del Principio al Fin

[Intro]

[Verse 1]
Del Edén al Calvario la historia se cuenta,
De la caída a la cruz, la promesa se presenta,
Adán cayó pero Cristo levantó,
Lo que el primero perdió, el segundo restauró.

[Verse 2]
Del árbol prohibido al árbol de la cruz,
De la oscuridad de la cueva a la gloriosa luz,
De la maldición de la serpiente a la victoria final,
Cristo aplastó su cabeza, el triunfo eternal.

[Chorus]
Del principio al fin, Dios tenía un plan,
Redimir a Su pueblo, desde Adán a Abraham,
De Moisés a David, de profetas al Rey,
¡Todo apunta a Cristo, nuestra vida y ley!

[Bridge]
El Paraíso perdido será restaurado,
El árbol de vida abierto, pecado perdonado,
La naturaleza brillante regresará,
Cuando Cristo venga y todo renovará.

[Verse 3]
La Cueva de Tesoros ahora brilla,
Porque Cristo es el tesoro, luz que maravilla,
Lo que Adán y Eva perdieron en aquel día,
Cristo lo devuelve con creces, alegría.

[Outro]
Del principio al fin... Cristo es la respuesta...
Alpha y Omega... el Primero y el Último...
