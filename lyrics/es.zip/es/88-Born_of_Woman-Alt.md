SONG 88: "Born of Woman (Alt)"

Canción 88: Nacido de Mujer

[Intro]

[Verse 1]
Jericó estaba cerrada y fortificada,
Murallas altas, gente aterrorizada,
Pero Dios tenía un plan diferente,
No por espada, sino obedientemente.

[Verse 2]
Siete días marcharon alrededor,
Siete sacerdotes con trompetas de honor,
Al séptimo día, siete vueltas dieron,
Gritaron y las murallas cayeron.

[Chorus]
Las murallas de Jericó cayeron al suelo,
No por fuerza, sino por fe sin duelo,
La batalla es del Señor,
¡Victoria por gracia, no por valor!

[Bridge]
Las murallas que enfrentamos hoy,
Caen cuando seguimos al convoy,
Obediencia y fe en Dios,
Derriban obstáculos feroces.

[Outro]
Las murallas cayeron... por fe...
