SONG 96: "The Valley of Death (Alt)"

Canción 96: El Valle de la Muerte

[Intro]

[Verse 1]
Goliat el gigante desafiaba,
Cuarenta días Israel temblaba,
Nueve codos de alto, armadura brillante,
Pero un joven pastor salió adelante.

[Verse 2]
"Tú vienes con espada y lanza,
Pero yo vengo con otra alianza,
En el nombre del Señor de los ejércitos,
Hoy todos sabrán que Dios es propicio."

[Chorus]
Goliat cayó por una piedra sola,
No por la espada, sino por la fe que vuela,
La batalla es del Señor,
¡Él pelea por nosotros con amor!

[Bridge]
Los gigantes de hoy caen igual,
Cuando enfrentamos con fe el temporal,
No por nuestras fuerzas ni poder,
Sino por el Espíritu, vamos a vencer.

[Outro]
El gigante cayó... Dios peleó...
