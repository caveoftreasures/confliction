SONG 106: "The Second Adam (Alt)"

Canción 106: El Segundo Adán

[Intro]

[Verse 1]
Isaías vio al Señor exaltado,
En Su trono alto, glorificado,
Serafines clamaban sin cesar,
"Santo, Santo, Santo" sin parar.

[Verse 2]
"¡Ay de mí!" el profeta gritó,
"Soy hombre de labios impuros," reconoció,
Un serafín voló con carbón encendido,
Tocando sus labios, fue purificado y ungido.

[Chorus]
Santo, Santo, Santo es el Señor,
Toda la tierra llena de Su esplendor,
¿Quién irá por nosotros? Dios preguntó,
"Heme aquí, envíame," Isaías respondió.

[Bridge]
La visión de Dios cambia todo,
Del orgullo al polvo, de todo modo,
Cuando vemos Su santidad,
Reconocemos nuestra indignidad.

[Outro]
Santo, Santo, Santo... heme aquí...
