SONG 50: "Cain and Abel (Alt)"

Canción 50: Caín y Abel

[Intro]

[Verse 1]
Madera de gofer, trescientos codos de largo,
Noé construyó el arca grande y fuerte,
Cincuenta codos de ancho, treinta de alto,
Una ventana arriba y una puerta a un lado.

[Verse 2]
Año tras año el martillo sonó,
Mientras Noé predicaba la canción de Dios,
"Arrepiéntanse," clamó, "el juicio viene,"
Pero ellos se rieron y siguieron huyendo.

[Chorus]
Construyendo el arca con fe y con oración,
Aunque nadie parecía que le importara,
Noé obedeció la palabra de Dios,
¡El mensaje más importante que él había escuchado!

[Bridge]
La fe construye cuando otros dudan,
La fe trabaja sin gritar,
Noé nos muestra lo que significa,
Obedecer a Dios aunque nadie lo crea.

[Outro]
Construyendo el arca... preparando el camino...
