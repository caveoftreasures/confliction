SONG 86: "The Midnight Cry (Alt)"

Canción 86: El Grito de Medianoche

[Intro]

[Verse 1]
Cuarenta años en el desierto pasaron,
La generación vieja se marchó,
Josué guió al pueblo adelante,
El Jordán por cruzar, río gigante.

[Verse 2]
Los sacerdotes con el arca entraron,
Las aguas se detuvieron, se pararon,
Israel cruzó en tierra seca,
A la tierra prometida, cosecha.

[Chorus]
Cruzando el Jordán a tierra nueva,
De la esclavitud a la promesa prueba,
Dios cumple lo que prometió,
¡La herencia que a Abraham juró!

[Bridge]
Doce piedras del río sacaron,
Memorial del cruce que recordaron,
Para que las generaciones sepan,
Que Dios obra maravillas que pasean.

[Outro]
Cruzando a la promesa... la herencia recibida...
