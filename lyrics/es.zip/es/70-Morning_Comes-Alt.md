SONG 70: "Morning Comes (Alt)"

Canción 70: Llega la Mañana

[Intro]

[Verse 1]
Moisés pastoreaba ovejas en Madián,
Cuando vio un arbusto en llamas sin afán,
Ardía pero no se consumía,
La voz de Dios desde allí surgía.

[Verse 2]
"Quita tus sandalias de tus pies,
El lugar es santo," dijo el Rey,
"Yo soy el Dios de tus padres,
He oído el clamor de sus almas madres."

[Chorus]
La zarza ardiente llamó a Moisés,
"Ve a Faraón," el mandato fue,
"Deja ir a mi pueblo ahora,
¡Yo estaré contigo cada hora!"

[Bridge]
"YO SOY EL QUE SOY," Dios declaró,
El nombre eterno que reveló,
Pasado, presente y futuro en Él,
El Dios de Abraham, siempre fiel.

[Outro]
La zarza ardía... Dios hablaba...
