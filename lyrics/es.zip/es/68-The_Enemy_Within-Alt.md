SONG 68: "The Enemy Within (Alt)"

Canción 68: El Enemigo Interior

[Intro]

[Verse 1]
Faraón ordenó matar a los niños,
Pero una madre escondió a su pequeño,
En una canasta de juncos lo puso,
En el Nilo flotando, Dios dispuso.

[Verse 2]
La hija de Faraón lo encontró llorando,
"Un niño hebreo," dijo observando,
Miriam su hermana apareció,
"¿Traigo una nodriza?" y corrió.

[Chorus]
Moisés en la canasta, salvado de la muerte,
Criado en el palacio con mucha suerte,
Pero Dios tenía un plan mayor,
¡Libertador de Su pueblo, con honor!

[Bridge]
De la canasta al palacio real,
Del palacio al desierto celestial,
Dios preparó a Su siervo así,
Para liberar a Israel de allí.

[Outro]
La canasta flotó... el libertador nació...
