SONG 118: "The Burning of Sin (Alt)"

Canción 118: La Quema del Pecado

[Intro]

[Verse 1]
Cuatrocientos años sin palabra de Dios,
El silencio entre los testamentos, atroz,
Malaquías fue el último en hablar,
"Elías vendrá antes de ese día llegar."

[Verse 2]
Pero el silencio no significa olvido,
Dios estaba preparando lo prometido,
Los reinos subían y caían,
Mientras el tiempo del Mesías se acercaba.

[Chorus]
El silencio se rompe en Belén,
Con un llanto de bebé en el pesebre también,
Los ángeles cantan, los pastores vienen,
¡El Verbo se hizo carne, todos los que creen!

[Bridge]
De Malaquías a Mateo el tiempo pasó,
Pero la promesa de Dios no se olvidó,
En el momento justo, en el tiempo perfecto,
Dios envió a Su Hijo, el proyecto.

[Outro]
El silencio se rompe... el Salvador nació...
