SONG 23: "The Sun and the Moon"

Canción 23: El Sol y la Luna

[Intro]

[Verse 1]
Tres varas de oro del jardín,
Incienso, mirra, tesoros del Rey,
Traídas por el ángel a la cueva,
Señales de la promesa que Dios nos dio.

[Verse 2]
Oro para la realeza del que vendría,
Incienso para Su divinidad,
Mirra para Su muerte y sepultura,
Símbolos del plan de Dios, puro y verdadero.

[Chorus]
Varas de oro brillando en la oscuridad,
Promesas de esperanza en cada marca,
Del jardín a la cueva vinieron,
¡Recordándonos que Dios siempre está!

[Bridge]
Estos dones un día serían dados,
Al niño nacido para salvarnos,
Reyes magos vendrían desde lejos,
Siguiendo Su brillante estrella.

[Outro]
Oro, incienso y mirra... dones para el Rey...
