SONG 107: "The Long Road Home"

Canción 107: El Largo Camino a Casa

[Intro]

[Verse 1]
Isaías escribió de uno que vendría,
Despreciado, rechazado, nadie lo quería,
Varón de dolores, experimentado en quebranto,
Herido por nuestros pecados, manto santo.

[Verse 2]
Como oveja al matadero fue llevado,
En silencio, sin abrir su boca, maltratado,
Molido por nuestras rebeliones fue,
Por Sus llagas fuimos curados, nuestra fe.

[Chorus]
El Siervo Sufriente murió por nosotros,
Llevando nuestros pecados y dolores,
Lo que merecíamos Él llevó,
¡Por Su sacrificio somos salvados, nos amó!

[Bridge]
Setecientos años antes escrito está,
La muerte de Cristo que nos salvará,
Cada detalle cumplido con precisión,
El plan de Dios, nuestra redención.

[Outro]
Por Sus llagas... somos sanados...
