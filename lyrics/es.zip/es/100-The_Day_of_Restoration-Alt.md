SONG 100: "The Day of Restoration (Alt)"

Canción 100: El Día de la Restauración

[Intro]

[Verse 1]
Salomón pidió sabiduría a Dios,
No riquezas ni fama, sino luz,
Dios le dio más de lo pedido,
Sabiduría, riqueza, honor sin olvido.

[Verse 2]
Juzgó con justicia casos difíciles,
Construyó el templo con manos hábiles,
Reyes y reinas venían a escuchar,
La sabiduría que Dios quiso dar.

[Chorus]
La sabiduría de Salomón brilló,
Pero uno mayor que Salomón llegó,
Cristo la sabiduría de Dios en persona,
¡En Él todo conocimiento se corona!

[Bridge]
El temor del Señor es el principio,
De la sabiduría, santo inicio,
Busca a Cristo, encuentra verdad,
Sabiduría eterna, inmensidad.

[Outro]
Sabiduría de lo alto... Cristo es la respuesta...
