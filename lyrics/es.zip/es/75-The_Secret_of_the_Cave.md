SONG 75: "The Secret of the Cave"

Canción 75: El Secreto de la Cueva

[Intro]

[Verse 1]
Israel llegó al Mar Rojo atrapado,
Faraón los seguía con su ejército armado,
Montañas a los lados, mar adelante,
"¿Para morir nos trajiste?" dijeron bastante.

[Verse 2]
Moisés extendió su vara sobre el mar,
Dios dividió las aguas sin cesar,
Paredes de agua a izquierda y derecha,
Israel pasó en tierra hecha.

[Chorus]
Cruzando el Mar Rojo en tierra seca,
El poder de Dios ninguno lo replica,
Faraón los siguió a su perdición,
¡Las aguas cerraron, fin de su invasión!

[Bridge]
Cuando no hay camino, Dios abre uno,
Cuando todo falla, Él es oportuno,
El mar que tememos se vuelve nuestro paso,
¡Victoria en Dios, no hay fracaso!

[Outro]
El mar se abrió... Israel pasó...
