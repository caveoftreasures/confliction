SONG 93: "The Great Exchange"

Canción 93: El Gran Intercambio

[Intro]

[Verse 1]
El menor de los hijos de Isaí,
Pastoreaba ovejas solo allí,
Pero Dios no mira la apariencia,
Sino el corazón con reverencia.

[Verse 2]
Samuel vino a ungir un rey,
Los hermanos pasaron, no era su ley,
"¿No hay otro?" el profeta preguntó,
"El menor," dijeron, y David llegó.

[Chorus]
David el pastor, ungido rey,
Un hombre conforme al corazón de Dios fue ley,
De cuidar ovejas a cuidar naciones,
¡Dios prepara en todas las condiciones!

[Bridge]
El pastor se convierte en rey,
Señalando a Cristo, la eterna grey,
El Buen Pastor que da Su vida,
Por Sus ovejas, amor sin medida.

[Outro]
El pastor ungido... el rey escogido...
