SONG 21: "Eves Lament"

Canción 21: El Lamento de Eva

[Intro]

[Verse 1]
Dios hizo un pacto con Adán ese día,
Una promesa de salvación en el camino,
Cinco mil años hasta que llegue el Salvador,
Para rescatar a la humanidad de la tumba.

[Verse 2]
"Te enviaré Mi Palabra," dijo Dios,
"Para salvarte del pecado y la muerte,
Confía en Mí aunque el camino sea largo,
Mi amor por ti siempre será fuerte."

[Chorus]
El pacto de Dios permanece firme y verdadero,
Lo que Él promete, Él lo cumplirá,
De generación en generación,
¡Su fidelidad nunca fallará!

[Bridge]
Sellado con la Palabra, sellado con amor,
Prometido por el Dios del cielo arriba,
Ningún poder del infierno puede romper,
Este pacto que Dios hizo por nosotros.

[Outro]
El pacto permanece... hasta el fin de los tiempos...
