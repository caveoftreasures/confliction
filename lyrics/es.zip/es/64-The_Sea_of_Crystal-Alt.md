SONG 64: "The Sea of Crystal (Alt)"

Canción 64: El Mar de Cristal

[Intro]

[Verse 1]
Jacob durmió con piedra por almohada,
Huyendo de Esaú sin ninguna hazaña,
En sueños vio una escalera al cielo,
Ángeles subiendo, bajando sin recelo.

[Verse 2]
Arriba estaba el Señor de toda gloria,
"Yo soy el Dios de Abraham," cuenta la historia,
"La tierra donde duermes te la daré,
Y en tu semilla las naciones bendeciré."

[Chorus]
La escalera de Jacob toca el cielo,
Conectando la tierra con Dios sin velo,
Cristo es esa escalera hoy,
¡El camino al Padre, nuestro convoy!

[Bridge]
"Betel," llamó a ese lugar santo,
La casa de Dios, refugio y manto,
La puerta del cielo se abrió esa noche,
Para Jacob el fugitivo, dulce broche.

[Outro]
La escalera al cielo... Cristo es el camino...
