SONG 1: "Cast Out of Paradise"

Canción 01: Expulsados del Paraíso

[Intro]

[Verse 1]
Jardín del Edén, tercer día plantado,
Al este del mundo donde el sol se levanta,
Agua lo rodea, pura y santa,
Frontera del cielo, jardín de Dios.

[Verse 2]
Adán fue formado del polvo y gloria,
Naturaleza brillante, imagen del cielo,
Caminando con ángeles, siempre alabando,
Sin noche ni día, solo luz infinita.

[Chorus]
¡Expulsados del Paraíso, caídos de la gracia,
Naturaleza brillante quitada, no vemos la faz de Dios,
Del jardín a la cueva, de la gloria al polvo,
Pero Dios hizo una promesa en la que aprendimos a confiar!

[Bridge]
Cinco días y medio la profecía contó,
Cinco mil años antes de que la verdad se revele,
Un salvador vendría a restaurar lo perdido,
A pagar por su pecado al precio más alto.

[Outro]
Paraíso perdido... pero no para siempre...
