SONG 82: "The Word Made Flesh (Alt)"

Canción 82: El Verbo Hecho Carne

[Intro]

[Verse 1]
Dios ordenó construir un tabernáculo,
Un lugar santo, un receptáculo,
Para que Él morara entre Su pueblo,
Su gloria llenando todo el suelo.

[Verse 2]
Cortinas de lino fino y azul,
Púrpura y carmesí, luz y tul,
El arca del pacto en el lugar santísimo,
Donde Dios habitaba, santísimo.

[Chorus]
El tabernáculo, morada de Dios,
Un anticipo del Emmanuel con nos,
Dios con nosotros quiere estar,
¡En nuestros corazones quiere morar!

[Bridge]
Cada detalle apuntaba a Cristo,
El velo, el altar, todo visto,
El camino al Padre ahora abierto,
Por la sangre de Jesús, cierto.

[Outro]
La morada de Dios... entre nosotros...
