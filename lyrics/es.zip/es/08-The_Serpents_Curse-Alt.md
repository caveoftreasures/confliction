SONG 8: "The Serpents Curse (Alt)"

Canción 08: La Maldición de la Serpiente

[Intro]

[Verse 1]
La serpiente era la más hermosa de todas,
Exaltada entre las bestias, alta y orgullosa,
Pero cuando Satanás eligió su forma,
La maldición de Dios cayó como una tormenta.

[Verse 2]
De caminar erguida a arrastrarse en el polvo,
De la belleza a la fealdad y el asco,
Maldita a comer el polvo de la tierra,
La más baja de las criaturas desde el nacimiento.

[Chorus]
La serpiente maldita, condenada a reptar,
Por traer la mentira que hizo caer a la humanidad,
Ojos rojos como sangre, llenos de odio,
Un recordatorio del engaño de Satanás.

[Bridge]
La cabeza de la serpiente será aplastada,
Un día la victoria será anunciada,
La semilla de la mujer pisará,
Al enemigo bajo sus pies.

[Outro]
Maldita pero no para siempre... viene la redención...
