SONG 113: "Gods Faithfulness"

Canción 113: La Fidelidad de Dios

[Intro]

[Verse 1]
Gabriel vino a Daniel con un mensaje,
Setenta semanas para tu linaje,
Para terminar la transgresión,
Expiar el pecado, traer bendición.

[Verse 2]
Siete semanas y sesenta y dos,
Hasta el Mesías Príncipe de los dos,
Después de esto sería quitado,
No por sí mismo, sino sacrificado.

[Chorus]
Las setenta semanas de Daniel,
El tiempo exacto para Emmanuel,
Dios marcó el día y la hora,
¡Cuando el Salvador llegó a Su morada ahora!

[Bridge]
La profecía se cumplió al pie de la letra,
Cristo vino cuando el tiempo era,
No un día antes, no un día después,
Dios es preciso en Su acontecer.

[Outro]
Setenta semanas... el Mesías viene...
