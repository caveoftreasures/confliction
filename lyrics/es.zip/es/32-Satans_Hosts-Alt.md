SONG 32: "Satans Hosts (Alt)"

Canción 32: Los Ejércitos de Satanás

[Intro]

[Verse 1]
Del cielo Satanás una vez cayó,
El ángel rebelde, orgulloso y alto,
Lucifer la estrella de la mañana brilló,
Hasta que el orgullo lo cegó.

[Verse 2]
Otra vez él cae cada vez que falla,
Sus mentiras y engaños no prevalecen,
Dios lo derriba una y otra vez,
El enemigo derrotado hasta el fin.

[Chorus]
Satanás cae otra vez y otra vez,
Cada plan aplastado, cada esquema termina,
El poder de Dios es siempre mayor,
¡La victoria es del Creador!

[Bridge]
Del cielo a la tierra, al abismo él irá,
Derrotado por Cristo, el golpe final,
Encadenado en oscuridad eternamente,
El enemigo vencido, nunca libre.

[Outro]
Cayendo... siempre cayendo...
