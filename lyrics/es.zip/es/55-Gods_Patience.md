SONG 55: "Gods Patience"

Canción 55: La Paciencia de Dios

[Intro]

[Verse 1]
Después del diluvio el sol brilló,
Un arcoíris apareció, señal divina,
Los colores pintaron el cielo de esperanza,
La promesa de Dios para toda la tierra.

[Verse 2]
"Nunca más destruiré con agua," dijo,
"Este arcoíris es mi pacto sellado,
Cuando las nubes aparezcan en el cielo,
El arcoíris recordará mi alianza aquí."

[Chorus]
El pacto del arcoíris brilla arriba,
Un recordatorio del fiel amor de Dios,
Las tormentas pueden venir, las lluvias pueden caer,
¡Pero Dios cumple Sus promesas a todos!

[Bridge]
Cada color cuenta una historia,
De la misericordia de Dios y Su gloria,
Cuando vemos el arcoíris en el cielo,
Recordamos que Dios está siempre aquí.

[Outro]
El arcoíris brilla... la promesa permanece...
