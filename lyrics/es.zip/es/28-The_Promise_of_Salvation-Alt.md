SONG 28: "The Promise of Salvation (Alt)"

Canción 28: La Promesa de Salvación

[Intro]

[Verse 1]
Dios mató bestias para vestir su vergüenza,
El primer derramamiento de sangre, ¿quién llevará la culpa?
El pecado requiere la muerte de lo inocente,
Un principio establecido, santo y reticente.

[Verse 2]
Pieles de animales para cubrir su piel,
Un símbolo de lo que sucedería,
El Cordero sin mancha moriría un día,
Para quitar nuestros pecados para siempre.

[Chorus]
Pieles de bestias, la primera ofrenda,
Sangre derramada, vida dando,
Dios los cubrió con Su amor,
¡Un regalo de gracia desde arriba!

[Bridge]
De Edén a la cruz la línea se traza,
Sangre inocente, todo por gracia,
Los animales murieron para que ellos vivieran,
Cristo murió, perdón para dar.

[Outro]
Cubiertos por sangre... salvados por gracia...
