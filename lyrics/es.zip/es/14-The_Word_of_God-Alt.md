SONG 14: "The Word of God (Alt)"

Canción 14: La Palabra de Dios

[Intro]

[Verse 1]
Cuando cayeron ante la puerta,
Aterrorizados por su nuevo estado,
Dios envió Su Palabra para levantarlos,
No dejaría morir a Sus hijos.

[Verse 2]
"Ordené en la tierra," dijo Dios,
"Días y años hasta tu muerte,
Camina en ella hasta que el tiempo termine,
Hasta que envíe a Mi Prometido."

[Chorus]
¡La Palabra de Dios descendió a mí,
Me levantó y me hizo libre,
La misma Palabra que creó todo,
Vino a salvarme de mi caída!

[Bridge]
Esa Palabra un día tomaría carne,
Haría nuevas todas las cosas rotas,
La promesa susurrada desde el inicio,
Sanaría cada corazón roto.

[Outro]
La Palabra se hizo carne... y habitó con nosotros...
