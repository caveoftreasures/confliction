SONG 40: "The Garden Remembered (Alt)"

Canción 40: El Jardín Recordado

[Intro]

[Verse 1]
Seth nació para tomar el lugar de Abel,
Otra oportunidad, otro hijo de gracia,
A través de su línea vendría la promesa,
El Salvador nacería, santo y libre.

[Verse 2]
Seth caminó en los caminos de su padre,
Enseñando a sus hijos a dar alabanza a Dios,
Una línea justa a través del tiempo,
Llevando la promesa, sublime.

[Chorus]
Seth el elegido, la semilla de esperanza,
A través de su línea aprendemos a afrontar,
De Adán a Noé la historia va,
¡La fidelidad de Dios siempre fluye!

[Bridge]
Cuando todo parecía perdido y hecho,
Dios levantó otro hijo,
La promesa continuó fuerte,
El plan de Dios nunca puede salir mal.

[Outro]
La semilla elegida... la promesa continúa...
