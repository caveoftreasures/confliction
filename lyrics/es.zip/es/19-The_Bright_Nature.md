SONG 19: "The Bright Nature"

Canción 19: La Naturaleza Brillante

[Intro]

[Verse 1]
Una vez vestimos un manto de luz,
Brillando puro, siempre radiante,
Ninguna oscuridad tocó nuestro marco santo,
Caminamos en la llama eterna de Dios.

[Verse 2]
Ojos podían ver lo que ángeles veían,
Gloria celestial, sin defecto alguno,
Alabando a Dios día y noche,
En la perfecta manera de esa naturaleza brillante.

[Chorus]
Perdimos nuestra naturaleza brillante en la caída,
Cambiamos gloria por un llamado mortal,
¡Pero Dios nos vestirá otra vez,
En vestiduras de luz al final del viaje!

[Bridge]
Ese mar de cristal, puro y claro,
Donde la justicia perseverará,
Bañándonos en su flujo santo,
Volviendo a la vida que solíamos conocer.

[Outro]
La naturaleza brillante regresa... cuando el Salvador viene...
