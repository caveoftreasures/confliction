SONG 127: "The Overcoming"

Canción 127: La Victoria

[Intro]

[Verse 1]
En el Calvario mi Salvador murió,
Clavado en la cruz, Su vida dio,
Por mis pecados Él sufrió allí,
El justo por los injustos, por ti y por mí.

[Verse 2]
"Padre, perdónalos," Él oró,
"No saben lo que hacen," declaró,
En medio de Su agonía más profunda,
Amor sin límites, gracia que abunda.

[Chorus]
La cruz, la cruz donde Cristo murió,
El lugar donde mi vida cambió,
De muerte a vida, de oscuridad a luz,
¡Todo por la gracia de Jesús!

[Bridge]
"Consumado es," fueron Sus palabras,
La obra completa, puertas abiertas,
El velo se rasgó de arriba abajo,
El camino a Dios ya no es bajo.

[Outro]
En la cruz... todo fue consumado...
