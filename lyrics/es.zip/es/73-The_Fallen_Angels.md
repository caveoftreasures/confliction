SONG 73: "The Fallen Angels"

Canción 73: Los Ángeles Caídos

[Intro]

[Verse 1]
Un cordero sin mancha cada casa tomó,
La sangre en los postes Dios ordenó,
Cuando el ángel de muerte pasara,
La sangre señal de vida sería clara.

[Verse 2]
Carne asada con hierbas amargas,
Pan sin levadura en las cargas,
Vestidos y listos para partir,
La noche de libertad por venir.

[Chorus]
El cordero pascual murió por nosotros,
Su sangre nos libra de todos los otros,
Cristo es nuestro Cordero hoy,
¡Su sangre nos da libertad, soy!

[Bridge]
De Egipto a la cruz la historia va,
Del cordero a Cristo que nos salvará,
El juicio pasa de largo cuando ve,
La sangre del Cordero que por fe es.

[Outro]
La sangre del cordero... la muerte pasa...
