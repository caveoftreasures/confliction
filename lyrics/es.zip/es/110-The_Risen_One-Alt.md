SONG 110: "The Risen One (Alt)"

Canción 110: El Resucitado

[Intro]

[Verse 1]
Daniel en Babilonia fue cautivo,
Pero guardó su corazón activo,
No se contaminó con manjares del rey,
Dios le dio favor, gracia y ley.

[Verse 2]
Interpretando sueños por el Espíritu de Dios,
Reyes se postraron ante su voz,
La imagen del sueño, los reinos que vendrían,
Hasta que el Reino de Dios todo llenaría.

[Chorus]
Daniel en Babilonia se mantuvo fiel,
En tierra extraña, sirviendo a Emmanuel,
Tres veces al día orando a su Dios,
¡Ningún decreto pudo callar su voz!

[Bridge]
En el foso de los leones sobrevivió,
Dios envió Su ángel y lo protegió,
La fe de Daniel brilló en la oscuridad,
Testigo del Dios de verdad.

[Outro]
Fiel en tierra extraña... Dios es fiel...
