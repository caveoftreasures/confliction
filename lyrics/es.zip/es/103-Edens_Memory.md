SONG 103: "Edens Memory"

Canción 103: El Recuerdo del Edén

[Intro]

[Verse 1]
Elías huyó de Jezabel con temor,
A una cueva se escondió con dolor,
"Soy el único que queda," él clamó,
Pero Dios en Su gracia respondió.

[Verse 2]
Viento recio, terremoto y fuego vinieron,
Pero en ninguno de ellos Dios sintieron,
Un silbo apacible, una voz suave,
Dios habló y todo fue clave.

[Chorus]
La voz suave y apacible de Dios,
No en el ruido, sino en la paz con Él,
En la quietud Él habla aún,
¡Silencio el alma para escuchar su canto común!

[Bridge]
No siempre en lo grande Dios está,
A veces en lo pequeño Él vendrá,
Aprende a escuchar Su voz sutil,
En la quietud, en lo gentil.

[Outro]
El silbo apacible... Dios habla...
