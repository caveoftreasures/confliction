SONG 65: "Seth the Replacement"

Canción 65: Set el Sustituto

[Intro]

[Verse 1]
José soñaba sueños de grandeza,
Sol, luna y estrellas en una certeza,
Sus hermanos lo odiaron por esto,
Lo vendieron como esclavo con pretexto.

[Verse 2]
De la cisterna a Egipto fue llevado,
De esclavo a prisionero, abandonado,
Pero Dios estaba con él en todo,
Interpretando sueños de modo.

[Chorus]
José el soñador, vendido y traicionado,
Pero Dios lo llevó a ser exaltado,
Lo que el hombre pensó para mal,
¡Dios lo usó para bien eternal!

[Bridge]
De la prisión al palacio ascendió,
Segundo después de Faraón, Dios lo bendijo,
Salvando a su familia del hambre cruel,
Perdonando a sus hermanos, siempre fiel.

[Outro]
Soñando sueños... Dios los cumplirá...
