SONG 116: "Walking with God (Alt)"

Canción 116: Caminando con Dios

[Intro]

[Verse 1]
Setenta años en Babilonia pasaron,
Ciro el persa libertad les dio,
Zorobabel guió al pueblo de regreso,
Para reconstruir el templo con proceso.

[Verse 2]
Esdras trajo la ley de nuevo,
Nehemías los muros levantó con duelo,
El pueblo regresó a su tierra,
Esperando al Mesías que acabaría la guerra.

[Chorus]
Del exilio de regreso a casa,
Dios cumple Sus promesas sin traza,
Restauración viene después del juicio,
¡Dios no abandona a Su pueblo en el suplicio!

[Bridge]
El templo fue reconstruido otra vez,
Pero la gloria no era como antes, parece,
Un día un templo mayor vendría,
El cuerpo de Cristo, templo del Mesías.

[Outro]
Regresando del exilio... restauración...
