SONG 18: "The Cherub at the Gate (Alt)"

Canción 18: El Querubín en la Puerta

[Intro]

[Verse 1]
Un querubín con espada ardiente,
De la puerta del jardín guardián vigilante,
Adán y Eva al verlo cayeron,
Pensando que los mataría sin dudar.

[Verse 2]
Pero el ángel subió al cielo alto,
Orando a Dios: "¿Qué haré con ellos, oh Dios?
Tus siervos yacen como muertos de miedo,
¿Qué les diré que les sea claro?"

[Chorus]
El querubín en la puerta se para,
Guardando el camino al árbol de vida,
Un día la espada será retirada,
¡Y entraremos sin más herida!

[Bridge]
La espada ardiente gira y brilla,
Recordatorio del pecado y su destino,
Pero más allá de la espada hay esperanza,
Un camino de regreso por amor divino.

[Outro]
Guardando la puerta... esperando el día...
