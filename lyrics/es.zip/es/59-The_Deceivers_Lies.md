SONG 59: "The Deceivers Lies"

Canción 59: Las Mentiras del Engañador

[Intro]

[Verse 1]
De Ur de los Caldeos Dios llamó,
A un hombre llamado Abram, nunca derrotado,
"Deja tu tierra y tu parentela,
Ve a la tierra que te mostraré en la huella."

[Verse 2]
Por fe Abraham obedeció el llamado,
Sin saber a dónde iba, dio el paso,
Sara su esposa a su lado,
Siguiendo a Dios con corazón confiado.

[Chorus]
Abraham fue llamado a caminar por fe,
Sin ver el fin, siguió adelante,
Padre de naciones llegaría a ser,
¡La promesa de Dios él iba a obtener!

[Bridge]
De Abraham a Isaac, de Isaac a Jacob,
La línea del Mesías nunca se acabó,
Dios cumple Sus promesas a través del tiempo,
A todos los que creen en Su diseño.

[Outro]
Llamado por Dios... caminando por fe...
