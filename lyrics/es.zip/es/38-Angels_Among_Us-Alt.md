SONG 38: "Angels Among Us (Alt)"

Canción 38: Ángeles Entre Nosotros

[Intro]

[Verse 1]
Caín fue maldecido a vagar la tierra,
Marcado por Dios desde su nuevo nacimiento,
Fugitivo y vagabundo sería,
Apartado de su familia, nunca libre.

[Verse 2]
La tierra ya no daría fruto,
Para las manos que derramaron sangre inocente,
Temblando y gimiendo todos sus días,
Viviendo en miedo de mil maneras.

[Chorus]
El castigo de Caín fue severo pero justo,
La consecuencia del pecado que todos deben enfrentar,
Pero Dios en misericordia le puso una marca,
Para protegerlo en la oscuridad.

[Bridge]
Incluso en el juicio, Dios muestra gracia,
La misericordia brilla en cada lugar,
El pecado tiene un precio que debemos pagar,
Pero Dios proporciona otro camino.

[Outro]
Vagando... pero no olvidado...
