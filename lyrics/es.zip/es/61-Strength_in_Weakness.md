SONG 61: "Strength in Weakness"

Canción 61: Fuerza en la Debilidad

[Intro]

[Verse 1]
A Abraham Dios prometió una semilla,
Numerosa como las estrellas en el cielo,
Como la arena del mar sin medida,
Bendición para todas las naciones con prisa.

[Verse 2]
A través de Isaac la promesa vendría,
El hijo de la risa, el santo,
Jacob luchó y prevaleció,
Israel su nombre, nunca falló.

[Chorus]
La semilla prometida crece y crece,
De Abraham a David la historia fluye,
Hasta que nació en Belén,
¡El Salvador prometido, nuestro Edén!

[Bridge]
Cada generación esperó,
La promesa de Dios nunca se agotó,
La semilla de la mujer aplastaría,
La cabeza de la serpiente que engañaría.

[Outro]
La semilla prometida... el Salvador vendría...
