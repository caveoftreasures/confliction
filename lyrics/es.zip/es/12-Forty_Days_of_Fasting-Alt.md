SONG 12: "Forty Days of Fasting (Alt)"

Canción 12: Cuarenta Días de Ayuno

[Intro]

[Verse 1]
Cuarenta días y cuarenta noches,
Adán se paró en el agua fría,
Orando a Dios por misericordia,
Buscando perdón, buscando gracia.

[Verse 2]
Eva en el río Tigris parada,
Su corazón arrepentido, manos alzadas,
Ambos ayunando de toda comida,
Esperando que sus almas fueran renovadas.

[Chorus]
Cuarenta días de ayuno y oración,
Buscando a Dios en todas partes,
No comeremos, no beberemos,
Hasta que la misericordia del Señor alcancemos.

[Bridge]
El ayuno rompe el poder del pecado,
La oración trae la paz de Dios,
Cuando nos humillamos ante Él,
Su gracia nos llena por completo.

[Outro]
Ayuno y oración... el camino está claro...
