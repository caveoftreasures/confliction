SONG 98: "Rivers of Living Water (Alt)"

Canción 98: Ríos de Agua Viva

[Intro]

[Verse 1]
Dios prometió a David una casa,
Un reino eterno que todo sobrepasa,
Su trono permanecería para siempre,
Un hijo reinaría eternamente.

[Verse 2]
Salomón construyó el templo grande,
Pero el verdadero templo es más que un estante,
Cristo el Hijo de David vendría,
Su reino sin fin permanecería.

[Chorus]
La casa de David permanece firme,
La promesa de Dios siempre confirme,
Un Rey de la línea de David nacería,
¡Cristo Jesús, Rey y Mesías!

[Bridge]
De la raíz de Isaí un renuevo salió,
La vara floreciente que esperó,
El León de Judá, la Estrella de Jacob,
Todo en Cristo se cumplió.

[Outro]
La casa de David... el trono eterno...
