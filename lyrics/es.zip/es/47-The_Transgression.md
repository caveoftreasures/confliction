SONG 47: "The Transgression"

Canción 47: La Transgresión

[Intro]

[Verse 1]
En los días de Noé la tierra estaba corrompida,
Todo pensamiento del hombre distorsionado,
Violencia llenaba cada lugar,
El mal había tomado todo el espacio.

[Verse 2]
Pero Noé encontró gracia a los ojos de Dios,
Un hombre justo, santo y sabio,
Predicó justicia por ciento veinte años,
Pero nadie escuchó sus lágrimas.

[Chorus]
Los días de Noé fueron oscuros y llenos de pecado,
Pero Dios tenía un plan desde el principio,
Un arca de salvación Él proveyó,
Para aquellos que en Él creyeron.

[Bridge]
Como fue en los días de Noé,
Así será cuando Cristo venga a buscar,
Comiendo, bebiendo, sin preocupación,
Hasta que el juicio llegue sin comparación.

[Outro]
Los días de Noé... señales de los tiempos...
