SONG 26: "The Fig Leaves (Alt)"

Canción 26: Las Hojas de Higuera

[Intro]

[Verse 1]
Hojas de higuera cosieron ese día,
Para cubrir su vergüenza y esconderse,
El primer intento del hombre de arreglar el pecado,
Pero solo Dios puede limpiar lo de adentro.

[Verse 2]
Frágiles hojas que pronto se marchitarían,
No pueden cubrir lo que el pecado revela,
Solo la sangre puede lavar la mancha,
Solo Dios puede quitar el dolor.

[Chorus]
Hojas de higuera no pueden cubrir el pecado,
Nuestros esfuerzos fallan una y otra vez,
Solo Dios puede vestirnos de nuevo,
¡Con vestiduras de gracia, lavados de la mancha!

[Bridge]
De hojas a pieles Dios los vistió,
Un sacrificio hecho, sangre derramada,
Señalando al Cordero que vendría,
Para vestir a todos los que creen en Él.

[Outro]
Cubiertos por Dios... vestidos de gracia...
