SONG 126: "From Glory to Glory (Alt)"

Canción 126: De Gloria en Gloria

[Intro]

[Verse 1]
Juan vio a Jesús venir hacia él,
"He aquí el Cordero de Dios," dijo fiel,
"Que quita el pecado del mundo,"
El sacrificio perfecto, profundo.

[Verse 2]
Desde Abel el cordero prefiguró,
El sacrificio que Dios preparó,
En Egipto la sangre protegió,
Y en la cruz todo se cumplió.

[Chorus]
El Cordero de Dios, sin mancha ni defecto,
Llevó nuestros pecados, acto perfecto,
De la esclavitud nos liberó,
¡Con Su sangre preciosa nos compró!

[Bridge]
Digno es el Cordero que fue inmolado,
De recibir poder, gloria y honor, amado,
Toda rodilla se doblará,
Y toda lengua confesará.

[Outro]
He aquí el Cordero... que quita el pecado...
