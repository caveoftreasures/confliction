SONG 46: "The Strange Land (Alt)"

Canción 46: La Tierra Extraña

[Intro]

[Verse 1]
Enoc caminó con Dios cada día,
Un hombre de fe en todo sentido,
Trescientos años en comunión,
Aprendiendo los secretos de la salvación.

[Verse 2]
Dios le mostró los cielos arriba,
Los misterios del tiempo y el amor,
Los ángeles, los tronos, la gloria divina,
Visiones del futuro, señal tras señal.

[Chorus]
Enoc camina con Dios y no fue más,
Porque Dios lo tomó a la costa eterna,
Sin probar la muerte, fue llevado,
¡Un hombre tan fiel, tan amado!

[Bridge]
Caminar con Dios significa andar en luz,
Hacer lo correcto en Su vista,
Enoc nos muestra el camino,
A vivir para Dios cada día.

[Outro]
Caminando con Dios... hacia la eternidad...
