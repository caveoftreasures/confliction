SONG 130: "The Eternal Home (Alt)"

Canción 130: El Hogar Eterno

[Intro]

[Verse 1]
Al tercer día la piedra rodó,
La tumba vacía, Jesús resucitó,
Los ángeles preguntaron ese día,
"¿Por qué buscáis entre muertos al que vive?" decían.

[Verse 2]
María lo vio en el jardín,
Los discípulos creyeron al fin,
Por cuarenta días apareció,
Y muchas pruebas de vida les dio.

[Chorus]
¡Ha resucitado! ¡No está aquí!
La muerte derrotada, ya no hay frenesí,
El que era muerto vive para siempre,
¡Cristo vive, eternamente!

[Bridge]
Porque Él vive, yo también viviré,
La muerte no es el fin, yo lo sé,
La tumba no pudo retenerlo,
Y no podrá retenerme a mí, lo veo.

[Outro]
Ha resucitado... vive para siempre...
