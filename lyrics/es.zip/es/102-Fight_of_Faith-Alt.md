SONG 102: "Fight of Faith (Alt)"

Canción 102: La Lucha de la Fe

[Intro]

[Verse 1]
Elías el profeta de fuego llegó,
En tiempos de maldad él proclamó,
"No habrá lluvia sino por mi palabra,"
Tres años de sequía, la tierra arrasada.

[Verse 2]
En el monte Carmelo el desafío lanzó,
Cuatrocientos profetas de Baal enfrentó,
El fuego del cielo cayó sobre el altar,
"¡El Señor es Dios!" el pueblo gritó sin cesar.

[Chorus]
Elías el profeta de Dios,
Llamando al arrepentimiento con voz,
Antes que venga el día grande,
¡Preparad el camino que el Señor expande!

[Bridge]
En un carro de fuego fue llevado,
Al cielo sin morir, arrebatado,
Un día volverá antes del fin,
Preparando corazones sin confín.

[Outro]
El profeta de fuego... preparando el camino...
