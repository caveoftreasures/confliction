SONG 122: "Never Forgotten (Alt)"

Canción 122: Nunca Olvidado

[Intro]

[Verse 1]
En el principio era el Verbo,
Y el Verbo era con Dios, todo sincero,
Y el Verbo era Dios desde el inicio,
Todo fue hecho por Él, sin perjuicio.

[Verse 2]
Y el Verbo se hizo carne y habitó,
Entre nosotros Su gloria mostró,
Gloria como del Unigénito del Padre,
Lleno de gracia y verdad, nuestro Madre.

[Chorus]
El Verbo se hizo carne, Dios con nosotros,
Emmanuel entre los otros,
El Creador se hizo criatura,
¡Para salvarnos con ternura!

[Bridge]
De la eternidad al tiempo vino,
Del cielo al pesebre, destino,
El Infinito en brazos de María,
El Eterno nació ese día.

[Outro]
El Verbo se hizo carne... y habitó entre nosotros...
