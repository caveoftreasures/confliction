SONG 9: "Satans Disguise"

Canción 09: El Disfraz de Satanás

[Intro]

[Verse 1]
Vestido con ropas brillantes como el día,
Satanás vino para extraviar,
Vara de luz en su mano,
Luciendo santo, luciendo grandioso.

[Verse 2]
"La paz sea contigo," él dijo,
"Dios me envió en Su lugar,
Ven conmigo al paraíso,
Te daré todo, no pagues precio."

[Chorus]
Satanás se transforma en luz,
Haciendo que lo malo parezca correcto,
¡Pero el pueblo de Dios reconoce,
Al engañador disfrazado!

[Bridge]
Ochenta veces intentó engañar,
Cada plan los haría enfermar,
Pero Dios fue fiel, siempre cerca,
Alejando a Satanás con temor.

[Outro]
Prueba cada espíritu... conoce la verdad...
