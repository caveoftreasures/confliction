SONG 29: "Standing in the Water"

Canción 29: De Pie en el Agua

[Intro]

[Verse 1]
En el centro del jardín estaba,
El árbol de vida, glorioso y grande,
Sus frutos daban vida eterna,
Pero ahora el camino estaba cerrado y bloqueado.

[Verse 2]
Un querubín con espada ardiente,
Guardando el camino, el decreto de Dios,
Ningún hombre pecador podía acercarse,
Hasta que el Salvador quitara el miedo.

[Chorus]
El árbol de vida, algún día volveremos,
Cuando el Salvador complete la obra de Dios,
Del jardín fuimos expulsados,
¡Pero a través de Cristo el camino se ha mostrado!

[Bridge]
La cruz se convirtió en nuestro árbol de vida,
Donde Cristo terminó nuestra lucha,
Su sangre abrió el camino de nuevo,
Al paraíso donde reinaremos.

[Outro]
El árbol de vida... nos espera...
