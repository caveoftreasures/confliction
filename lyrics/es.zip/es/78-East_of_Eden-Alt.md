SONG 78: "East of Eden (Alt)"

Canción 78: Al Este del Edén

[Intro]

[Verse 1]
En el desierto el pueblo se quejó,
"No hay comida," su voz clamó,
Pero Dios en Su gracia proveyó,
Pan del cielo cada mañana envió.

[Verse 2]
"¿Qué es esto?" el pueblo preguntó,
Maná lo llamaron cuando lo probó,
Dulce como miel, blanco como escarcha,
Suficiente para el día, sin ninguna marcha.

[Chorus]
Maná del cielo, pan de cada día,
Dios alimenta a los suyos con alegría,
No solo de pan el hombre vivirá,
¡Sino de la Palabra que de Dios saldrá!

[Bridge]
Cristo es el verdadero pan del cielo,
El que come de Él vive sin duelo,
El maná se acabó, Cristo permanece,
Alimento eterno que nunca perece.

[Outro]
Pan del cielo... vida para siempre...
