SONG 71: "The Garments of Skin"

Canción 71: Las Vestiduras de Piel

[Intro]

[Verse 1]
Moisés ante Faraón se presentó,
"Así dice el Señor," proclamó,
"Deja ir a mi pueblo a adorar,
En el desierto quieren celebrar."

[Verse 2]
Faraón endureció su corazón,
"¿Quién es el Señor? No hay razón,
No conozco a ese Dios de Israel,
No dejaré ir a su grey infiel."

[Chorus]
¡Deja ir a mi pueblo! Dios demandó,
Pero Faraón su corazón cerró,
Diez plagas vendrían sobre Egipto,
¡Hasta que el pueblo fuera librado, bendito!

[Bridge]
Sangre, ranas, piojos, moscas sin fin,
Peste, úlceras, granizo, langostas sin fin,
Tinieblas cubrieron la tierra hostil,
Y la muerte del primogénito al final vil.

[Outro]
Deja ir a mi pueblo... la libertad viene...
