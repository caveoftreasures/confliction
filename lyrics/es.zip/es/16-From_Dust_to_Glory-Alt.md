SONG 16: "From Dust to Glory (Alt)"

Canción 16: Del Polvo a la Gloria

[Intro]

[Verse 1]
Del polvo de la tierra fuimos hechos,
Formados por las manos de Dios sin descanso,
Aliento de vida en nuestras formas,
Elevándonos sobre todas las tormentas.

[Verse 2]
En el jardín caminamos con Él,
Antes de que el pecado hiciera que tropezáramos y cayéramos,
Gloria nos cubría como un vestido,
Naturaleza brillante, pura y bendita.

[Chorus]
Del polvo a la gloria fuimos elevados,
Por el pecado otra vez fuimos rebajados,
Pero la promesa de Dios permanece verdadera,
¡Del polvo Él nos renovará!

[Bridge]
El polvo recuerda de dónde venimos,
La gloria muestra lo que seremos,
Entre polvo y gloria esperamos,
Por el Redentor que no es tarde.

[Outro]
Del polvo... a la gloria eterna...
