SONG 123: "Holy Holy Holy"

Canción 123: Santo Santo Santo

[Intro]

[Verse 1]
En Belén de Judea nació el Rey,
Cumpliendo la profecía y la ley,
No en palacio sino en un establo,
El Salvador del mundo, humilde y santo.

[Verse 2]
María lo envolvió en pañales,
Lo acostó en un pesebre, sin iguales,
Pastores vinieron a adorar,
Al niño que vino a salvar.

[Chorus]
Nacido en Belén, el Pan de Vida,
En la casa de pan, llegada bendecida,
Los ángeles cantaron gloria a Dios,
¡Paz en la tierra, buena voluntad a nos!

[Bridge]
Reyes magos siguieron la estrella,
Oro, incienso y mirra tan bella,
Adorando al Rey recién nacido,
El Mesías prometido.

[Outro]
Nacido en Belén... el Salvador vino...
