SONG 5: "The First Darkness"

Canción 05: La Primera Oscuridad

[Intro]

[Verse 1]
Cuando cayó la noche por primera vez,
Adán y Eva temblaron de miedo,
Nunca habían conocido la oscuridad antes,
Solo luz eterna, año tras año.

[Verse 2]
"¿Por qué, Señor, nos plagas así?"
Clamaron en la noche negra sin fin,
Pensando que Dios los había abandonado,
Perdidos en sombras, tan solos.

[Chorus]
La primera oscuridad cayó sobre sus almas,
Pero Dios prometió que la luz volvería,
Doce horas de noche, luego el amanecer brillaría,
La oscuridad no dura para siempre, espera y verás.

[Bridge]
Día y noche, noche y día,
El ciclo gira de esta manera,
Un tiempo para trabajar, un tiempo para descansar,
Dios sabe qué es lo mejor.

[Outro]
Esperando el amanecer... viene la luz...
