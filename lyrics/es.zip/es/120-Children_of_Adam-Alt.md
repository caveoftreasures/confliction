SONG 120: "Children of Adam (Alt)"

Canción 120: Los Hijos de Adán

[Intro]

[Verse 1]
Juan el Bautista en el desierto clamó,
"Preparad el camino del Señor," proclamó,
Vestido de pelo de camello, miel y langostas,
Predicando arrepentimiento en las costas.

[Verse 2]
"El que viene después de mí es mayor,
No soy digno de desatar su calzado menor,
Yo bautizo en agua, pero Él bautizará,
En Espíritu Santo, fuego traerá."

[Chorus]
Una voz en el desierto prepara,
El camino del Señor se declara,
Enderezad las sendas torcidas,
¡El Rey de reyes viene con vidas bendecidas!

[Bridge]
Juan preparó el camino del Rey,
El último profeta de la vieja ley,
Señalando a Cristo dijo un día,
"He aquí el Cordero," con alegría.

[Outro]
Preparad el camino... el Señor viene...
