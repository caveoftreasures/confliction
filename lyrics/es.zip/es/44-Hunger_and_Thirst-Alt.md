SONG 44: "Hunger and Thirst (Alt)"

Canción 44: Hambre y Sed

[Intro]

[Verse 1]
Ángeles descendieron del cielo alto,
Los vigilantes que cruzaron la línea,
Vieron a las hijas de los hombres tan bellas,
Y tomaron esposas de dondequiera.

[Verse 2]
Gigantes nacieron de esa unión,
Los Nefilim trajeron confusión,
La tierra fue corrompida por su maldad,
Pero Noé encontró gracia en la bondad de Dios.

[Chorus]
Los vigilantes cayeron de su lugar santo,
Mezclando cielo y tierra en desgracia,
Pero Dios vio todo desde arriba,
Y envió el diluvio con Su amor.

[Bridge]
Encadenados en oscuridad esperan,
Los ángeles que sellaron su destino,
El juicio viene para todos los que pecan,
Sea ángel u hombre, afuera o adentro.

[Outro]
Los vigilantes cayeron... pero Dios permanece...
