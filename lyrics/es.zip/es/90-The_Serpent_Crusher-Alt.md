SONG 90: "The Serpent Crusher (Alt)"

Canción 90: El que Aplasta la Serpiente

[Intro]

[Verse 1]
Israel hizo lo malo otra vez,
Olvidando a Dios, buscando otro juez,
Pero cuando clamaban en su dolor,
Dios levantaba un libertador.

[Verse 2]
Otoniel, Aod, Débora valiente,
Gedeón con trescientos, Dios omnipotente,
Jefté, Sansón con fuerza sin igual,
Cada juez señalando al Rey eternal.

[Chorus]
Los jueces se levantan cuando Israel cae,
Salvadores temporales que Dios trae,
Pero un Juez perfecto vendría,
¡Cristo Jesús, Juez y Mesías!

[Bridge]
El ciclo de pecado continuó,
Hasta que el verdadero Juez llegó,
No solo para librar del enemigo,
Sino del pecado, siempre contigo.

[Outro]
Los jueces vienen y van... el Rey permanece...
