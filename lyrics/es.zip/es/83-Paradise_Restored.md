SONG 83: "Paradise Restored"

Canción 83: El Paraíso Restaurado

[Intro]

[Verse 1]
Serpientes ardientes mordían al pueblo,
Juicio por su queja, sin consuelo,
Murieron muchos por el veneno,
Hasta que clamaron al Dios bueno.

[Verse 2]
Dios dijo a Moisés: "Haz una serpiente,
Ponla en un asta, sea evidente,
Todo el que mire vivirá,
La fe en Mi palabra lo salvará."

[Chorus]
La serpiente de bronce levantada,
Símbolo de Cristo en la jornada,
Como Moisés levantó la señal,
¡Cristo fue levantado en la cruz final!

[Bridge]
Mira y vive, la orden fue dada,
No hay otra obra, no hay otra strada,
Solo mirar al que fue herido,
Por nuestras transgresiones, el ungido.

[Outro]
Mira y vive... Cristo fue levantado...
