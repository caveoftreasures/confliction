SONG 36: "The Tree of Life (Alt)"

Canción 36: El Árbol de la Vida

[Intro]

[Verse 1]
Abel yacía muerto en el campo,
Su sangre clamaba, su vida sellada,
El primer asesinato, hermano contra hermano,
Caín de pie solo bajo el sol.

[Verse 2]
"¿Dónde está tu hermano?" Dios demandó,
"Su sangre clama desde la tierra,
Maldito serás, vagando sin descanso,
El juicio de Dios sobre tu cabeza."

[Chorus]
La sangre de Abel clama desde el suelo,
Un clamor por justicia, un sonido solemne,
Pero una sangre mejor un día hablaría,
¡La sangre de Jesús, salvación traería!

[Bridge]
De Abel a Cristo la línea corre,
Sangre derramada hasta que todo esté hecho,
Pero la sangre de Cristo clama perdón,
No venganza, sino vida sin fin.

[Outro]
La sangre clama... pero la gracia responde...
