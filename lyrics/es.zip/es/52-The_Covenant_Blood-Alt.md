SONG 52: "The Covenant Blood (Alt)"

Canción 52: La Sangre del Pacto

[Intro]

[Verse 1]
Dios llamó a Noé: "Entra ahora,"
Dos de cada especie, él mostraría cómo,
Siete de los limpios, macho y hembra,
Para preservar la vida, el plan del Creador.

[Verse 2]
Los animales vinieron de cerca y de lejos,
Guiados por Dios como una estrella,
Dos a dos entraron en fila,
Mientras las nubes se oscurecían milla tras milla.

[Chorus]
Entra al arca, refugio seguro,
Antes de que llegue la tormenta,
Dios cierra la puerta, la gracia termina,
¡Ven ahora, no seas de los que pierden!

[Bridge]
Ocho almas entraron ese día,
Mientras el mundo seguía en su camino,
La puerta se cerró, el tiempo acabó,
Para aquellos que rechazaron al Dios amado.

[Outro]
Entrando al arca... salvados por gracia...
