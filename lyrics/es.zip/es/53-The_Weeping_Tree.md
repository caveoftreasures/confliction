SONG 53: "The Weeping Tree"

Canción 53: El Árbol que Llora

[Intro]

[Verse 1]
Las fuentes del abismo se abrieron ese día,
Las ventanas del cielo sin parar,
Cuarenta días y cuarenta noches,
La lluvia cayó con todas sus fuerzas.

[Verse 2]
Las aguas subieron más y más alto,
Cubriendo montañas hasta el cielo,
Todo lo que respiraba pereció en el agua,
Excepto los que estaban en el arca del Padre.

[Chorus]
El diluvio vino como Dios advirtió,
Barriendo todo lo que estaba deformado,
Pero dentro del arca había paz,
¡La familia de Noé encontró su base!

[Bridge]
El juicio de Dios es seguro y verdadero,
Pero la salvación está disponible para ti,
El arca fue el camino en ese entonces,
Cristo es el camino ahora y siempre, amén.

[Outro]
Las aguas cubrieron la tierra... pero el arca flotó...
