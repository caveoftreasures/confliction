SONG 42: "The Jordan Flows (Alt)"

Canción 42: El Jordán Fluye

[Intro]

[Verse 1]
De Adán a Set, de Set a Enós,
Generaciones pasando el testigo de Dios,
Cada padre enseñando a su hijo,
La promesa de salvación para todos.

[Verse 2]
Cainán, Mahalaleel, Jared también,
Enoc que caminó con Dios y voló,
Matusalén, el más viejo de todos,
Lamec y Noé escuchando el llamado.

[Chorus]
Las generaciones van y vienen,
Pero la promesa de Dios siempre fluye,
De padre a hijo la historia contamos,
¡Hasta que el Salvador rompa el hechizo!

[Bridge]
Cada nombre en la línea sagrada,
Apuntando al Salvador divino,
La historia de redención se despliega,
Como los profetas antiguos predijeron.

[Outro]
Generación tras generación... la promesa continúa...
