SONG 112: "The Final Day (Alt)"

Canción 112: El Día Final

[Intro]

[Verse 1]
Tres jóvenes hebreos se negaron a adorar,
La estatua de oro del rey Nabucodonosor,
"Nuestro Dios puede librarnos," declararon,
"Y si no, aún así no nos postraremos," afirmaron.

[Verse 2]
Siete veces más el horno calentaron,
A Sadrac, Mesac y Abed-nego arrojaron,
Pero cuatro figuras caminaban dentro,
"El cuarto parece hijo de los dioses," fue el encuentro.

[Chorus]
En el horno de fuego Dios estuvo ahí,
Caminando con Sus siervos, junto a ti,
Las llamas no tienen poder,
¡Cuando Dios decide proteger!

[Bridge]
Ni un cabello chamuscado estaba,
Ni olor a humo los acompañaba,
El fuego que mata, para ellos no ardió,
Porque el Hijo de Dios con ellos anduvo.

[Outro]
En el fuego... Dios está presente...
