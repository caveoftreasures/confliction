SONG 33: "The Fire in the Cave"

Canción 33: El Fuego en la Cueva

[Intro]

[Verse 1]
Dios prometió agua para su sed,
No solo para el cuerpo, también para el alma,
Ríos de agua viva fluirían,
Del Salvador que todos conocerán.

[Verse 2]
Del Jordán al pozo de Jacob,
Agua de vida donde los sedientos moran,
Cristo ofrece lo que nunca se agota,
Una fuente de vida que siempre es la mejor.

[Chorus]
La promesa del agua, pura y verdadera,
Del cielo fluyendo hacia mí y hacia ti,
Nunca sedientos, nunca secos otra vez,
¡Bebiendo del Salvador, el amigo del hombre!

[Bridge]
El agua lava, el agua limpia,
El agua cumple todos nuestros sueños,
Bautizados en Su nombre santo,
Nacidos de nuevo, nunca los mismos.

[Outro]
Agua de vida... fluyendo libre...
