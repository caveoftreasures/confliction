SONG 4: "Cave of Treasures (Alt)"

Canción 04: La Cueva de los Tesoros

[Intro]

[Verse 1]
Cueva de Tesoros, nuestro nuevo hogar,
Rocas y oscuridad, tan lejos de la gloria,
De los árboles del Edén a este lugar sombrío,
De la luz del cielo a esta prisión terrenal.

[Verse 2]
Adán y Eva lloraron amargamente,
Recordando el jardín tan claro y brillante,
Sus cuerpos cambiados, su visión oscurecida,
Sin ángeles cantando, sin luz divina.

[Chorus]
En la Cueva de Tesoros nos arrodillamos y oramos,
Esperando la promesa de un nuevo día,
Dios no nos abandonó en nuestra desesperación,
Su amor nos siguió incluso allí.

[Bridge]
Esta cueva de piedra, esta tumba de tierra,
Se convertiría en un símbolo de renacimiento,
Porque de la oscuridad viene la luz,
Y de la muerte viene la vida eterna.

[Outro]
Esperando en la oscuridad... la luz vendrá...
