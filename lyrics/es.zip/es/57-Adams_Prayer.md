SONG 57: "Adams Prayer"

Canción 57: La Oración de Adán

[Intro]

[Verse 1]
En la llanura de Sinar construyeron,
Una torre hasta el cielo, pensamiento sin fin,
"Hagámonos un nombre," dijeron,
"Para no ser esparcidos," en su mente pesó.

[Verse 2]
Ladrillos por piedras, asfalto por mortero,
La torre subía cada vez más alta,
Pero Dios descendió para ver,
Lo que los hijos de los hombres querían ser.

[Chorus]
La torre de Babel se levantó con orgullo,
El hombre intentando alcanzar el cielo,
Pero Dios confundió sus lenguas ese día,
¡Y los esparció por todo lugar!

[Bridge]
El orgullo viene antes de la caída,
Cuando el hombre trata de ser Dios sobre todo,
Pero los planes de Dios no pueden ser frustrados,
Su voluntad siempre será celebrada.

[Outro]
Lenguas confundidas... naciones nacidas...
