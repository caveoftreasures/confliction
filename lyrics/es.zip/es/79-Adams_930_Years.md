SONG 79: "Adams 930 Years"

Canción 79: Los 930 Años de Adán

[Intro]

[Verse 1]
En el monte Sinaí Dios descendió,
Con truenos y relámpagos se presentó,
Moisés subió a recibir la ley,
Mandamientos de Dios, el eterno Rey.

[Verse 2]
"No tendrás otros dioses delante de mí,
No te harás imágenes así,
No tomarás mi nombre en vano,
Acuérdate del sábado, hermano."

[Chorus]
Los Diez Mandamientos en piedra escritos,
La ley de Dios para los benditos,
Amarás al Señor con todo tu ser,
¡Y a tu prójimo como debes hacer!

[Bridge]
Honra a tu padre y a tu madre bien,
No matarás, no adulterarás también,
No robarás, no mentirás jamás,
No codiciarás lo que otros tienen más.

[Outro]
La ley de Dios... escrita en piedra...
