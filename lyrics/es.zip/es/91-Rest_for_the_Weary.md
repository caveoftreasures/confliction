SONG 91: "Rest for the Weary"

Canción 91: Descanso para los Cansados

[Intro]

[Verse 1]
Rut dejó su tierra por amor,
Siguiendo a Noemí con fervor,
"Tu pueblo será mi pueblo," dijo,
"Tu Dios mi Dios," su alma bendijo.

[Verse 2]
En los campos de Boaz espigó,
Un pariente redentor la encontró,
La tomó por esposa con ternura,
Cubriendo su vida de dulzura.

[Chorus]
Rut y Boaz, historia de redención,
El pariente cercano, nuestra salvación,
Cristo es nuestro Boaz hoy,
¡Nos redime, nuestro convoy!

[Bridge]
De Rut nació Obed, padre de Isaí,
De Isaí, David el rey nació allí,
La línea del Mesías continuó,
De una moabita que a Dios siguió.

[Outro]
Redimida por amor... en la línea del Rey...
