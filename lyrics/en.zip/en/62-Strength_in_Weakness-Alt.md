SONG 62: "Strength in Weakness (Alt)"

[Intro]

[Verse 1]
Bodies withered, strength was gone,
Couldn't make it on their own,
Falling down inside the cave,
No more energy to save.

[Verse 2]
But in their weakness, God was strong,
Carried them the whole way long,
When they couldn't stand no more,
His Word would lift them off the floor.

[Chorus]
Strength in weakness, power in pain,
When we're empty, we can gain,
All of God's sufficient grace,
To carry us to a better place!

[Verse 3]
"I can't do this anymore!"
Adam cried out from the core,
But God said, "My grace is enough,
When the road is long and rough."

[Verse 4]
Forty days without a meal,
Nothing left for them to feel,
But heaven's power kept them standing,
God's own grace was never-ending.

[Chorus]
Strength in weakness, power in pain,
When we're empty, we can gain,
All of God's sufficient grace,
To carry us to a better place!

[Bridge]
When I am weak then I am strong,
This is where we all belong,
Dependent on the One above,
Filled with His unending love.

[Outro]
In our weakness... His power is made perfect...
