SONG 37: "Angels Among Us"

[Intro]

[Verse 1]
When they fell before the gate,
Angels moved to change their fate,
Cherub prayed to God above,
Interceding with great love.

[Verse 2]
Angels carried them with care,
To the cave, safe from despair,
Brought them gifts of gold and myrrh,
Incense sweet that would occur.

[Chorus]
Angels among us, sent from on high,
Watching and guarding as days go by,
Ministering spirits for those who believe,
God's faithful servants who never leave!

[Verse 3]
When the serpent attacked with might,
An angel threw it from their sight,
Carried it on winds so strong,
Cast it where it would belong.

[Verse 4]
When the rock came tumbling down,
Angels turned it to a crown,
Shelter from the enemy's plan,
Protection for the fallen man.

[Chorus]
Angels among us, sent from on high,
Watching and guarding as days go by,
Ministering spirits for those who believe,
God's faithful servants who never leave!

[Bridge]
They don't always show their face,
Working silently with grace,
But in moments of great need,
They appear and intercede.

[Outro]
Angels are watching... always watching...
