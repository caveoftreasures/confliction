SONG 26: "The Fig Leaves (Alt)"

[Intro]

[Verse 1]
When their eyes were opened wide,
They saw their shame, tried to hide,
Fig leaves sewn together quick,
A covering thin and weak and slick.

[Verse 2]
Before the fall they knew no shame,
Naked, pure, without a blame,
But sin had stripped their glory bright,
Left them bare in their own sight.

[Chorus]
Fig leaves can't cover what we've done,
Can't hide our shame from the Holy One,
Only God can clothe our sin,
With garments pure that come from Him!

[Verse 3]
God came walking in the cool,
Found them hiding, playing fool,
"Who told you that you were bare?
Did you eat the fruit I said beware?"

[Verse 4]
Adam blamed Eve, Eve blamed the snake,
Neither owned their big mistake,
But God in mercy clothed them still,
Working out His sovereign will.

[Chorus]
Fig leaves can't cover what we've done,
Can't hide our shame from the Holy One,
Only God can clothe our sin,
With garments pure that come from Him!

[Bridge]
Skin of animals God would give,
Blood was shed that they might live,
Picture of the coming day,
When the Lamb would take sin away.

[Outro]
Our covering comes... from the blood of the One...
