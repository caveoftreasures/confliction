SONG 80: "Adams 930 Years (Alt)"

[Intro]

[Verse 1]
Nine hundred thirty years he lived,
All that God had chosen to give,
Watching generations grow,
Telling them all they need to know.

[Verse 2]
He saw his sons and grandsons rise,
Under the ever-changing skies,
Witnessed Cain's curse and Abel's death,
Drew so many final breaths.

[Chorus]
Adam lived nine hundred thirty years,
Through all the laughter and the tears,
Teaching the children of the truth,
That they had lost in Eden's youth!

[Verse 3]
Every day he felt the weight,
Of what he'd done, his fallen state,
But still he held to God's own word,
Every promise that he'd heard.

[Verse 4]
When at last his days were done,
Setting like the evening sun,
He passed the story to his seed,
To carry on the righteous deed.

[Chorus]
Adam lived nine hundred thirty years,
Through all the laughter and the tears,
Teaching the children of the truth,
That they had lost in Eden's youth!

[Bridge]
He didn't live to see the flood,
Or see the Savior's precious blood,
But his faith looked forward still,
To the One who would fulfill.

[Outro]
930 years... but eternity appears...
