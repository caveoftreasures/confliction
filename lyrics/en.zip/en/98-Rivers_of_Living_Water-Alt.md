SONG 98: "Rivers of Living Water (Alt)"

[Intro]

[Verse 1]
In the garden rivers flowed,
Pishon, Gihon, all they showed,
Tigris, Euphrates, fresh and clean,
The purest water ever seen.

[Verse 2]
But outside the garden gate,
A different water was their fate,
They thirsted under scorching sun,
Until God's provision came.

[Chorus]
Rivers of living water flow,
From the throne of God below,
Drink deep and never thirst again,
Living water for all men!

[Verse 3]
The woman at the well was told,
"Drink this water, never grow old,
It will spring up unto life,
Ending all your pain and strife."

[Verse 4]
From the Savior's side they poured,
Blood and water from the Lord,
Living streams for all who drink,
Pulled back from the final brink.

[Chorus]
Rivers of living water flow,
From the throne of God below,
Drink deep and never thirst again,
Living water for all men!

[Bridge]
In the city yet to come,
Where the living waters run,
We'll drink freely, fully satisfied,
Forever by the Savior's side.

[Outro]
Living water flows... eternally it flows...
