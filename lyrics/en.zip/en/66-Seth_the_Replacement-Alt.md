SONG 66: "Seth the Replacement (Alt)"

[Intro]

[Verse 1]
Abel died by brother's hand,
Cain was cursed throughout the land,
But God gave Adam another son,
A new beginning had begun.

[Verse 2]
Seth was born to carry on,
The righteous line after Abel gone,
Through his seed the promise flowed,
Down to where the Savior showed.

[Chorus]
Seth, the replacement, God provided,
When hope seemed lost and faith was divided,
Through his line salvation came,
Glory to the Father's name!

[Verse 3]
Eve said, "God has given me,
Another seed, a legacy,
To replace the one who died,
By his murderous brother's pride."

[Verse 4]
From Seth to Noah, on and on,
The faithful line would carry on,
Through the flood to Abraham's day,
All the way to the Messiah's stay.

[Chorus]
Seth, the replacement, God provided,
When hope seemed lost and faith was divided,
Through his line salvation came,
Glory to the Father's name!

[Bridge]
When one door closes, God opens more,
Always faithful to restore,
What the enemy meant to end,
God can always comprehend.

[Outro]
The line continues... through Seth it continues...
