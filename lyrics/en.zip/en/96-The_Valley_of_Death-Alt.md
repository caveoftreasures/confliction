SONG 96: "The Valley of Death (Alt)"

[Intro]

[Verse 1]
Though I walk through the valley deep,
Where the shadows ever creep,
I will not fear, I'm not alone,
God has claimed me as His own.

[Verse 2]
Adam walked this valley too,
Didn't know what he should do,
But God's rod and staff were there,
Evidence of loving care.

[Chorus]
The valley of death holds no more fear,
For my Shepherd walks with me here,
His presence lights the darkest night,
Guides my steps from wrong to right!

[Verse 3]
Satan lurked in every shade,
Trying to make them afraid,
But the One who walked with them,
Was greater than the enemy's condemn.

[Verse 4]
Death will come for everyone,
But it's not where life is done,
On the other side there waits,
Paradise beyond the gates.

[Chorus]
The valley of death holds no more fear,
For my Shepherd walks with me here,
His presence lights the darkest night,
Guides my steps from wrong to right!

[Bridge]
"O death where is your sting?
O grave where is your ring?"
The Savior conquered both that day,
And showed us the only way.

[Outro]
Through the valley... to the mountaintop...
