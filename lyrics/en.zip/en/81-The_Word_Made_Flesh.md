SONG 81: "The Word Made Flesh"

[Intro]

[Verse 1]
The Word that spoke creation true,
The Word that raised Adam anew,
This Word would one day take on skin,
And dwell with fallen men of sin.

[Verse 2]
"I will send My Word to you,
After five and half days through,
He will save you and your seed,
Meet your every single need."

[Chorus]
The Word made flesh will come to dwell,
Among us all, Emmanuel,
The promise spoken from the start,
Will finally fill every heart!

[Verse 3]
From the garden to the stable,
God was faithful, God was able,
To fulfill what He had said,
Through the living, not the dead.

[Verse 4]
The Word walked on the dusty road,
The Word carried the heavy load,
The Word died upon the tree,
The Word rose to set us free.

[Chorus]
The Word made flesh will come to dwell,
Among us all, Emmanuel,
The promise spoken from the start,
Will finally fill every heart!

[Bridge]
What Adam lost, the Word restored,
Everything that we deplored,
Paradise regained through grace,
When we see Him face to face.

[Outro]
The Word became flesh... and dwelt among us...
