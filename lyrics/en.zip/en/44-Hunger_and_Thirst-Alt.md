SONG 44: "Hunger and Thirst (Alt)"

[Intro]

[Verse 1]
In the garden they never ate,
Heavenly food was on their plate,
Now their stomachs growled with pain,
Bodies crying out in vain.

[Verse 2]
Forty-three days without a bite,
Their flesh withered, no more might,
But still they prayed and still they sought,
The One who all creation brought.

[Chorus]
Hunger and thirst in our bodies cry,
But only God can satisfy,
More than bread and more than wine,
We need the food that is divine!

[Verse 3]
God had pity, saw their state,
Would not leave them to their fate,
Figs and dates and wheat to eat,
Water flowing pure and sweet.

[Verse 4]
"This is not like garden food,
But it will sustain your mood,
Eat and drink and carry on,
Till the night has turned to dawn."

[Chorus]
Hunger and thirst in our bodies cry,
But only God can satisfy,
More than bread and more than wine,
We need the food that is divine!

[Bridge]
"Blessed are those who hunger so,
For righteousness their hearts will know,
They shall be filled," the promise true,
God will satisfy each one of you.

[Outro]
Hunger for Him... thirst for righteousness...
