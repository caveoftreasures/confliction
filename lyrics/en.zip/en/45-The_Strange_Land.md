SONG 45: "The Strange Land"

[Intro]

[Verse 1]
This strange land, this foreign soil,
Full of rocks and daily toil,
Not like Eden's perfect ground,
Thorns and thistles all around.

[Verse 2]
Adam fell upon his face,
Lost and scared in this harsh place,
"How can we survive out here?
Everything fills us with fear!"

[Chorus]
Strange land beneath our feet,
Foreign earth where sorrow and exile meet,
But God walks with us in this place,
Showing us His saving grace!

[Verse 3]
Eve walked gently on the stone,
Never felt this cold alone,
"What is this ground that scrapes and stings?
So different from heavenly things."

[Verse 4]
But God said, "Walk in this land,
I will hold you by the hand,
Days and years I have decreed,
For you and all your future seed."

[Chorus]
Strange land beneath our feet,
Foreign earth where sorrow and exile meet,
But God walks with us in this place,
Showing us His saving grace!

[Bridge]
Pilgrims and strangers, that's what we are,
Guided by heaven's morning star,
This world is not our final home,
A better land is yet to come.

[Outro]
Strangers in the land... till we reach the promised sand...
