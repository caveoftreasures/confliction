SONG 13: "The Word of God"

[Intro]

[Verse 1]
When they fell before the gate,
Terrified at their new state,
God sent His Word to raise them high,
Would not let His children die.

[Verse 2]
"I ordained on earth," God said,
"Days and years till you are dead,
Walk in it till time is done,
Till I send My promised One."

[Chorus]
The Word of God came down to me,
Lifted me up and set me free,
Same Word that created all,
Came to save me from my fall!

[Verse 3]
"Five and a half days," was the sign,
Five thousand years in the divine,
Then salvation would appear,
Wipe away each fallen tear.

[Verse 4]
Every time they fell in fear,
God's Word came drawing near,
Raised them up and gave them hope,
Gave them strength with which to cope.

[Chorus]
The Word of God came down to me,
Lifted me up and set me free,
Same Word that created all,
Came to save me from my fall!

[Bridge]
That Word would one day take on flesh,
Make all things broken fresh,
The promise whispered from the start,
Would heal every broken heart.

[Outro]
The Word became flesh... and dwelt with us...
