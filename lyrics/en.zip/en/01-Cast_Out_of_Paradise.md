SONG 1: "Cast Out of Paradise"

[Intro]

[Verse 1]
Garden of Eden, third day planted,
East of the world where the sun rises,
Water surrounds it, pure and holy,
Border of heaven, God's own garden.

[Verse 2]
Adam was formed from dust and glory,
Bright nature shining, heaven's image,
Walking with angels, praising always,
No night or day, just endless light.

[Chorus]
Cast out of Paradise, fallen from grace,
Bright nature taken, can't see God's face,
From garden to cave, from glory to dust,
But God made a promise we learned to trust!

[Verse 3]
Eve from his side, bone of his bone,
Together in Eden, never alone,
But the serpent came with words so sweet,
Deception and lies at their feet.

[Verse 4]
One taste of fruit, one moment of sin,
The door to darkness came rushing in,
Their eyes were opened but what did they see?
Nakedness, shame, and mortality.

[Chorus]
Cast out of Paradise, fallen from grace,
Bright nature taken, can't see God's face,
From garden to cave, from glory to dust,
But God made a promise we learned to trust!

[Bridge]
Five days and a half the prophecy told,
Five thousand years before truth unfolds,
A savior would come to restore what was lost,
To pay for their sin at the highest cost.

[Outro]
Paradise lost... but not forever...
