SONG 73: "The Fallen Angels"

[Intro]

[Verse 1]
Once they stood in heaven's light,
Worshipping with all their might,
But pride rose up in Lucifer's heart,
Tore the heavenly host apart.

[Verse 2]
"I will be like the Most High!"
He declared beneath the sky,
But God cast him down below,
With all the angels in his flow.

[Chorus]
Fallen angels roam the earth,
Seeking to destroy all worth,
But their time is running out,
God's own judgment casts them out!

[Verse 3]
Now they plot against the Lord,
Every lie, every discord,
Trying to destroy His plan,
Waging war against each man.

[Verse 4]
But God gives us armor strong,
Power to stand when trials are long,
Greater is He who is in us,
Than all their evil and their fuss.

[Chorus]
Fallen angels roam the earth,
Seeking to destroy all worth,
But their time is running out,
God's own judgment casts them out!

[Bridge]
The lake of fire waits for them,
An eternal dark condemn,
Where they'll never hurt again,
God's justice will be plain.

[Outro]
Their end is coming... the judgment is running...
