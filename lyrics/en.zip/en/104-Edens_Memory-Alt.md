SONG 104: "Edens Memory (Alt)"

[Intro]

[Verse 1]
Sometimes in dreams they'd see it still,
The garden on the holy hill,
Trees of beauty everywhere,
Fragrant blossoms in the air.

[Verse 2]
They'd wake up crying, filled with grief,
Memories too sweet, too brief,
How they longed to walk again,
In that place without the pain.

[Chorus]
Eden's memory never fades,
Though we walk through shadowed glades,
One day we'll return once more,
To Paradise's open door!

[Verse 3]
The sound of God walking near,
In the cool, without a fear,
Communion pure and undefiled,
Before they acted like a child.

[Verse 4]
But memories become a hope,
A reason to endure and cope,
What was will again be found,
On resurrection ground.

[Chorus]
Eden's memory never fades,
Though we walk through shadowed glades,
One day we'll return once more,
To Paradise's open door!

[Bridge]
We're hardwired for Paradise,
That's why nothing here suffice,
Our hearts were made for something more,
A homeland we're waiting for.

[Outro]
Memory becomes hope... hope becomes reality...
