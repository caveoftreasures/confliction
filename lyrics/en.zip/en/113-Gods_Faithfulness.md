SONG 113: "Gods Faithfulness"

[Intro]

[Verse 1]
From the garden to the cave,
God was faithful, came to save,
Never left them on their own,
Always making His love known.

[Verse 2]
Every promise that He made,
Never once would it fade,
Through the darkness and the light,
God was always doing right.

[Chorus]
God's faithfulness endures forever,
His promises He breaks never,
What He says He will do,
He is always faithful and true!

[Verse 3]
When they fell, He picked them up,
When they thirsted, filled their cup,
When they feared, He calmed their soul,
Made the broken sinner whole.

[Verse 4]
Generations come and go,
But His faithfulness still flows,
From Adam down to you and me,
The same yesterday, tomorrow, eternally.

[Chorus]
God's faithfulness endures forever,
His promises He breaks never,
What He says He will do,
He is always faithful and true!

[Bridge]
Great is Your faithfulness, O Lord,
Your mercies never can be stored,
New every morning, fresh each day,
You are our strength along the way.

[Outro]
Faithful forever... our God is faithful...
