SONG 92: "Rest for the Weary (Alt)"

[Intro]

[Verse 1]
Weary from the daily grind,
Bodies broken, troubled mind,
Adam and Eve had no rest,
Always tested, always pressed.

[Verse 2]
But God called them to His side,
Said He would be their guide,
"Come to Me, you heavy laden,
I will give you rest in Canaan."

[Chorus]
Rest for the weary, peace for the soul,
God makes the broken perfectly whole,
Lay down your burdens at His feet,
Find in Him your rest complete!

[Verse 3]
The cave was dark and cold and tight,
But it was their home each night,
And in that darkness, God was there,
Surrounding them with love and care.

[Verse 4]
One day there will be no toil,
No more working cursed soil,
Sabbath rest forevermore,
On that eternal shore.

[Chorus]
Rest for the weary, peace for the soul,
God makes the broken perfectly whole,
Lay down your burdens at His feet,
Find in Him your rest complete!

[Bridge]
There remains a rest for all,
Who answer God's own call,
A Sabbath celebration grand,
In the palm of His great hand.

[Outro]
Rest is coming... eternal rest is coming...
