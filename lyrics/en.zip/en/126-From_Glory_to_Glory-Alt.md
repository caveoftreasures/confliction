SONG 126: "From Glory to Glory (Alt)"

[Intro]

[Verse 1]
Adam started clothed in light,
Radiant and burning bright,
Then he fell and lost it all,
Glory stripped by sin's dark call.

[Verse 2]
But God's plan from the very start,
Was to change the broken heart,
Little by little, day by day,
Transforming us along the way.

[Chorus]
From glory to glory we are changed,
By the Spirit, rearranged,
More like Jesus every day,
As we follow in His way!

[Verse 3]
Like a mirror reflecting light,
We behold the Lord so bright,
And as we gaze upon His face,
We're transformed by His grace.

[Verse 4]
The glory Adam lost in sin,
The Spirit is restoring within,
A foretaste of what's yet to come,
When we finally reach our home.

[Chorus]
From glory to glory we are changed,
By the Spirit, rearranged,
More like Jesus every day,
As we follow in His way!

[Bridge]
When we see Him as He is,
We will be exactly His,
Complete transformation that day,
Glory forever and a day.

[Outro]
Transforming, changing... glory to glory...
