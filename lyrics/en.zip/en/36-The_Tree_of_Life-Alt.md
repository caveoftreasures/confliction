SONG 36: "The Tree of Life (Alt)"

[Intro]

[Verse 1]
In the midst of the garden fair,
Two trees stood beyond compare,
One brought knowledge, one brought life,
One brought blessing, one brought strife.

[Verse 2]
They ate from knowledge, wanting more,
Divinity they were looking for,
But the tree of life was set apart,
Protected from their broken heart.

[Chorus]
Tree of Life, we long for you,
Barred from eating, through and through,
But God will make a way one day,
For the faithful to eat and stay!

[Verse 3]
Cherub with a flaming sword,
Guards the tree by God's own word,
No fallen hand can reach its fruit,
No corrupt root can take its shoot.

[Verse 4]
But Satan promised, "I'll give you some,
From the tree of life I'll bring you one!"
Lies upon lies, deception deep,
He cannot give what he cannot keep.

[Chorus]
Tree of Life, we long for you,
Barred from eating, through and through,
But God will make a way one day,
For the faithful to eat and stay!

[Bridge]
In the end, the promise stands,
Tree of Life with healing hands,
For the nations, leaves that cure,
For the righteous, life secure.

[Outro]
The Tree of Life... awaits in Paradise...
