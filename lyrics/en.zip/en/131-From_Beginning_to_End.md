SONG 131: "From Beginning to End"

[Intro]

[Verse 1]
In the beginning, God created,
All things new, nothing belated,
Adam and Eve in Paradise,
Before the fall, before the price.

[Verse 2]
Then came sin and death and pain,
But God had planned redemption's gain,
Through the ages, through the years,
Through the blood and through the tears.

[Chorus]
From beginning to end, God's plan unfolds,
More beautiful than can be told,
Alpha and Omega, First and Last,
Connecting the future with the past!

[Verse 3]
Prophets spoke of One to come,
The Father's own and only Son,
In the fullness of the time,
He stepped down from the divine.

[Verse 4]
Cross and grave and resurrection,
Sin's defeat, complete perfection,
Now we wait for Him to come,
To bring His children safely home.

[Chorus]
From beginning to end, God's plan unfolds,
More beautiful than can be told,
Alpha and Omega, First and Last,
Connecting the future with the past!

[Bridge]
What started in a garden fair,
Will end with God everywhere,
New heavens and new earth reborn,
On that eternal morn.

[Outro]
From the beginning to the end... He is faithful, our God and friend...
