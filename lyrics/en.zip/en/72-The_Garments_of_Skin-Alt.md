SONG 72: "The Garments of Skin (Alt)"

[Intro]

[Verse 1]
Fig leaves couldn't do the job,
They fell apart and made them sob,
But God provided something more,
Garments of skin they would wear for sure.

[Verse 2]
Animals died to cover shame,
Blood was spilled to take the blame,
This was God's own gracious gift,
To give His children a spiritual lift.

[Chorus]
Garments of skin to cover our sin,
God's own provision lets us begin,
We can't clothe ourselves, we need His grace,
To stand before Him face to face!

[Verse 3]
These were not just earthly clothes,
But what they meant, everybody knows,
A foreshadow of the day to come,
When the Lamb of God would become one.

[Verse 4]
Wrapped in righteousness divine,
Clothed in garments all so fine,
Not by works that we have done,
But by the blood of God's own Son.

[Chorus]
Garments of skin to cover our sin,
God's own provision lets us begin,
We can't clothe ourselves, we need His grace,
To stand before Him face to face!

[Bridge]
The robes we wear are stained by blood,
Washed clean by mercy's mighty flood,
White as snow, pure as light,
Ready to meet the King of might.

[Outro]
Clothed in grace... we see His face...
