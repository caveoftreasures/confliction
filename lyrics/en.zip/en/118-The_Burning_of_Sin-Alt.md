SONG 118: "The Burning of Sin (Alt)"

[Intro]

[Verse 1]
Like gold refined in fire's blaze,
God works through these trial days,
Burning off what doesn't belong,
Making weak things become strong.

[Verse 2]
Adam walked through flames of test,
God burning out all but the best,
Every trial had a purpose true,
Making old things new.

[Chorus]
The burning of sin purifies the soul,
Through the fire God makes us whole,
What seems like destruction's hand,
Is God's refining to help us stand!

[Verse 3]
Satan meant it all for harm,
But God extended His strong arm,
Turned the fire into a gift,
To save and heal and lift.

[Verse 4]
When you walk through trials hot,
Remember you are never forgot,
God is with you in the flame,
Calling you by your own name.

[Chorus]
The burning of sin purifies the soul,
Through the fire God makes us whole,
What seems like destruction's hand,
Is God's refining to help us stand!

[Bridge]
Three Hebrew boys in fire stood,
And found the fourth was God so good,
Not a hair upon them burned,
A lesson that we've all learned.

[Outro]
Through the fire... comes the gold...
