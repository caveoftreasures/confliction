SONG 7: "The Serpents Curse"

[Intro]

[Verse 1]
Serpent was beautiful, most exalted beast,
From best food to dust he would feast,
Satan entered and used him as a tool,
To make God's children play the fool.

[Verse 2]
Now he crawls upon his belly low,
Slippery and mean wherever he goes,
From beautiful abode to living in dust,
Venomous and cursed, lost all trust.

[Chorus]
Serpent cursed, crawling on the ground,
Satan's tool, your judgment is sound,
From exalted beast to lowest of all,
Because of your part in humanity's fall!

[Verse 3]
Blood-red eyes and swollen head,
Standing on its tail, wishing them dead,
Ran at Eve with murder in sight,
Adam grabbed its tail to fight.

[Verse 4]
"Because of you I'm slippery!" it cried,
But God sent an angel to turn the tide,
Struck the serpent dumb that very day,
Wind carried it far, far away.

[Chorus]
Serpent cursed, crawling on the ground,
Satan's tool, your judgment is sound,
From exalted beast to lowest of all,
Because of your part in humanity's fall!

[Bridge]
Where once all beasts came to drink,
Now they flee, they will not link,
With the cursed one cast aside,
Symbol of the enemy's pride.

[Outro]
Cursed to crawl... till the end of all...
