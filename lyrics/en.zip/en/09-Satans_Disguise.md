SONG 9: "Satans Disguise"

[Intro]

[Verse 1]
Clad in garments bright as day,
Satan came to lead astray,
Staff of light held in his hand,
Looking holy, looking grand.

[Verse 2]
"Peace be unto you," he said,
"God has sent me in His stead,
Come with me to paradise,
I'll give you all, pay no price."

[Chorus]
Satan transforms into light,
Making wrong appear as right,
But God's people recognize,
The deceiver in disguise!

[Verse 3]
Eve was fooled, came out the cave,
Thinking this angel came to save,
But Adam saw through the pretense,
Knew this wasn't heaven-sent.

[Verse 4]
"God sent you?" Adam cried in grief,
"No! You're Satan, father of lies and thief!
You promised divinity before,
Left us broken, wanting more!"

[Chorus]
Satan transforms into light,
Making wrong appear as right,
But God's people recognize,
The deceiver in disguise!

[Bridge]
Eighty times he tried to trick,
Every scheme would make them sick,
But God was faithful, always near,
Driving Satan back with fear.

[Outro]
Test every spirit... know the truth...
