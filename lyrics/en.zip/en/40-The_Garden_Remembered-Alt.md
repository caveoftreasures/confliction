SONG 40: "The Garden Remembered (Alt)"

[Intro]

[Verse 1]
Adam looked back at the garden gate,
Remembering what was once his state,
Trees so beautiful and tall,
Before sin made him fall.

[Verse 2]
"What is this cave to paradise?
This darkness to the light so nice?
What is this rock to those sweet groves?
This exile from the place I loved?"

[Chorus]
We remember Eden's song,
All the beauty now gone wrong,
But we hold to God's true word,
Restoration will be heard!

[Verse 3]
Eve remembered walking free,
No pain, no death, just purity,
Now with sorrow and with tears,
They faced a future full of fears.

[Verse 4]
"Our eyes once saw the angels bright,
Praising God with all their might,
Now flesh has covered what we knew,
Everything looks different, new."

[Chorus]
We remember Eden's song,
All the beauty now gone wrong,
But we hold to God's true word,
Restoration will be heard!

[Bridge]
The smell of the trees would drift their way,
When the north wind came to play,
But God kept them from that sweet scent,
Lest they forget why they were sent.

[Outro]
Paradise lost... but not forgotten...
