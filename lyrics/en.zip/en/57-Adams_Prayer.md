SONG 57: "Adams Prayer"

[Intro]

[Verse 1]
"O my Lord, O my God,
Creator of the heavens broad,
You made me from the dust of earth,
Breathed into me, gave me birth."

[Verse 2]
"At the third hour You brought me in,
Before I knew of death or sin,
Named the creatures, one by one,
Under the bright and glorious sun."

[Chorus]
Adam's prayer rises up on high,
To the Creator of the sky,
"Hear my cry, O Lord, I pray,
Lead me back to perfect day!"

[Verse 3]
"Now I'm broken, weak and low,
Nothing like the life I'd know,
Beasts that once bowed to my name,
Now look upon me with disdain."

[Verse 4]
"But I trust in Your great Word,
Every promise that I've heard,
You will send the One to save,
Lift me from this living grave."

[Chorus]
Adam's prayer rises up on high,
To the Creator of the sky,
"Hear my cry, O Lord, I pray,
Lead me back to perfect day!"

[Bridge]
God heard Adam's every plea,
Promised him that he would see,
Salvation coming in due time,
To restore the paradigm.

[Outro]
The Father hears... every cry, every tear...
