SONG 70: "Morning Comes (Alt)"

[Intro]

[Verse 1]
All through the night they cried in fear,
Thinking death was drawing near,
But God said, "Wait and see the dawn,
A new day comes before too long."

[Verse 2]
Twelve hours passed and light appeared,
Everything they had once feared,
Was swallowed up in morning's glow,
Hope returned from high to low.

[Chorus]
Morning comes after the night,
Darkness gives way to the light,
Hold on through the midnight hour,
Dawn reveals God's saving power!

[Verse 3]
Every trial has an end,
God's own mercy will descend,
What seems eternal in the dark,
Is just a temporary mark.

[Verse 4]
Adam learned this truth so deep,
Even when he could not sleep,
After the hardest, longest night,
Morning brings the healing light.

[Chorus]
Morning comes after the night,
Darkness gives way to the light,
Hold on through the midnight hour,
Dawn reveals God's saving power!

[Bridge]
Weeping lasts for just a night,
But joy comes with morning's sight,
The sun will rise on sorrows old,
And turn them into stories told.

[Outro]
Morning is coming... hold on, morning is coming...
