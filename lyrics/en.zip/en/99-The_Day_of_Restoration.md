SONG 99: "The Day of Restoration"

[Intro]

[Verse 1]
A day is coming, the prophets say,
When all sorrow fades away,
Every tear will be wiped dry,
Under new and perfect sky.

[Verse 2]
All that Adam lost will be restored,
By the grace of the risen Lord,
Bodies new that never die,
In the place beyond the sky.

[Chorus]
The day of restoration is near,
When the Savior will appear,
All things new, the old is gone,
A new creation has begun!

[Verse 3]
No more death or pain or night,
Only everlasting light,
The curse removed forever more,
This is what we're waiting for.

[Verse 4]
Animals at peace will play,
Lion and lamb, night and day,
The way it was before the fall,
Restored and given back to all.

[Chorus]
The day of restoration is near,
When the Savior will appear,
All things new, the old is gone,
A new creation has begun!

[Bridge]
"Behold," He says, "I make all new,"
Everything refreshed and true,
What was broken now is whole,
Perfect healing for each soul.

[Outro]
Restoration is coming... hold on, it's coming...
