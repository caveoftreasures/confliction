SONG 77: "East of Eden"

[Intro]

[Verse 1]
East of Eden, that's where we stand,
In this rough and broken land,
Paradise is behind the gate,
Cherubim are guarding fate.

[Verse 2]
Thorns and thistles, sweat and tears,
This is life for all our years,
Working hard just to survive,
Barely keeping hope alive.

[Chorus]
East of Eden, we must go on,
Even though Paradise is gone,
God is with us in this place,
Showing us His saving grace!

[Verse 3]
But God didn't leave us alone,
He has made His presence known,
Speaking through His holy Word,
Every prayer He has heard.

[Verse 4]
One day we'll return again,
To a garden without pain,
New Jerusalem coming down,
Where the redeemed receive their crown.

[Chorus]
East of Eden, we must go on,
Even though Paradise is gone,
God is with us in this place,
Showing us His saving grace!

[Bridge]
The way back in is not behind,
But up ahead if we will find,
The narrow path that leads to life,
Through the Savior's sacrifice.

[Outro]
East of Eden now... but Heaven awaits somehow...
