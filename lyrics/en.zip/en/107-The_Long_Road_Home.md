SONG 107: "The Long Road Home"

[Intro]

[Verse 1]
From the garden they began,
The long journey for every man,
Walking east into the sun,
Not knowing when they'd be done.

[Verse 2]
Generation after generation,
Walking through each situation,
Eyes fixed on the distant shore,
Where they'd live forevermore.

[Chorus]
The long road home is winding still,
Through every valley, every hill,
But we're getting closer every day,
To the end of the winding way!

[Verse 3]
Abraham left his father's land,
Trusting in God's guiding hand,
Looking for a city bright,
Where everything would be right.

[Verse 4]
Moses led them through the sea,
Toward the land where they'd be free,
Pilgrimage is what we know,
Till we reach our home below.

[Chorus]
The long road home is winding still,
Through every valley, every hill,
But we're getting closer every day,
To the end of the winding way!

[Bridge]
We're strangers here, just passing through,
Heaven's home is coming into view,
Keep walking, don't lose heart,
We'll finish what we start.

[Outro]
Almost home... we're almost home...
