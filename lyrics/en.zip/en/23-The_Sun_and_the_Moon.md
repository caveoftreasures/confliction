SONG 23: "The Sun and the Moon"

[Intro]

[Verse 1]
Adam never saw the sun before,
Heat upon his flesh he'd never bore,
Thought that God was plaguing him again,
For all his sin and all his pain.

[Verse 2]
But God spoke clear, "This is not Me,
The sun I made to give life to thee,
By day it shines to warm the earth,
I am the One who knows your worth."

[Chorus]
Sun by day and moon by night,
Created things, they're not the Light,
But they point to the One above,
Who rules them all with power and love!

[Verse 3]
When darkness came with evening time,
They feared again the paradigm,
But God assured them, "Have no fear,
After twelve hours, dawn is near."

[Verse 4]
This pattern set for all their days,
Teaching them in countless ways,
That after darkness, light will come,
Hope remains till all is done.

[Chorus]
Sun by day and moon by night,
Created things, they're not the Light,
But they point to the One above,
Who rules them all with power and love!

[Bridge]
The greater light to rule the day,
The lesser light to guide our way,
Both bowing to the Creator's will,
Who speaks and they obey Him still.

[Outro]
Day and night... until the eternal Light...
