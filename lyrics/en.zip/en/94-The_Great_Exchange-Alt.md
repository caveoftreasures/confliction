SONG 94: "The Great Exchange (Alt)"

[Intro]

[Verse 1]
Adam traded glory for shame,
A bright nature for curse and blame,
Paradise for rocky cave,
Eternal life for a dusty grave.

[Verse 2]
But God made another trade,
Through the sacrifice He made,
Taking our sin upon His back,
Giving us all that we lack.

[Chorus]
The great exchange, our sin for His grace,
Our shame for glory, face to face,
He took our curse and gave us life,
Peace instead of endless strife!

[Verse 3]
Our righteousness was filthy rags,
Like empty, broken, useless bags,
But He gave us robes of white,
Pure and clean in heaven's light.

[Verse 4]
Our death was swapped for His life,
Our wounds for His healing knife,
By His stripes we now are whole,
Restored in body and in soul.

[Chorus]
The great exchange, our sin for His grace,
Our shame for glory, face to face,
He took our curse and gave us life,
Peace instead of endless strife!

[Bridge]
He who knew no sin became,
Covered in our guilt and shame,
So that we could stand complete,
Righteous at the mercy seat.

[Outro]
The greatest trade ever made... grace for sin...
