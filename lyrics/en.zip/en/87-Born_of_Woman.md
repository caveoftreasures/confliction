SONG 87: "Born of Woman"

[Intro]

[Verse 1]
God spoke to the serpent's face,
Pronounced the judgment and the grace,
"The woman's seed will crush your head,
Though you will bruise His heel," He said.

[Verse 2]
From Eve would come the righteous line,
Through Seth and Noah, all in time,
Down to Mary, pure and true,
Who bore the Son that God would use.

[Chorus]
Born of woman, the Savior comes,
Beating back the devil's drums,
From the garden's darkest day,
To the Light that shows the way!

[Verse 3]
The seed promised from the start,
Would be born in Mary's heart,
Virgin birth, the holy one,
God's eternal, perfect Son.

[Verse 4]
What began with Eve in shame,
Would be redeemed through Mary's fame,
A woman brought the curse so low,
A woman would the Savior show.

[Chorus]
Born of woman, the Savior comes,
Beating back the devil's drums,
From the garden's darkest day,
To the Light that shows the way!

[Bridge]
He took on flesh to die for sin,
To let the broken back in,
Through one woman came the fall,
Through another, life for all.

[Outro]
Born of woman... the Promised One...
