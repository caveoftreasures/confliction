SONG 119: "Children of Adam"

[Intro]

[Verse 1]
Every human ever born,
Every child upon this morn,
Traces back to one same pair,
Adam and Eve who once were there.

[Verse 2]
One blood flows through every vein,
One sorrow, one common pain,
All have sinned and fallen short,
All need the grace the Savior brought.

[Chorus]
Children of Adam, that's what we are,
Fallen and broken, near and far,
But through Christ we are reborn,
No longer bound by our old worn!

[Verse 3]
Doesn't matter who you are,
Rich or poor, near or far,
Royal blood or common clay,
All trace back to that first day.

[Verse 4]
And now through faith in God's own Son,
We become the chosen one,
Children of the second Adam,
New creation, free from phantom.

[Chorus]
Children of Adam, that's what we are,
Fallen and broken, near and far,
But through Christ we are reborn,
No longer bound by our old worn!

[Bridge]
From every nation, tribe and tongue,
The same old song has always been sung,
We're all family, one in blood,
Connected by the grace of God.

[Outro]
One family... in Adam, one family in Christ...
