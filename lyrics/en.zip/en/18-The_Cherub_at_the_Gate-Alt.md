SONG 18: "The Cherub at the Gate (Alt)"

[Intro]

[Verse 1]
At the gate a cherub stood,
Flashing sword of fire and blood,
Guarding Eden's sacred door,
Where they could not enter more.

[Verse 2]
Adam saw him, fell in fear,
Thought his death was drawing near,
Trembling at the angel's might,
Terrified at the burning sight.

[Chorus]
Cherub at the gate with sword aflame,
Guarding Eden since we fell in shame,
Can't go back to what we knew,
Must press forward, born anew!

[Verse 3]
But the cherub prayed to God above,
Asking for mercy, asking for love,
"What shall I do for these servants of Thine?
They fell before me, give them a sign!"

[Verse 4]
God had pity, showed them grace,
Sent His Word to that very place,
Raised them up from their fallen state,
Love conquers fear at heaven's gate.

[Chorus]
Cherub at the gate with sword aflame,
Guarding Eden since we fell in shame,
Can't go back to what we knew,
Must press forward, born anew!

[Bridge]
One day the way will open wide,
For all who trust in the One who died,
The flaming sword will step aside,
And welcome home the purified.

[Outro]
The gate will open... for those who trust...
