SONG 75: "The Secret of the Cave"

[Intro]

[Verse 1]
Gold and incense, myrrh so sweet,
Treasures laid at Adam's feet,
Brought by angels from above,
Tokens of the Father's love.

[Verse 2]
Hidden in the cave so deep,
Secrets that the ages keep,
These would travel through the years,
Witness to both joy and tears.

[Chorus]
The secret of the cave is told,
Through incense, myrrh, and precious gold,
Gifts for the King who is to come,
The Father's own beloved Son!

[Verse 3]
Wise men from the East would bring,
These same gifts before the King,
Born in Bethlehem's humble stall,
Savior and Lord of all.

[Verse 4]
What started in the Cave of Treasures,
Would fulfill all holy measures,
The circle closes, story complete,
When heaven and earth would finally meet.

[Chorus]
The secret of the cave is told,
Through incense, myrrh, and precious gold,
Gifts for the King who is to come,
The Father's own beloved Son!

[Bridge]
Adam never fully knew,
What these treasures pointed to,
But faith believed in God's great plan,
The redemption of fallen man.

[Outro]
Treasures pointing... to the coming King...
