SONG 42: "The Jordan Flows (Alt)"

[Intro]

[Verse 1]
Jordan river flowing strong,
Adam stood there oh so long,
Water rushing past his frame,
Calling on the Father's name.

[Verse 2]
"Hear me God, forgive my sin,
Cleanse me Lord from outside in,
I will stand here till you speak,
Even though my body's weak."

[Chorus]
The Jordan flows, the Jordan flows,
Where the water of redemption goes,
Standing in the current deep,
Promises the Lord will keep!

[Verse 3]
One day in this very stream,
Another Adam would be seen,
Descending under holy wave,
Coming up, the world to save.

[Verse 4]
The Spirit like a dove would fall,
"This is My Son, beloved of all,"
What started here with Adam's stand,
Would climax in God's saving hand.

[Chorus]
The Jordan flows, the Jordan flows,
Where the water of redemption goes,
Standing in the current deep,
Promises the Lord will keep!

[Bridge]
From the mountains to the sea,
The Jordan speaks of being free,
Cross its waters, you will find,
The promised land of humankind.

[Outro]
Through the Jordan... to the promised land...
