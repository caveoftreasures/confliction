SONG 47: "The Transgression"

[Intro]

[Verse 1]
"Of your own free will you fell,
Chose the path that leads to hell,
Desire for divinity,
Stripped you of your purity."

[Verse 2]
God spoke clearly, truth so plain,
Explained the source of all their pain,
"You wanted to be just like Me,
Now look what you have come to be."

[Chorus]
The transgression weighs heavy on our soul,
Sin has broken what was whole,
But God's mercy covers all,
He lifts us up from where we fall!

[Verse 3]
Adam bowed his head in shame,
Took responsibility and blame,
"Lord, because I sinned a little,
Now my life has become so brittle."

[Verse 4]
"If only you had prayed before,
If only you had knocked that door,
Before you ate the forbidden fruit,
Your path would have borne different fruit."

[Chorus]
The transgression weighs heavy on our soul,
Sin has broken what was whole,
But God's mercy covers all,
He lifts us up from where we fall!

[Bridge]
One transgression, such great cost,
Paradise and glory lost,
But one obedience would restore,
All we were and so much more.

[Outro]
One transgression fell... one obedience will be well...
