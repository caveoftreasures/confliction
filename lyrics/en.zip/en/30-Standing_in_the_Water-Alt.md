SONG 30: "Standing in the Water (Alt)"

[Intro]

[Verse 1]
Adam stood in Jordan's flow,
Forty days he would not go,
Water up to his neck so high,
Crying out to God on high.

[Verse 2]
Eve in Tigris, thirty-five days,
Praying hard in water's maze,
Beseeching God to hear their plea,
Restore them back to what used to be.

[Chorus]
Standing in the water, Lord we pray,
Wash our transgressions all away,
In the current of Your grace,
Show us Lord Your mercy's face!

[Verse 3]
Satan came to Eve one day,
Dressed in light to lead astray,
"God has heard you, come with me!"
But it was a deceptive plea.

[Verse 4]
She left the water, followed him,
Situation looking grim,
But Adam knew it wasn't right,
Saw through Satan's false disguise of light.

[Chorus]
Standing in the water, Lord we pray,
Wash our transgressions all away,
In the current of Your grace,
Show us Lord Your mercy's face!

[Bridge]
Baptism picture in this tale,
Water won't make us prevail,
Only faith in God's true Word,
Can save us from the curse we've incurred.

[Outro]
Through the water... into new life...
