SONG 130: "The Eternal Home (Alt)"

[Intro]

[Verse 1]
Streets of gold and gates of pearl,
A city coming to this world,
New Jerusalem descending,
All the waiting finally ending.

[Verse 2]
No more tears, no more pain,
No more death's destroying reign,
God Himself will wipe each eye,
Under an eternal sky.

[Chorus]
The eternal home is coming down,
Where the redeemed receive their crown,
Every promise finally fulfilled,
As God Himself with us is sealed!

[Verse 3]
Tree of Life on either side,
Of the river, crystal wide,
Twelve fruits for the healing of,
Nations covered by God's love.

[Verse 4]
No need for sun or for moon,
God's own glory fills every room,
And we will dwell there evermore,
On that eternal shore.

[Chorus]
The eternal home is coming down,
Where the redeemed receive their crown,
Every promise finally fulfilled,
As God Himself with us is sealed!

[Bridge]
What Adam lost is now restored,
By the grace of our Lord,
Paradise regained at last,
All the sorrows of the past.

[Outro]
Our eternal home awaits... where love never fades...
