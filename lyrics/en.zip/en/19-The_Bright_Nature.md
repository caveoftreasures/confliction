SONG 19: "The Bright Nature"

[Intro]

[Verse 1]
Once we wore a robe of light,
Shining pure, forever bright,
No darkness touched our holy frame,
We walked in God's eternal flame.

[Verse 2]
Eyes could see what angels saw,
Heaven's glory, without flaw,
Praising God both night and day,
In that bright nature's perfect way.

[Chorus]
We lost our bright nature in the fall,
Traded glory for a mortal call,
But God will clothe us once again,
In garments of light at journey's end!

[Verse 3]
Now our eyes are flesh and bone,
Cannot see what once was shown,
Hearts turned earthly, bodies weak,
Lost the glory we now seek.

[Verse 4]
But the promise still remains,
Through the suffering and the pains,
One will come to give it back,
Restore all that sin made lack.

[Chorus]
We lost our bright nature in the fall,
Traded glory for a mortal call,
But God will clothe us once again,
In garments of light at journey's end!

[Bridge]
That sea of crystal, pure and clear,
Where righteousness will persevere,
Bathing in its holy flow,
Returning to the life we used to know.

[Outro]
The bright nature returns... when the Savior comes...
