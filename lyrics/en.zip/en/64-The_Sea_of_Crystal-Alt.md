SONG 64: "The Sea of Crystal (Alt)"

[Intro]

[Verse 1]
North of the garden, crystal clear,
A sea so pure without a fear,
When a man washed in its flow,
Whiter than snow he would glow.

[Verse 2]
God created it with care,
Knowing Adam would be there,
Future righteous ones would bathe,
In its waters, be remade.

[Chorus]
Sea of crystal, pure and bright,
Washing souls in holy light,
When we reach that final shore,
We'll be clean forevermore!

[Verse 3]
But Adam could not go that way,
God kept him from it every day,
Lest he wash and then forget,
The sin that caused his regret.

[Verse 4]
For now the sea was set apart,
For those with pure and righteous heart,
Who would rise in that last day,
Washed of sin and decay.

[Chorus]
Sea of crystal, pure and bright,
Washing souls in holy light,
When we reach that final shore,
We'll be clean forevermore!

[Bridge]
Like the crystal sea before the throne,
Where God's glory is fully known,
We'll stand there clean and purified,
Forever by the Savior's side.

[Outro]
Crystal waters call... to the righteous all...
