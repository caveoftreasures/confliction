SONG 86: "The Midnight Cry (Alt)"

[Intro]

[Verse 1]
In the darkest hour of night,
When there's no end in sight,
Adam lifted up his voice,
Made his calling, made his choice.

[Verse 2]
"O my Lord, where are You now?
Help me, save me, show me how!
Darkness covers all my way,
Turn this night into day!"

[Chorus]
The midnight cry reaches heaven's throne,
God hears every desperate moan,
In the darkest, deepest night,
He will come and be our light!

[Verse 3]
Eve joined in with tears of pain,
Crying out through the strain,
Together lifting prayers high,
Hoping for God's reply.

[Verse 4]
And the Lord heard every word,
Every whisper, every herd,
Sent His comfort from above,
Wrapped them in His perfect love.

[Chorus]
The midnight cry reaches heaven's throne,
God hears every desperate moan,
In the darkest, deepest night,
He will come and be our light!

[Bridge]
At midnight the bridegroom comes,
When all other hope succumbs,
Those with oil in their lamps,
Will leave these dark and dreary camps.

[Outro]
Cry out at midnight... He's still listening...
