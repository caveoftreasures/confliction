SONG 101: "Fight of Faith"

[Intro]

[Verse 1]
Every day a battle raged,
In this war that God had staged,
Adam fighting for his soul,
Satan trying to take control.

[Verse 2]
With no sword and with no shield,
They refused to ever yield,
Prayer and faith their only weapon,
Trusting God for every blessing.

[Chorus]
Fight the fight of faith today,
Don't let the enemy lead you astray,
Stand firm on the Word of God,
Walk the path the Savior trod!

[Verse 3]
The armor given by the Lord,
Truth and righteousness, the sword,
Shield of faith and helmet strong,
Fighting right against the wrong.

[Verse 4]
We wrestle not with flesh and blood,
But powers trying to flood,
Our minds with lies and fear,
But victory is always near.

[Chorus]
Fight the fight of faith today,
Don't let the enemy lead you astray,
Stand firm on the Word of God,
Walk the path the Savior trod!

[Bridge]
The battle belongs to the Lord,
Victory secured by His word,
Though the fight seems long and hard,
He is standing guard.

[Outro]
Keep fighting... the victory is coming...
