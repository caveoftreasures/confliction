SONG 50: "Cain and Abel (Alt)"

[Intro]

[Verse 1]
Eve bore children, sons of dust,
Cain the first, in whom she'd trust,
Abel came, a shepherd true,
Each one with a different view.

[Verse 2]
Cain brought crops from cursed ground,
Abel's lamb made better sound,
God accepted Abel's gift,
Left Cain's heart with bitter rift.

[Chorus]
Cain and Abel, sons of Eve,
One would kill, one would leave,
Sin crouched at the door that day,
And Cain let it have its way!

[Verse 3]
"Why is your face fallen low?
If you do well, you will know,
But sin is waiting, wants you bad,
You must master all that's sad."

[Verse 4]
But Cain rose up against his brother,
Took his life, hurt his mother,
First blood spilled upon the ground,
The curse went deeper, all around.

[Chorus]
Cain and Abel, sons of Eve,
One would kill, one would leave,
Sin crouched at the door that day,
And Cain let it have its way!

[Bridge]
"Where is Abel?" God called out,
"Am I his keeper?" Cain did shout,
But the blood cried from the earth,
Witness to a brother's worth.

[Outro]
Am I my brother's keeper?... yes, you are...
