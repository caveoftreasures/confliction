SONG 32: "Satans Hosts (Alt)"

[Intro]

[Verse 1]
Satan gathered all his hosts,
Demons came from every coast,
"This Adam stole our kingdom away,
We'll crush him on this very day!"

[Verse 2]
They found a rock, huge and wide,
No hole in it where they could hide,
Hurled it down upon their heads,
Meant to kill them in their beds.

[Chorus]
Satan's hosts come to destroy,
Every weapon they deploy,
But God protects His fallen own,
They shall never fight alone!

[Verse 3]
But as the rock came tumbling down,
God transformed it like a crown,
A shelter formed above their heads,
Shade to cover where they slept.

[Verse 4]
The earth did quake, the mountain shook,
But God was watching, never forsook,
What Satan meant to bring them death,
God turned to life with every breath.

[Chorus]
Satan's hosts come to destroy,
Every weapon they deploy,
But God protects His fallen own,
They shall never fight alone!

[Bridge]
Every scheme the devil tries,
God can overturn his lies,
What was meant for evil ends,
God uses good to transcend.

[Outro]
No weapon formed... against us shall stand...
