SONG 127: "The Overcoming"

[Intro]

[Verse 1]
Eighty times Satan came for them,
Eighty times tried to condemn,
Eighty times God came through,
Making all things new.

[Verse 2]
Every trial they overcame,
By the power of God's name,
Not by their strength alone,
But by grace from heaven's throne.

[Chorus]
We are the overcoming ones,
Through Jesus Christ, God's holy Son,
Greater is He who is in us,
Than all the schemes of the unjust!

[Verse 3]
In this world we'll have our share,
Of tribulation everywhere,
But take heart, the Lord says true,
"I have overcome for you."

[Verse 4]
To him who overcomes is given,
The crown of life from heaven,
White stone with a new name,
Forever freed from sin and shame.

[Chorus]
We are the overcoming ones,
Through Jesus Christ, God's holy Son,
Greater is He who is in us,
Than all the schemes of the unjust!

[Bridge]
They overcame by the blood of the Lamb,
And the word of their testimony grand,
Loved not their lives unto death,
Faithful until their final breath.

[Outro]
Overcomers through Christ... that's who we are...
