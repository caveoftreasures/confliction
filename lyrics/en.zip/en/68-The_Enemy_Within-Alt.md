SONG 68: "The Enemy Within (Alt)"

[Intro]

[Verse 1]
Before they ate the fruit that day,
No darkness led their hearts astray,
Pure in thought and pure in deed,
No selfish want, no greedy need.

[Verse 2]
But now a battle raged inside,
Between the truth and human pride,
Good and evil both they knew,
Constantly fighting, through and through.

[Chorus]
The enemy within us fights,
Struggles in the darkest nights,
But God gives power to prevail,
His faithful children will not fail!

[Verse 3]
"Why do I do what I hate?
Why can't I just set myself straight?"
This cry echoes through the years,
Accompanied by bitter tears.

[Verse 4]
The flesh wars against the soul,
Trying hard to take control,
But the Spirit given from above,
Empowers us with God's great love.

[Chorus]
The enemy within us fights,
Struggles in the darkest nights,
But God gives power to prevail,
His faithful children will not fail!

[Bridge]
One day this battle will be done,
When finally the war is won,
New bodies, free from sin's dark stain,
Never to struggle again.

[Outro]
The war within... until we win...
