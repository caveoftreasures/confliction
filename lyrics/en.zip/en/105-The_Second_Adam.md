SONG 105: "The Second Adam"

[Intro]

[Verse 1]
The first Adam brought us down,
Traded glory for thorns and crown,
One transgression, death for all,
From the highest to the fall.

[Verse 2]
But a second Adam came,
To restore and remove the shame,
One obedience, life for all,
Answering every desperate call.

[Chorus]
The second Adam breaks the curse,
Turns the bad into the reverse,
What was lost is now regained,
Through the blood of the One who reigned!

[Verse 3]
Where Adam failed in the garden green,
Jesus won in Gethsemane's scene,
"Not My will but Yours be done,"
Victory for the Father's Son.

[Verse 4]
Where Adam took what wasn't his,
Jesus gave all that He is,
Where Adam hid in fear and shame,
Jesus took upon Himself our blame.

[Chorus]
The second Adam breaks the curse,
Turns the bad into the reverse,
What was lost is now regained,
Through the blood of the One who reigned!

[Bridge]
In Adam all die, that is true,
But in Christ all are made new,
The last Adam is life-giving Spirit,
When you trust Him, you inherit.

[Outro]
In the first Adam, death... in the second, eternal breath...
