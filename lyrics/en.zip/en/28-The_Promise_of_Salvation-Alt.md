SONG 28: "The Promise of Salvation (Alt)"

[Intro]

[Verse 1]
By the tree where sin began,
God made covenant with man,
"Five and a half days shall pass by,
Five thousand years before you die."

[Verse 2]
When Adam heard these words from God,
He didn't understand what they told,
Thought five days was all he had,
Wept with grief, broken and sad.

[Chorus]
The promise of salvation stands,
Written in the Creator's hands,
Though we fell in sin and shame,
He will come to take the blame!

[Verse 3]
God explained with patient grace,
Years not days would fill that space,
When fulfilled, the Word would come,
Father would send His only Son.

[Verse 4]
Same Word that made them from the dust,
Same Word in which they learned to trust,
Would take on flesh to break the chain,
Would turn their sorrow into gain.

[Chorus]
The promise of salvation stands,
Written in the Creator's hands,
Though we fell in sin and shame,
He will come to take the blame!

[Bridge]
From that tree to another wood,
Where the promise would be understood,
Cross of shame, but also glory,
The end and start of redemption's story.

[Outro]
The promise spoken... will never be broken...
