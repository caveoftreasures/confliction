SONG 54: "The Weeping Tree (Alt)"

[Intro]

[Verse 1]
When Adam passed the tree that day,
The one that led his heart astray,
He saw it withered, changed its form,
No longer beautiful and warm.

[Verse 2]
The tree that once was bright and fair,
Now stood in desolation there,
God had changed its very frame,
A monument to sin and shame.

[Chorus]
The weeping tree stands alone,
Where sin was sown and seeds were thrown,
But one day on another tree,
A Savior hung to set us free!

[Verse 3]
Adam trembled, fell to ground,
Before that tree he'd once been bound,
This was where it all began,
The downward fall of mortal man.

[Verse 4]
God lifted him up from his fear,
Made His covenant loud and clear,
Though the tree had brought such pain,
Greater glory would be gained.

[Chorus]
The weeping tree stands alone,
Where sin was sown and seeds were thrown,
But one day on another tree,
A Savior hung to set us free!

[Bridge]
Tree of knowledge, tree of shame,
Tree of the Cross, a different name,
What killed us once would be the way,
God would bring us back one day.

[Outro]
From the tree of death... to the tree of life...
