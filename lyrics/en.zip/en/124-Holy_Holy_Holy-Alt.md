SONG 124: "Holy Holy Holy (Alt)"

[Intro]

[Verse 1]
In the garden they could see,
What true holiness could be,
God so pure, so set apart,
Perfect in mind and heart.

[Verse 2]
When they sinned, they understood,
They had lost what was so good,
Holiness they could not claim,
Now just sinners, full of shame.

[Chorus]
Holy, holy, holy is the Lord,
Worthy of all praise and to be adored,
Seraphim cry out His name,
Holy, holy, ever the same!

[Verse 3]
The cherub at the gate so bright,
Reflected heaven's holy light,
Adam trembled at the sight,
Knowing he had lost the right.

[Verse 4]
But the Holy One came down,
Laid aside His royal crown,
Took our sin upon His frame,
So we could bear His holy name.

[Chorus]
Holy, holy, holy is the Lord,
Worthy of all praise and to be adored,
Seraphim cry out His name,
Holy, holy, ever the same!

[Bridge]
We are made holy through His blood,
Washed and cleansed in mercy's flood,
Robed in righteousness divine,
Holy because of His design.

[Outro]
Holy is the Lord... our God is holy...
