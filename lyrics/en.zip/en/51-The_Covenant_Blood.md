SONG 51: "The Covenant Blood"

[Intro]

[Verse 1]
God made garments for their skin,
To cover up the shame of sin,
Animals had to die that day,
Blood was shed to pave the way.

[Verse 2]
This was not the final act,
Just a preview, just a fact,
Pointing to a greater Lamb,
The holy, spotless great I Am.

[Chorus]
Covenant blood was spilled that day,
To cover sin and light the way,
From Eden's gate to Calvary's hill,
Blood would flow, the promise fulfill!

[Verse 3]
Without blood there's no remission,
This has always been the mission,
Life for life, the great exchange,
All throughout the Savior's range.

[Verse 4]
Adam watched the creature die,
Saw the cost in its dim eye,
Understood in part that day,
What it took to wash sin away.

[Chorus]
Covenant blood was spilled that day,
To cover sin and light the way,
From Eden's gate to Calvary's hill,
Blood would flow, the promise fulfill!

[Bridge]
From Abel's lamb to the Passover night,
From temple courts to the cross of light,
One thread of blood runs through it all,
Answering humanity's desperate call.

[Outro]
The blood covers... the blood redeems...
