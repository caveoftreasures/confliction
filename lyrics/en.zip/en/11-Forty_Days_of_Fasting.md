SONG 11: "Forty Days of Fasting"

[Intro]

[Verse 1]
Forty days without bread or water,
Adam and Eve, son and daughter,
Standing in prayer, day and night,
Seeking God with all their might.

[Verse 2]
Bodies withered, strength was gone,
But still they prayed from dusk to dawn,
"Forgive us Lord, our transgression,
Hear our humble confession."

[Chorus]
Forty days we fast and pray,
Forty nights we seek Your way,
Weak in body, strong in soul,
Only God can make us whole!

[Verse 3]
Eve stood in the water deep,
Thirty-five days she would keep,
Adam in the Jordan stood,
Seeking God as best he could.

[Verse 4]
Satan tried to break their will,
Disguised as angels, smooth and still,
But they pressed on through the test,
Finding in their weakness, rest.

[Chorus]
Forty days we fast and pray,
Forty nights we seek Your way,
Weak in body, strong in soul,
Only God can make us whole!

[Bridge]
When at last the days were done,
God sent mercy like the sun,
Raised them up from death's dark door,
Promised them forevermore.

[Outro]
Through fasting we find... what we left behind...
