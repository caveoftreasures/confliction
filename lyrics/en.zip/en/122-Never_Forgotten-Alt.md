SONG 122: "Never Forgotten (Alt)"

[Intro]

[Verse 1]
Even when they thought He'd gone,
When they felt so all alone,
God had not forgotten them,
His care would never end.

[Verse 2]
In the darkness of the cave,
He remembered those He'd save,
Their names written on His hand,
Footsteps marked upon the sand.

[Chorus]
Never forgotten, always on His mind,
God's love is faithful, one of a kind,
He sees your tears, He knows your pain,
His promises remain!

[Verse 3]
"Can a mother forget her child?
Even then I'm not beguiled,
I will never forget you,"
This is what the Lord says, true.

[Verse 4]
Before you call, He answers still,
Working out His perfect will,
Not one sparrow falls alone,
Every hair upon your head is known.

[Chorus]
Never forgotten, always on His mind,
God's love is faithful, one of a kind,
He sees your tears, He knows your pain,
His promises remain!

[Bridge]
He who began a work in you,
Will finish what He set out to do,
Faithful is the One who calls,
He never, ever lets you fall.

[Outro]
You're never forgotten... never alone...
