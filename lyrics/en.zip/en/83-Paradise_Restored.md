SONG 83: "Paradise Restored"

[Intro]

[Verse 1]
No more curse upon the ground,
No more sorrow all around,
Paradise will be restored,
When we stand before the Lord.

[Verse 2]
The tree of life will bloom again,
For the children freed from sin,
Its leaves will heal the nations whole,
Restore each wounded soul.

[Chorus]
Paradise restored, the garden renewed,
All that was lost, will be reviewed,
What Adam lost, Christ has regained,
Forever pure, forever unstained!

[Verse 3]
The river of life will freely flow,
Crystal clear from high to low,
And we will drink and never thirst,
The last made first, the first made first.

[Verse 4]
No more night, no need for sun,
God's own glory, second to none,
Will light the city all the days,
Eternity of praise.

[Chorus]
Paradise restored, the garden renewed,
All that was lost, will be reviewed,
What Adam lost, Christ has regained,
Forever pure, forever unstained!

[Bridge]
The cherubim will step aside,
No more need for us to hide,
The way is open, the door is wide,
For all who trust in Christ who died.

[Outro]
Paradise is coming... we're going home...
