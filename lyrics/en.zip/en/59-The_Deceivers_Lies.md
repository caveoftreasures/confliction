SONG 59: "The Deceivers Lies"

[Intro]

[Verse 1]
"I'll give you divinity!" he said,
"You'll be like God!" he misled,
"Your eyes will open, you will know,
Everything from high to low."

[Verse 2]
But what he gave was not divine,
Just knowledge of a broken line,
They knew good but now knew evil,
Trapped by the ancient serpent devil.

[Chorus]
The deceiver lies through his teeth,
Promising gold, delivering grief,
Don't believe what Satan sells,
He's leading you straight to hell!

[Verse 3]
"I'll make you bright, I'll make you shine!"
But every promise was malign,
Every offer was a trap,
Every gift was just a cap.

[Verse 4]
Eighty times he came their way,
Eighty times in bright array,
But God exposed him every time,
Revealed his truth, revealed his crime.

[Chorus]
The deceiver lies through his teeth,
Promising gold, delivering grief,
Don't believe what Satan sells,
He's leading you straight to hell!

[Bridge]
He has no kingdom left to give,
No power to help you truly live,
Just empty words and broken dreams,
Nothing is ever what it seems.

[Outro]
The father of lies... will meet his demise...
