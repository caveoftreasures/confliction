SONG 115: "Walking with God"

[Intro]

[Verse 1]
In the garden cool of day,
God would come and walk their way,
Communion pure without a care,
Creator and created there.

[Verse 2]
Sin broke that fellowship sweet,
Sent them hiding at His feet,
Afraid to hear His gentle voice,
Ashamed of their rebellious choice.

[Chorus]
Walking with God is what we were made for,
Communion with Him forevermore,
Though sin broke us for a while,
He restores us with His smile!

[Verse 3]
But even outside Eden's gate,
God came down to communicate,
Through His Word and through His grace,
Still seeking face to face.

[Verse 4]
Enoch walked with God one day,
Until God took him away,
This is what the Savior brings,
Restoration of all things.

[Chorus]
Walking with God is what we were made for,
Communion with Him forevermore,
Though sin broke us for a while,
He restores us with His smile!

[Bridge]
One day in the city bright,
Where there is no need for light,
We will walk with Him again,
Perfect fellowship, amen.

[Outro]
Walk with Him today... He's waiting for you...
