SONG 5: "The First Darkness"

[Intro]

[Verse 1]
Sun went down, they'd never seen night,
Terror filled them, stripped of the light,
Is this death? Is this the end?
God's punishment they could not comprehend.

[Verse 2]
Adam cried out, "Lord, don't kill us!
Take not the light that was promised us!
We'd rather die than face this dark,
Please restore to us heaven's spark!"

[Chorus]
First darkness falling, we're so afraid,
Never seen night, in Eden we stayed,
But God spoke words of comfort true,
"This is just night, dawn comes to you!"

[Verse 3]
Eve was weeping, thought they would die,
Fell to the ground with a bitter cry,
But God in mercy heard their plea,
Sent comfort in their misery.

[Verse 4]
"This darkness," God said, "is not your death,
Just twelve hours, then the sun rises fresh,
Night and day I have ordained,
Till salvation is obtained."

[Chorus]
First darkness falling, we're so afraid,
Never seen night, in Eden we stayed,
But God spoke words of comfort true,
"This is just night, dawn comes to you!"

[Bridge]
Morning came with golden rays,
But they feared the sun's burning blaze,
"Is this God's plague upon our skin?"
No, just the light to begin again.

[Outro]
From darkness to light... the pattern of life...
