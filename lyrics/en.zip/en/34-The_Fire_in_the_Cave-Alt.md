SONG 34: "The Fire in the Cave (Alt)"

[Intro]

[Verse 1]
Satan set the cave on fire,
Flames rose higher, ever higher,
Adam and Eve could not escape,
Burning heat in that dark space.

[Verse 2]
Their flesh was scorched, their bodies burned,
But to the Lord their hearts were turned,
"If this is pain in mortal frame,
What will be hell's eternal flame?"

[Chorus]
Fire in the cave burns all around,
But our faith in God is solid ground,
Though the flames rise high tonight,
He will lead us to the light!

[Verse 3]
They fled the cave into the night,
Forty-seventh day of blight,
But God had not abandoned them,
Would not let their fire condemn.

[Verse 4]
Under stars upon the hill,
They sought the Lord, surrendered still,
And in the morning God came near,
Drove away their deepest fear.

[Chorus]
Fire in the cave burns all around,
But our faith in God is solid ground,
Though the flames rise high tonight,
He will lead us to the light!

[Bridge]
Adam said to Eve that day,
"How will we face hell's fire's sway?
But God who saved us from this blaze,
Will be with us all our days."

[Outro]
Through fire we pass... to glory at last...
