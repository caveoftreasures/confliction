SONG 22: "Eves Lament (Alt)"

[Intro]

[Verse 1]
"Forgive me Lord, I caused this fall,
I alone made Adam fall,
Remember not my sin this day,
Take not my beloved away."

[Verse 2]
She wept before the throne of grace,
Tears streaming down her fallen face,
"I brought him from the light to dark,
From joy to this cold, bitter spark."

[Chorus]
Eve's lament rises to the sky,
"Lord, I'm the reason, I know why,
If you won't save him, take me too,
I cannot live this world without you!"

[Verse 3]
From Adam's side she was made,
One flesh, one bone, now both afraid,
"You made us both in one single day,
Don't let death take him away!"

[Verse 4]
God heard her cry, felt her pain,
Would not let her weep in vain,
Raised them both with His Holy Word,
Their desperate prayers He had heard.

[Chorus]
Eve's lament rises to the sky,
"Lord, I'm the reason, I know why,
If you won't save him, take me too,
I cannot live this world without you!"

[Bridge]
Through her came the fall of man,
But also part of God's great plan,
For through a woman, born would be,
The One to set all captives free.

[Outro]
Through a woman came the fall... through a woman, life for all...
