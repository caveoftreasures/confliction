SONG 89: "The Serpent Crusher"

[Intro]

[Verse 1]
From the moment of the fall,
God declared to one and all,
One would come to crush the snake,
Every chain of sin would break.

[Verse 2]
Satan thought he'd won the day,
Leading Adam far astray,
But God's plan was set in stone,
Victory from the Father's throne.

[Chorus]
The Serpent Crusher is on His way,
Coming soon to win the day,
Satan's head beneath His feet,
His ancient victory complete!

[Verse 3]
At the cross it looked like loss,
Shame and pain upon that cross,
But on the third day He arose,
Crushing every single foe.

[Verse 4]
Now the serpent's time is short,
Judgment comes from heaven's court,
The lake of fire waits for him,
Where all evil will meet its end.

[Chorus]
The Serpent Crusher is on His way,
Coming soon to win the day,
Satan's head beneath His feet,
His ancient victory complete!

[Bridge]
What started in Eden's shade,
Is ending now, the debt is paid,
The enemy is crushed beneath,
The Victor who conquered death.

[Outro]
The serpent is crushed... under the Savior's foot...
