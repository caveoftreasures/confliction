SONG 109: "The Risen One"

[Intro]

[Verse 1]
Death could not hold Him in the ground,
Three days down, He came around,
Stone rolled back, the tomb was bare,
Grave clothes folded, placed with care.

[Verse 2]
What Adam lost through sin and shame,
The risen Christ can now reclaim,
Death defeated, Satan's done,
Victory won by God's own Son.

[Chorus]
The Risen One has conquered all,
Answered every desperate call,
Up from the grave He arose,
Triumph over all His foes!

[Verse 3]
"Why do you seek the living here,
Among the dead with doubt and fear?
He is not here, He has risen,
Released from death's dark prison!"

[Verse 4]
And because He lives, we too,
Will rise to life forever new,
Bodies raised from dust and clay,
On that great resurrection day.

[Chorus]
The Risen One has conquered all,
Answered every desperate call,
Up from the grave He arose,
Triumph over all His foes!

[Bridge]
He is the resurrection and the life,
Whoever believes overcomes the strife,
Though they die, yet shall they live,
This is what the Savior gives.

[Outro]
He is risen... He is risen indeed...
