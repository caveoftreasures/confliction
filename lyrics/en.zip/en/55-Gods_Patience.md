SONG 55: "Gods Patience"

[Intro]

[Verse 1]
How many times they fell in fear,
How many times God drew them near,
Raised them up from death's cold grip,
Never let His promise slip.

[Verse 2]
Satan attacked them day and night,
Every way to block the light,
But God was patient, God was true,
Always bringing something new.

[Chorus]
God's patience never runs out,
Even when we're filled with doubt,
Eighty times they fell and rose,
Eighty times His mercy flows!

[Verse 3]
They failed and stumbled, time again,
But God kept working through their pain,
Never left them on their own,
Never left them all alone.

[Verse 4]
"How long, O Lord?" they'd cry out loud,
Underneath the suffering cloud,
But God would answer, faithful still,
Working out His perfect will.

[Chorus]
God's patience never runs out,
Even when we're filled with doubt,
Eighty times they fell and rose,
Eighty times His mercy flows!

[Bridge]
For God is slow to anger, rich in love,
Sending blessings from above,
He knows we're dust, He understands,
We're held securely in His hands.

[Outro]
His patience endures... forever secure...
