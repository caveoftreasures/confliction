SONG 16: "From Dust to Glory (Alt)"

[Intro]

[Verse 1]
Four elements God gathered round,
Spread His hand upon the ground,
Took the dust, just one part small,
Formed a man to rule them all.

[Verse 2]
Third hour on that Friday morn,
Into Eden Adam born,
Given understanding, pure heart too,
Named the creatures, every hue.

[Chorus]
From dust to glory we were made,
From glory back to dust we fade,
But God's not finished with this clay,
He'll raise us up on that great day!

[Verse 3]
Lions, birds, and beasts of field,
All to Adam had to yield,
Dominion given, power supreme,
Living out the Creator's dream.

[Verse 4]
But dust we are and dust return,
This lesson Adam had to learn,
Yet in the dust hope remains,
God will break our mortal chains.

[Chorus]
From dust to glory we were made,
From glory back to dust we fade,
But God's not finished with this clay,
He'll raise us up on that great day!

[Bridge]
The body withers, flesh decays,
But souls will see eternal days,
When the righteous bathe in that crystal sea,
They'll shine in glory, forever free.

[Outro]
From dust we rise... to claim the prize...
