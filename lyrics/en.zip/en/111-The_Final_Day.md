SONG 111: "The Final Day"

[Intro]

[Verse 1]
When the five and a half are done,
The Father sends His only Son,
To gather up His chosen ones,
From the daughters and the sons.

[Verse 2]
Every eye will see Him come,
On the clouds, the Holy One,
Angels with Him by the score,
What they've waited for and more.

[Chorus]
The final day is drawing near,
When the King will appear,
Every knee will bow that day,
Every tongue will confess and say!

[Verse 3]
Adam will stand in that great throng,
With the faithful all along,
See the face of the promised One,
See the promise finally done.

[Verse 4]
Satan cast into the fire,
Gets what he did desire,
All his schemes come to an end,
Nothing left for him to send.

[Chorus]
The final day is drawing near,
When the King will appear,
Every knee will bow that day,
Every tongue will confess and say!

[Bridge]
"Holy, holy, holy Lord,
Worthy to be praised and adored,
King of Kings and Lord of Lords,
Forever and forever and ever!"

[Outro]
The final day approaches... are you ready?...
