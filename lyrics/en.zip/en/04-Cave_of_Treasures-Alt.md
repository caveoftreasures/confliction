SONG 4: "Cave of Treasures (Alt)"

[Intro]

[Verse 1]
Western border of the garden wide,
A cave in the rock where they could hide,
God commanded them to dwell inside,
Cave of Treasures, where hope survived.

[Verse 2]
Gold on the southern wall did shine,
Incense from the east, a sacred sign,
Myrrh on the western side aligned,
Treasures of mercy, gifts divine.

[Chorus]
Cave of Treasures, our prison and home,
Dark rocky walls where we're not alone,
God hasn't left us, He hears our cry,
In this cold cave, we will not die!

[Verse 3]
What is this gloom compared to light?
What is this darkness after the bright?
What is this narrow space to bear,
After the garden beyond compare?

[Verse 4]
Adam wept over his fallen state,
Eve beside him sharing his fate,
But God sent His Word to raise them up,
Filling with hope their bitter cup.

[Chorus]
Cave of Treasures, our prison and home,
Dark rocky walls where we're not alone,
God hasn't left us, He hears our cry,
In this cold cave, we will not die!

[Bridge]
Three treasures left for future days,
Gold, incense, myrrh for the one who saves,
Pointing to the promise yet to come,
When the Father would send His Son.

[Outro]
In the cave we wait... for redemption's gate...
