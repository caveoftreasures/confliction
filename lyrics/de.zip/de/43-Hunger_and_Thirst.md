SONG 43: "Hunger and Thirst"

Lied 22: Hunger und Durst

[Intro]

[Verse 1]
Engel stiegen vom hohen Himmel herab,
Die Wächter, die die Grenze überschritten, hinab,
Sie sahen die Töchter der Menschen so schön,
Und nahmen sich Frauen überall zu seh'n.

[Verse 2]
Riesen wurden aus dieser Verbindung geboren,
Die Nephilim brachten Verwirrung erkoren,
Die Erde wurde durch ihre Bosheit verdorben,
Aber Noah fand Gnade bei Gott, nicht gestorben.

[Chorus]
Die Wächter fielen von ihrem heiligen Platz,
Himmel und Erde mischend in Schande, der Schatz,
Aber Gott sah alles von oben,
Und sandte die Flut mit Seiner Liebe gehoben.

[Bridge]
Gefesselt in Dunkelheit warten sie,
Die Engel, die ihr Schicksal besiegelten früh,
Das Gericht kommt für alle, die sündigen,
Ob Engel oder Mensch, drinnen oder aus den Windigen.

[Outro]
Die Wächter fielen... aber Gott bleibt...
