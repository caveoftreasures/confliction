SONG 19: "The Bright Nature"

Lied 10: Die Strahlende Natur

[Intro]

[Verse 1]
Einst trugen wir ein Kleid aus Licht,
Strahlend rein, im Angesicht,
Keine Dunkelheit berührte unseren heiligen Rahmen,
Wir wandelten in Gottes ewiger Flamme im Namen.

[Verse 2]
Augen konnten sehen, was Engel sahen,
Himmlische Herrlichkeit, ohne Mahn,
Gott lobpreisend Tag und Nacht,
In der perfekten Weise dieser leuchtenden Pracht.

[Chorus]
Wir verloren unsere leuchtende Natur im Fall,
Tauschten Herrlichkeit gegen einen sterblichen Schall,
Aber Gott wird uns wieder kleiden,
In Gewänder des Lichts, wenn wir scheiden!

[Bridge]
Jenes Meer aus Kristall, rein und klar,
Wo Gerechtigkeit währt, wunderbar,
Uns badend in seinem heiligen Fluss,
Zurückkehrend zum Leben, das wir einst kannten zum Schluss.

[Outro]
Die leuchtende Natur kehrt zurück... wenn der Retter kommt...
