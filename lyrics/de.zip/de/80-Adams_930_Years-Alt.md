SONG 80: "Adams 930 Years (Alt)"

Lied 40: Adams 930 Jahre

[Intro]

[Verse 1]
Auf dem Berg Sinai kam Gott herab,
Mit Donner und Blitz erschien Er knapp,
Mose stieg auf, das Gesetz zu empfangen,
Gebote Gottes, dem ewigen König, ohne Bangen.

[Verse 2]
"Du sollst keine anderen Götter haben vor mir,
Du sollst dir kein Bildnis machen hier,
Du sollst meinen Namen nicht missbrauchen,
Gedenke des Sabbats, die Tage tauchen."

[Chorus]
Die Zehn Gebote in Stein geschrieben,
Gottes Gesetz für die Geliebten und Getrieben,
Du sollst den Herrn lieben mit allem, was du bist,
Und deinen Nächsten wie dich selbst, nicht List!

[Bridge]
Ehre deinen Vater und deine Mutter wohl,
Du sollst nicht töten, nicht ehebrechen toll,
Du sollst nicht stehlen, nie lügen,
Du sollst nicht begehren, was andere kriegen.

[Outro]
Gottes Gesetz... in Stein geschrieben...
