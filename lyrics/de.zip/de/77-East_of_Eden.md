SONG 77: "East of Eden"

Lied 39: Östlich von Eden

[Intro]

[Verse 1]
In der Wüste beschwerte sich das Volk,
"Es gibt kein Essen," ihr Ruf im Wolke,
Aber Gott in Seiner Gnade sorgte vor,
Brot vom Himmel jeden Morgen am Tor.

[Verse 2]
"Was ist das?" fragte das Volk,
Manna nannten sie es, als sie es schmeckten im Volk,
Süß wie Honig, weiß wie Frost,
Genug für den Tag, ohne Durst.

[Chorus]
Manna vom Himmel, Brot jeden Tag,
Gott nährt die Seinen mit Wohlbehag,
Der Mensch lebt nicht vom Brot allein,
Sondern von jedem Wort Gottes, fein!

[Bridge]
Christus ist das wahre Brot vom Himmel,
Wer von Ihm isst, lebt im Getümmel,
Das Manna hörte auf, Christus bleibt,
Ewige Nahrung, die nie verbleibt.

[Outro]
Brot vom Himmel... Leben für immer...
