SONG 99: "The Day of Restoration"

Lied 50: Der Tag der Wiederherstellung

[Intro]

[Verse 1]
Salomo bat Gott um Weisheit,
Nicht um Reichtum oder Ruhm zur Zeit,
Gott gab ihm mehr als er bat,
Weisheit, Reichtum, Ehre, Gottes Tat.

[Verse 2]
Er richtete mit Gerechtigkeit schwierige Fälle,
Baute den Tempel mit geschickten Händen, die schnelle,
Könige und Königinnen kamen zu hören,
Die Weisheit, die Gott wollte lehren.

[Chorus]
Salomos Weisheit strahlte hell,
Aber einer größer als Salomo kam schnell,
Christus, die Weisheit Gottes persönlich,
In Ihm ist alles Wissen königlich!

[Bridge]
Die Furcht des Herrn ist der Anfang,
Der Weisheit, heiliger Empfang,
Suche Christus, finde Wahrheit,
Ewige Weisheit, Unendlichkeit.

[Outro]
Weisheit von oben... Christus ist die Antwort...
