SONG 127: "The Overcoming"

Lied 64: Der Sieg

[Intro]

[Verse 1]
Auf Golgatha starb mein Retter,
Ans Kreuz genagelt, gab Er Sein Leben, so bitter,
Für meine Sünden litt Er dort,
Der Gerechte für die Ungerechten, am Ort.

[Verse 2]
"Vater, vergib ihnen," betete Er,
"Sie wissen nicht, was sie tun," erklärte Er schwer,
Inmitten Seiner tiefsten Qual,
Grenzenlose Liebe, Gnade ohne Zahl.

[Chorus]
Das Kreuz, das Kreuz, wo Christus starb,
Der Ort, wo mein Leben sich erwarb,
Vom Tod zum Leben, von Dunkelheit zu Licht,
Alles durch die Gnade Jesu, das Gedicht!

[Bridge]
"Es ist vollbracht," waren Seine Worte,
Das Werk vollständig, offene Pforte,
Der Vorhang zerriss von oben nach unten,
Der Weg zu Gott ist nicht mehr gebunden.

[Outro]
Am Kreuz... alles wurde vollbracht...
