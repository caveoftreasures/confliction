SONG 97: "Rivers of Living Water"

Lied 49: Ströme Lebendigen Wassers

[Intro]

[Verse 1]
Gott versprach David ein Haus,
Ein ewiges Königreich ohne Aus,
Sein Thron würde für immer bleiben,
Ein Sohn würde ewig regieren, nicht treiben.

[Verse 2]
Salomo baute den großen Tempel,
Aber der wahre Tempel ist mehr als ein Exempel,
Christus, der Sohn Davids, würde kommen,
Sein Reich ohne Ende, willkommen.

[Chorus]
Das Haus Davids steht fest,
Gottes Verheißung bestätigt am best,
Ein König aus Davids Linie würde geboren,
Christus Jesus, König und Messias erkoren!

[Bridge]
Aus der Wurzel Isais kam ein Spross,
Der blühende Zweig, der wartete groß,
Der Löwe von Juda, der Stern Jakobs,
Alles erfüllt in Christus, ohne Knacks.

[Outro]
Das Haus Davids... der ewige Thron...
