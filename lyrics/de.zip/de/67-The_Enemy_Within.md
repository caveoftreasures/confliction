SONG 67: "The Enemy Within"

Lied 34: Der Feind im Inneren

[Intro]

[Verse 1]
Pharao befahl, die Kinder zu töten,
Aber eine Mutter versteckte ihr Kleines in Nöten,
In einem Korb aus Binsen legte sie ihn,
Auf dem Nil treibend, Gottes Sinn.

[Verse 2]
Die Tochter des Pharao fand ihn weinend,
"Ein hebräisches Kind," sagte sie scheinend,
Mirjam, seine Schwester, erschien dort,
"Soll ich eine Amme holen?" an diesem Ort.

[Chorus]
Mose im Korb, vom Tod gerettet,
Im Palast aufgezogen, fest eingebettet,
Aber Gott hatte einen größeren Plan,
Befreier Seines Volkes, mit Ehre dann!

[Bridge]
Vom Korb zum königlichen Palast,
Vom Palast zur Wüste ohne Rast,
Gott bereitete Seinen Diener so vor,
Israel zu befreien, öffne das Tor.

[Outro]
Der Korb schwamm... der Befreier wurde geboren...
