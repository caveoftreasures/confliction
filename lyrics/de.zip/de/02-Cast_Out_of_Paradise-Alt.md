SONG 2: "Cast Out of Paradise (Alt)"

Lied 01: Vertrieben aus dem Paradies

[Intro]

[Verse 1]
Garten Eden, am dritten Tag gepflanzt,
Im Osten der Welt, wo die Sonne tanzt,
Wasser umgibt ihn, rein und heilig,
Grenze des Himmels, Gottes Garten selig.

[Verse 2]
Adam wurde aus Staub und Herrlichkeit geformt,
Leuchtende Natur, Abbild des Himmels genormt,
Mit Engeln wandelnd, immer lobpreisend,
Keine Nacht, kein Tag, nur endloses Licht erweisend.

[Chorus]
Aus dem Paradies verstoßen, von der Gnade gefallen,
Leuchtende Natur genommen, Gottes Angesicht nicht mehr sehend in den Hallen,
Vom Garten zur Höhle, von der Herrlichkeit zum Staub,
Aber Gott machte ein Versprechen, dem wir glauben!

[Verse 3]
Eva aus seiner Seite, Bein von seinem Bein,
Zusammen in Eden, niemals allein,
Aber die Schlange kam mit süßen Worten,
Täuschung und Lügen an allen Orten.

[Verse 4]
Ein Biss der Frucht, ein Moment der Sünde,
Die Tür zur Dunkelheit öffnete sich geschwinde,
Ihre Augen wurden geöffnet, aber was sahen sie?
Nacktheit, Scham und Sterblichkeit, nie.

[Bridge]
Fünfeinhalb Tage sagte die Prophezeiung an,
Fünftausend Jahre bevor die Wahrheit begann,
Ein Retter würde kommen, das Verlorene wiederherzustellen,
Für ihre Sünde den höchsten Preis zu bestellen.

[Outro]
Paradies verloren... aber nicht für immer...
