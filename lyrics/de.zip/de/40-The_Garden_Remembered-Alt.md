SONG 40: "The Garden Remembered (Alt)"

Lied 20: Der Erinnerte Garten

[Intro]

[Verse 1]
Seth wurde geboren, Abels Platz zu nehmen,
Eine weitere Chance, ein anderer Sohn in Gottes Namen,
Durch seine Linie würde die Verheißung kommen,
Der Retter geboren, heilig und willkommen.

[Verse 2]
Seth wandelte in den Wegen seines Vaters,
Lehrte seine Kinder Gottes Lob als Rather,
Eine gerechte Linie durch die Zeit,
Die Verheißung tragend, bereit.

[Chorus]
Seth der Erwählte, der Same der Hoffnung,
Durch seine Linie lernen wir zu hoffen,
Von Adam zu Noah geht die Geschichte,
Gottes Treue immer im Lichte!

[Bridge]
Als alles verloren schien und getan,
Erweckte Gott einen anderen Sohn, sein Plan,
Die Verheißung ging stark weiter,
Gottes Plan kann nie scheitern, heiter.

[Outro]
Der erwählte Same... die Verheißung geht weiter...
