SONG 84: "Paradise Restored (Alt)"

Lied 42: Das Wiederhergestellte Paradies

[Intro]

[Verse 1]
Feurige Schlangen bissen das Volk,
Gericht für ihre Klage, Wolke,
Viele starben durch das Gift,
Bis sie zum guten Gott riefen als Stift.

[Verse 2]
Gott sagte zu Mose: "Mache eine Schlange,
Setze sie auf eine Stange, die lange,
Jeder, der hinschaut, wird leben,
Der Glaube an Mein Wort wird es geben."

[Chorus]
Die eherne Schlange erhoben,
Symbol Christi, von oben,
Wie Mose das Zeichen erhöhte,
Wurde Christus am Kreuz erhöht!

[Bridge]
Schau und lebe, der Befehl wurde gegeben,
Kein anderes Werk, kein anderer Weg zum Leben,
Nur schauen auf den, der verwundet wurde,
Für unsere Übertretungen, der Gesalbte.

[Outro]
Schau und lebe... Christus wurde erhöht...
