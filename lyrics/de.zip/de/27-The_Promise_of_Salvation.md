SONG 27: "The Promise of Salvation"

Lied 14: Das Versprechen der Erlösung

[Intro]

[Verse 1]
Gott tötete Tiere, um ihre Schande zu kleiden,
Das erste Blutvergießen, wer wird leiden?
Sünde erfordert den Tod des Unschuldigen,
Ein Prinzip etabliert, heilig und sündigen.

[Verse 2]
Tierhäute, um ihre Haut zu bedecken,
Ein Symbol dessen, was geschehen würde wecken,
Das makellose Lamm würde eines Tages sterben,
Um unsere Sünden für immer zu verderben.

[Chorus]
Tierfelle, das erste Opfer,
Blut vergossen, Leben gebend, unser Helfer,
Gott bedeckte sie mit Seiner Liebe,
Ein Geschenk der Gnade von oben!

[Bridge]
Von Eden zum Kreuz wird die Linie gezogen,
Unschuldiges Blut, alles durch Gnade, verbogen,
Die Tiere starben, damit sie lebten,
Christus starb, Vergebung zu geben.

[Outro]
Bedeckt durch Blut... gerettet durch Gnade...
