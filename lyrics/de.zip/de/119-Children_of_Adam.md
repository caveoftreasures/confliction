SONG 119: "Children of Adam"

Lied 60: Kinder Adams

[Intro]

[Verse 1]
Johannes der Täufer in der Wüste rief,
"Bereitet den Weg des Herrn," er lief,
Gekleidet in Kamelhaare, Honig und Heuschrecken,
Predigend Buße ohne zu erschrecken.

[Verse 2]
"Der nach mir kommt, ist größer,
Ich bin nicht würdig, seine Sandale zu lösen,
Ich taufe mit Wasser, aber Er wird taufen,
Mit Heiligem Geist, Feuer wird laufen."

[Chorus]
Eine Stimme in der Wüste bereitet,
Der Weg des Herrn wird verkündet, geleitet,
Macht gerade die krummen Pfade,
Der König der Könige kommt mit Gnade!

[Bridge]
Johannes bereitete den Weg des Königs,
Der letzte Prophet des alten Gesetzes, wenigstens,
Auf Christus zeigend sagte er eines Tages,
"Siehe, das Lamm," mit Behagen.

[Outro]
Bereitet den Weg... der Herr kommt...
