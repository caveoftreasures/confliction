SONG 21: "Eves Lament"

Lied 11: Evas Klage

[Intro]

[Verse 1]
Gott schloss einen Bund mit Adam an diesem Tag,
Ein Versprechen der Erlösung, ohne Frag,
Fünftausend Jahre bis der Retter kommt,
Um die Menschheit vom Grab zu befreit und gelobt.

[Verse 2]
"Ich werde dir Mein Wort senden," sprach Gott,
"Um dich von Sünde und Tod zu retten, mein Gebot,
Vertraue Mir, auch wenn der Weg lang ist,
Meine Liebe zu dir ist immer die Frist."

[Chorus]
Der Bund Gottes steht fest und wahr,
Was Er verspricht, wird Er erfüllen, fürwahr,
Von Generation zu Generation,
Seine Treue kennt keine Frustration!

[Bridge]
Versiegelt mit dem Wort, versiegelt mit Liebe,
Versprochen vom Gott des Himmels, dem ich verliebe,
Keine Macht der Hölle kann brechen,
Diesen Bund, den Gott machte für uns zu sprechen.

[Outro]
Der Bund bleibt... bis zum Ende der Zeit...
