SONG 71: "The Garments of Skin"

Lied 36: Die Kleider aus Fell

[Intro]

[Verse 1]
Mose trat vor den Pharao,
"So spricht der Herr," verkündete er so,
"Lass mein Volk ziehen, um anzubeten,
In der Wüste wollen sie feiern und beten."

[Verse 2]
Pharao verhärtete sein Herz,
"Wer ist der Herr? Kein Scherz,
Ich kenne diesen Gott Israels nicht,
Ich werde sie nicht gehen lassen im Licht."

[Chorus]
Lass mein Volk ziehen! Gott verlangte,
Aber Pharao sein Herz verengte,
Zehn Plagen würden über Ägypten kommen,
Bis das Volk befreit würde, willkommen!

[Bridge]
Blut, Frösche, Mücken, Fliegen ohne End,
Pest, Geschwüre, Hagel, Heuschrecken gesandt,
Finsternis bedeckte das feindliche Land,
Und der Tod des Erstgeborenen am Ende stand.

[Outro]
Lass mein Volk ziehen... Freiheit kommt...
