SONG 60: "The Deceivers Lies (Alt)"

Lied 30: Die Lügen des Betrügers

[Intro]

[Verse 1]
Aus Ur der Chaldäer rief Gott,
Einen Mann namens Abram, nie besiegt durch Spott,
"Verlasse dein Land und deine Verwandtschaft,
Geh in das Land, das ich dir zeige in Gemeinschaft."

[Verse 2]
Im Glauben gehorchte Abraham dem Ruf,
Ohne zu wissen, wohin er ging, machte er den Schuf,
Sara, seine Frau, an seiner Seite,
Gott folgend mit vertrauendem Herzen, bereit.

[Chorus]
Abraham wurde gerufen, im Glauben zu wandeln,
Ohne das Ende zu sehen, ging er voran im Handeln,
Vater der Nationen würde er werden,
Gottes Verheißung würde er auf Erden!

[Bridge]
Von Abraham zu Isaak, von Isaak zu Jakob,
Die Linie des Messias endete nie ohne Job,
Gott erfüllt Seine Verheißungen durch die Zeit,
An alle, die an Seinen Plan glauben, bereit.

[Outro]
Von Gott gerufen... im Glauben wandelnd...
