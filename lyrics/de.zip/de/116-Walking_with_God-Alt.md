SONG 116: "Walking with God (Alt)"

Lied 58: Mit Gott Wandeln

[Intro]

[Verse 1]
Siebzig Jahre in Babylon vergingen,
Kyrus der Perser gab Freiheit, sie gingen,
Serubbabel führte das Volk zurück,
Um den Tempel wiederaufzubauen, Stück für Stück.

[Verse 2]
Esra brachte das Gesetz von neuem,
Nehemia baute die Mauern zum Ruhm, zu zeugen,
Das Volk kehrte in sein Land zurück,
Wartend auf den Messias, der den Krieg besiegt im Glück.

[Chorus]
Aus dem Exil zurück nach Hause,
Gott erfüllt Seine Verheißungen ohne Pause,
Wiederherstellung kommt nach dem Gericht,
Gott verlässt Sein Volk im Leiden nicht!

[Bridge]
Der Tempel wurde wieder aufgebaut,
Aber die Herrlichkeit war nicht wie zuvor, so laut,
Eines Tages würde ein größerer Tempel kommen,
Der Leib Christi, Tempel des Messias, willkommen.

[Outro]
Rückkehr aus dem Exil... Wiederherstellung...
