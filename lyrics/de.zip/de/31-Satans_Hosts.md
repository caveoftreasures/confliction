SONG 31: "Satans Hosts"

Lied 16: Satans Heerscharen

[Intro]

[Verse 1]
Vom Himmel fiel Satan einst herab,
Der rebellische Engel, stolz und knab,
Luzifer, der Morgenstern, schien hell,
Bis der Stolz ihn blendete schnell.

[Verse 2]
Wieder fällt er jedes Mal, wenn er scheitert,
Seine Lügen und Täuschungen nicht erweitert,
Gott wirft ihn nieder immer wieder,
Der besiegte Feind, seine Glieder.

[Chorus]
Satan fällt immer wieder,
Jeder Plan zerschmettert, jedes Schema nieder,
Gottes Macht ist immer größer,
Der Sieg gehört dem Schöpfer, dem Erlöser!

[Bridge]
Vom Himmel zur Erde, zum Abgrund wird er gehen,
Besiegt von Christus, den letzten Schlag zu sehen,
Gekettet in Dunkelheit für immer,
Der Feind besiegt, niemals frei, ohne Schimmer.

[Outro]
Fallend... immer fallend...
