SONG 50: "Cain and Abel (Alt)"

Lied 25: Kain und Abel

[Intro]

[Verse 1]
Gopherholz, dreihundert Ellen lang,
Noah baute die Arche stark und bang,
Fünfzig Ellen breit, dreißig hoch,
Ein Fenster oben und eine Tür auch noch.

[Verse 2]
Jahr für Jahr klang der Hammer,
Während Noah Gottes Lied predigte ohne Jammer,
"Tut Buße," rief er, "das Gericht kommt,"
Aber sie lachten und flohen, verstummt.

[Chorus]
Die Arche bauend mit Glauben und Gebet,
Obwohl niemand sich darum zu kümmern steht,
Noah gehorchte dem Wort Gottes,
Die wichtigste Nachricht des Todes!

[Bridge]
Glaube baut, wenn andere zweifeln,
Glaube arbeitet ohne zu schreien bei den Meilen,
Noah zeigt uns, was es bedeutet,
Gott zu gehorchen, auch wenn niemand es glaubt, befreiet.

[Outro]
Die Arche bauend... den Weg bereitend...
