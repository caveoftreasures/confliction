SONG 52: "The Covenant Blood (Alt)"

Lied 26: Das Bundesblut

[Intro]

[Verse 1]
Gott rief Noah: "Tritt ein jetzt,"
Zwei von jeder Art, wie Er es setzt,
Sieben von den Reinen, Männchen und Weibchen,
Um das Leben zu erhalten, des Schöpfers Zeichen.

[Verse 2]
Die Tiere kamen von nah und fern,
Geführt von Gott wie ein Stern,
Zwei bei zwei traten sie ein in Reihe,
Während die Wolken dunkler wurden ohne Weihe.

[Chorus]
Tritt ein in die Arche, sichere Zuflucht,
Bevor der Sturm kommt mit Wucht,
Gott schließt die Tür, die Gnade endet,
Komm jetzt, sei nicht unter denen, die geblendet!

[Bridge]
Acht Seelen traten an diesem Tag ein,
Während die Welt weiter ging, allein,
Die Tür schloss sich, die Zeit war um,
Für die, die den liebenden Gott ablehnten, stumm.

[Outro]
In die Arche tretend... gerettet durch Gnade...
