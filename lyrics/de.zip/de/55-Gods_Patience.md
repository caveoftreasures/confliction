SONG 55: "Gods Patience"

Lied 28: Gottes Geduld

[Intro]

[Verse 1]
Nach der Flut schien die Sonne,
Ein Regenbogen erschien, göttliche Wonne,
Die Farben malten den Himmel mit Hoffnung,
Gottes Versprechen für die ganze Erde in Eröffnung.

[Verse 2]
"Nie wieder werde ich durch Wasser vernichten," sprach Er,
"Dieser Regenbogen ist mein Bund, schwer,
Wenn Wolken am Himmel erscheinen,
Wird der Regenbogen an meinen Bund erinnern, nicht weinen."

[Chorus]
Der Regenbogenbund strahlt oben,
Eine Erinnerung an Gottes treue Liebe gehoben,
Stürme mögen kommen, Regen fallen,
Aber Gott hält Seine Versprechen für alle!

[Bridge]
Jede Farbe erzählt eine Geschichte,
Von Gottes Barmherzigkeit und Seiner Ruhmes Berichte,
Wenn wir den Regenbogen am Himmel sehen,
Erinnern wir uns, dass Gott immer hier ist, verstehen.

[Outro]
Der Regenbogen scheint... die Verheißung bleibt...
