SONG 93: "The Great Exchange"

Lied 47: Der Große Austausch

[Intro]

[Verse 1]
Der Jüngste der Söhne Isais,
Hütete Schafe allein, so gewiss,
Aber Gott schaut nicht auf das Äußere,
Sondern auf das Herz, das Innere.

[Verse 2]
Samuel kam, um einen König zu salben,
Die Brüder kamen vorbei, nicht die Hälfte,
"Gibt es keinen anderen?" der Prophet fragte,
"Der Jüngste," sagten sie, und David wagte.

[Chorus]
David der Hirte, zum König gesalbt,
Ein Mann nach dem Herzen Gottes, erkalbt,
Vom Hüten der Schafe zum Hüten der Nationen,
Gott bereitet in allen Situationen!

[Bridge]
Der Hirte wird König,
Weist auf Christus hin, wenig,
Der gute Hirte, der Sein Leben gibt,
Für Seine Schafe, Liebe, die liebt.

[Outro]
Der gesalbte Hirte... der erwählte König...
