SONG 110: "The Risen One (Alt)"

Lied 55: Der Auferstandene

[Intro]

[Verse 1]
Daniel war in Babylon gefangen,
Aber er bewahrte sein Herz mit Verlangen,
Er verunreinigte sich nicht mit des Königs Speise,
Gott gab ihm Gunst und Gnade auf der Reise.

[Verse 2]
Träume deutend durch Gottes Geist,
Könige verbeugten sich vor seiner Weise,
Das Bild des Traumes, die kommenden Reiche,
Bis Gottes Reich alles erfüllt, das Gleiche.

[Chorus]
Daniel in Babylon blieb treu,
In fremdem Land, Emmanuel diente ohne Scheu,
Dreimal am Tag zu seinem Gott betend,
Kein Dekret konnte seine Stimme beenden!

[Bridge]
In der Löwengrube überlebte er,
Gott sandte Seinen Engel, beschützte ihn sehr,
Daniels Glaube leuchtete in der Dunkelheit,
Zeuge des Gottes der Wahrheit.

[Outro]
Treu im fremden Land... Gott ist treu...
