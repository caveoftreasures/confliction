SONG 130: "The Eternal Home (Alt)"

Lied 65: Die Ewige Heimat

[Intro]

[Verse 1]
Am dritten Tag rollte der Stein weg,
Das leere Grab, Jesus auferstand, der Beleg,
Die Engel fragten an diesem Tag,
"Warum sucht ihr den Lebenden bei den Toten?" die Frag.

[Verse 2]
Maria sah ihn im Garten steh'n,
Die Jünger glaubten, als sie ihn geseh'n,
Vierzig Tage erschien Er,
Und gab viele Beweise des Lebens hier.

[Chorus]
Er ist auferstanden! Er ist nicht hier!
Der Tod besiegt, keine Sorge mehr bei mir,
Der tot war, lebt für immer,
Christus lebt, ewiglich und immer!

[Bridge]
Weil Er lebt, werde ich auch leben,
Der Tod ist nicht das Ende, ich muss nicht beben,
Das Grab konnte Ihn nicht halten,
Und es kann mich nicht behalten.

[Outro]
Er ist auferstanden... er lebt für immer...
