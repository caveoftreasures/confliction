SONG 12: "Forty Days of Fasting (Alt)"

Lied 06: Vierzig Tage des Fastens

[Intro]

[Verse 1]
Vierzig Tage und vierzig Nächte,
Adam stand im kalten Wasser, das ihn flechte,
Betend zu Gott um Gnade,
Suchend Vergebung, auf dem Pfade.

[Verse 2]
Eva im Tigris stehend dort,
Ihr reuiges Herz, Hände zum Hort,
Beide fastend von aller Nahrung,
Hoffend auf ihrer Seelen Erfahrung.

[Chorus]
Vierzig Tage Fasten und Gebet,
Suchend Gott überall, wo man steht,
Wir werden nicht essen, nicht trinken,
Bis wir des Herrn Gnade empfangen.

[Bridge]
Fasten bricht die Macht der Sünde,
Gebet bringt Gottes Frieden geschwinde,
Wenn wir uns vor Ihm demütigen,
Erfüllt Seine Gnade uns völlig.

[Outro]
Fasten und Gebet... der Weg ist klar...
