SONG 102: "Fight of Faith (Alt)"

Lied 51: Der Kampf des Glaubens

[Intro]

[Verse 1]
Elia der Prophet des Feuers kam,
In Zeiten der Bosheit, er verkündigte Gottes Plan,
"Es wird kein Regen fallen außer durch mein Wort,"
Drei Jahre Dürre, das Land verdorrt.

[Verse 2]
Auf dem Berg Karmel stellte er die Herausforderung,
Vierhundert Propheten Baals er konfrontiert in Förderung,
Das Feuer vom Himmel fiel auf den Altar,
"Der Herr ist Gott!" das Volk rief wunderbar.

[Chorus]
Elia der Prophet Gottes,
Rufend zur Buße ohne Spottes,
Bevor der große Tag kommt,
Bereitet den Weg, den der Herr bestimmt!

[Bridge]
In einem Feuerwagen wurde er entrückt,
Zum Himmel ohne zu sterben, beglückt,
Eines Tages wird er wiederkommen vor dem Ende,
Herzen vorbereitend ohne Wende.

[Outro]
Der Prophet des Feuers... den Weg bereitend...
