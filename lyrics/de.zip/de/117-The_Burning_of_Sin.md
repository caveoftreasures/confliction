SONG 117: "The Burning of Sin"

Lied 59: Die Verbrennung der Sünde

[Intro]

[Verse 1]
Vierhundert Jahre ohne Gottes Wort,
Die Stille zwischen den Testamenten, so fort,
Maleachi war der Letzte, der sprach,
"Elia wird kommen, bevor jener Tag erwacht."

[Verse 2]
Aber Stille bedeutet nicht Vergessen,
Gott bereitete vor, was versprochen, unterdessen,
Reiche stiegen auf und fielen,
Während die Zeit des Messias kam nach Zielen.

[Chorus]
Die Stille bricht in Bethlehem,
Mit dem Schrei eines Babys in der Krippe, hem,
Die Engel singen, die Hirten kommen,
Das Wort wurde Fleisch, für alle, die glauben, willkommen!

[Bridge]
Von Maleachi zu Matthäus verging die Zeit,
Aber Gottes Verheißung vergaß sie nicht, bereit,
Im richtigen Moment, zur perfekten Zeit,
Sandte Gott Seinen Sohn, das Projekt.

[Outro]
Die Stille bricht... der Retter wurde geboren...
