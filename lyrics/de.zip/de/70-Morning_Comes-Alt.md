SONG 70: "Morning Comes (Alt)"

Lied 35: Der Morgen Kommt

[Intro]

[Verse 1]
Mose hütete Schafe in Midian,
Als er einen Busch in Flammen sah, wunderan,
Er brannte, aber verzehrte sich nicht,
Die Stimme Gottes aus ihm spricht.

[Verse 2]
"Ziehe deine Sandalen von deinen Füßen,
Der Ort ist heilig," sprach der König süßen,
"Ich bin der Gott deiner Väter,
Ich habe das Schreien gehört, nun räter."

[Chorus]
Der brennende Busch rief Mose,
"Geh zum Pharao," der Befehl, oh Rose,
"Lass mein Volk ziehen jetzt,
Ich werde bei dir sein, unverletzt!"

[Bridge]
"ICH BIN, DER ICH BIN," Gott erklärte,
Der ewige Name, den Er lehrte,
Vergangenheit, Gegenwart und Zukunft in Ihm,
Der Gott Abrahams, treu und fromm.

[Outro]
Der Busch brannte... Gott sprach...
