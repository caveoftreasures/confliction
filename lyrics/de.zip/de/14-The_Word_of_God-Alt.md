SONG 14: "The Word of God (Alt)"

Lied 07: Das Wort Gottes

[Intro]

[Verse 1]
Als sie vor dem Tor fielen nieder,
Erschreckt von ihrem Zustand wieder,
Gott sandte Sein Wort, sie aufzurichten,
Er würde Seine Kinder nicht vernichten.

[Verse 2]
"Ich ordnete auf der Erde an," sprach Gott,
"Tage und Jahre bis zum Tod,
Wandle darin bis die Zeit endet,
Bis Ich Meinen Verheißenen sendet."

[Chorus]
Das Wort Gottes kam zu mir herab,
Richtete mich auf und machte mich wach,
Dasselbe Wort, das alles schuf,
Kam, um mich zu retten vom Ruf!

[Bridge]
Dieses Wort würde eines Tages Fleisch werden,
Alle zerbrochenen Dinge neu machen auf Erden,
Das Versprechen, vom Anfang geflüstert,
Würde jedes gebrochene Herz heilen, ungetrübt.

[Outro]
Das Wort wurde Fleisch... und wohnte unter uns...
