SONG 113: "Gods Faithfulness"

Lied 57: Gottes Treue

[Intro]

[Verse 1]
Gabriel kam zu Daniel mit einer Botschaft,
Siebzig Wochen für dein Geschlecht mit Kraft,
Um der Übertretung ein Ende zu machen,
Die Sünde zu sühnen, Segen zu entfachen.

[Verse 2]
Sieben Wochen und zweiundsechzig dazu,
Bis zum Messias Fürst, in Ruh,
Danach würde Er abgeschnitten werden,
Nicht für sich selbst, sondern geopfert auf Erden.

[Chorus]
Die siebzig Wochen Daniels,
Die genaue Zeit für Emmanuel,
Gott markierte den Tag und die Stunde,
Als der Retter kam, die frohe Kunde!

[Bridge]
Die Prophezeiung erfüllte sich buchstäblich,
Christus kam, als die Zeit war verständlich,
Nicht einen Tag früher, nicht einen Tag später,
Gott ist präzise in Seinem Geschick als Rater.

[Outro]
Siebzig Wochen... der Messias kommt...
