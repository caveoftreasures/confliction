SONG 64: "The Sea of Crystal (Alt)"

Lied 32: Das Kristallmeer

[Intro]

[Verse 1]
Jakob schlief mit einem Stein als Kissen,
Fliehend vor Esau ohne Wissen,
Im Traum sah er eine Leiter zum Himmel,
Engel auf und ab, alles ein Schimmel.

[Verse 2]
Oben war der Herr aller Herrlichkeit,
"Ich bin der Gott Abrahams," zur Zeit,
"Das Land, auf dem du liegst, werde ich dir geben,
Und in deinem Samen die Nationen segnen und erheben."

[Chorus]
Jakobs Leiter berührt den Himmel,
Verbindet die Erde mit Gott ohne Getümmel,
Christus ist diese Leiter heute,
Der Weg zum Vater, unsere Beute!

[Bridge]
"Bethel," nannte er diesen heiligen Ort,
Das Haus Gottes, Zuflucht und Hort,
Das Tor des Himmels öffnete sich in dieser Nacht,
Für Jakob den Flüchtling, süße Pracht.

[Outro]
Die Leiter zum Himmel... Christus ist der Weg...
