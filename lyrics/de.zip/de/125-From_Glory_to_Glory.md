SONG 125: "From Glory to Glory"

Lied 63: Von Herrlichkeit zu Herrlichkeit

[Intro]

[Verse 1]
Johannes sah Jesus auf ihn zukommen,
"Siehe, das Lamm Gottes," sagte er, willkommen,
"Das die Sünde der Welt wegnimmt,"
Das perfekte Opfer, dessen Wert bestimmt.

[Verse 2]
Seit Abel wies das Lamm voraus,
Auf das Opfer, das Gott bereitete im Haus,
In Ägypten schützte das Blut,
Und am Kreuz wurde alles gut.

[Chorus]
Das Lamm Gottes, ohne Makel und Fehler,
Trug unsere Sünden, perfekter Wähler,
Von der Knechtschaft befreite Er uns,
Mit Seinem kostbaren Blut kaufte Er uns!

[Bridge]
Würdig ist das Lamm, das geschlachtet wurde,
Macht, Herrlichkeit und Ehre zu empfangen, die Hürde,
Jedes Knie wird sich beugen,
Und jede Zunge wird bekennen und zeugen.

[Outro]
Siehe das Lamm... das die Sünde wegnimmt...
