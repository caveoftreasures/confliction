SONG 3: "Cave of Treasures"

Lied 02: Die Schatzhöhle

[Intro]

[Verse 1]
Schatzhöhle, unser neues Zuhause,
Felsen und Dunkelheit, in der Klause,
Von Edens Bäumen zu diesem düsteren Ort,
Vom Licht des Himmels zu diesem irdischen Hort.

[Verse 2]
Adam und Eva weinten bitterlich,
Erinnerten sich an den Garten herrlich,
Ihre Körper verändert, ihr Sehen getrübt,
Keine Engel mehr singend, die Seele betrübt.

[Chorus]
In der Schatzhöhle knien wir und beten,
Warten auf das Versprechen, Gott zu vertreten,
Gott hat uns nicht in unserer Verzweiflung verlassen,
Seine Liebe folgte uns, wir können es fassen.

[Verse 3]
Die Steinwände schienen sich zu schließen,
Die Luft schwer vom Gewicht, Tränen fließen,
Aber Gott sprach Worte der Hoffnung klar,
Ein Bund geschlossen, wunderbar.

[Bridge]
Diese Höhle aus Stein, dieses Grab aus Erde,
Würde zum Symbol der Wiedergeburt werde,
Denn aus der Dunkelheit kommt das Licht,
Und aus dem Tod kommt ewiges Gericht.

[Outro]
Wartend in der Dunkelheit... das Licht wird kommen...
