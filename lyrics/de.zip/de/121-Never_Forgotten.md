SONG 121: "Never Forgotten"

Lied 61: Niemals Vergessen

[Intro]

[Verse 1]
Am Anfang war das Wort,
Und das Wort war bei Gott, am Ort,
Und das Wort war Gott von Beginn,
Alles wurde durch Es gemacht, das ist der Sinn.

[Verse 2]
Und das Wort wurde Fleisch und wohnte,
Unter uns, Seine Herrlichkeit zeigte und lohnte,
Herrlichkeit wie des eingeborenen Sohnes vom Vater,
Voll Gnade und Wahrheit, unser Rather.

[Chorus]
Das Wort wurde Fleisch, Gott mit uns,
Emmanuel unter uns, ohne Verdruss,
Der Schöpfer wurde Geschöpf,
Um uns zu retten, der Erlöser tief!

[Bridge]
Von der Ewigkeit in die Zeit kam Er,
Vom Himmel zur Krippe, so schwer,
Der Unendliche in Marias Armen,
Der Ewige wurde geboren, zum Erbarmen.

[Outro]
Das Wort wurde Fleisch... und wohnte unter uns...
