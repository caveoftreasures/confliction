SONG 73: "The Fallen Angels"

Lied 37: Die Gefallenen Engel

[Intro]

[Verse 1]
Ein makelloses Lamm nahm jedes Haus,
Das Blut an den Pfosten, Gottes Beschluss,
Wenn der Todesengel vorüberginge,
Das Blut als Zeichen des Lebens bringe.

[Verse 2]
Gebratenes Fleisch mit bitteren Kräutern,
Ungesäuertes Brot in den Bräutern,
Angezogen und bereit zu gehen,
Die Nacht der Freiheit zu sehen.

[Chorus]
Das Passahlamm starb für uns,
Sein Blut befreit uns vom Verdruss,
Christus ist unser Lamm heute,
Sein Blut gibt uns Freiheit, keine Reue!

[Bridge]
Von Ägypten zum Kreuz geht die Geschichte,
Vom Lamm zu Christus im Berichte,
Das Gericht geht vorüber, wenn es sieht,
Das Blut des Lammes durch den Glauben.

[Outro]
Das Blut des Lammes... der Tod geht vorüber...
