SONG 57: "Adams Prayer"

Lied 29: Adams Gebet

[Intro]

[Verse 1]
In der Ebene von Schinar bauten sie,
Einen Turm bis zum Himmel, dachten nie,
"Lasst uns einen Namen machen," sagten sie,
"Damit wir nicht zerstreut werden," in ihrer Fantasie.

[Verse 2]
Ziegel für Steine, Asphalt für Mörtel,
Der Turm stieg immer höher, zur Pforte,
Aber Gott kam herab zu sehen,
Was die Menschenkinder wollten verstehen.

[Chorus]
Der Turm zu Babel erhob sich mit Stolz,
Der Mensch versuchte den Himmel zu erreichen, so tolz,
Aber Gott verwirrte ihre Sprachen an diesem Tag,
Und zerstreute sie überall ohne Frag!

[Bridge]
Stolz kommt vor dem Fall,
Wenn der Mensch versucht, Gott zu sein über all,
Aber Gottes Pläne können nicht vereitelt werden,
Sein Wille wird immer gefeiert auf Erden.

[Outro]
Sprachen verwirrt... Nationen geboren...
