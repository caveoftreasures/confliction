SONG 112: "The Final Day (Alt)"

Lied 56: Der Letzte Tag

[Intro]

[Verse 1]
Drei junge Hebräer weigerten sich anzubeten,
Die goldene Statue von König Nebukadnezar zu vertreten,
"Unser Gott kann uns befreien," erklärten sie,
"Und wenn nicht, beugen wir uns trotzdem nie."

[Verse 2]
Siebenmal heißer wurde der Ofen geheizt,
Schadrach, Meschach und Abed-Nego wurden rein gespeist,
Aber vier Gestalten gingen darin umher,
"Der Vierte sieht aus wie ein Göttersohn," war nicht schwer.

[Chorus]
Im Feuerofen war Gott dabei,
Mit Seinen Dienern wandelnd, auch bei dir herbei,
Die Flammen haben keine Macht,
Wenn Gott beschließt zu schützen in der Nacht!

[Bridge]
Kein Haar war versengt,
Kein Rauchgeruch sie umdrängt,
Das Feuer, das tötet, brannte sie nicht,
Denn der Sohn Gottes war ihr Licht.

[Outro]
Im Feuer... Gott ist gegenwärtig...
