SONG 108: "The Long Road Home (Alt)"

Lied 54: Der Lange Weg Nach Hause

[Intro]

[Verse 1]
Jesaja schrieb von einem, der kommen würde,
Verachtet, abgelehnt, niemand wollte Seine Bürde,
Mann der Schmerzen, mit Leiden vertraut,
Für unsere Sünden verwundet, uns vertraut.

[Verse 2]
Wie ein Lamm zur Schlachtbank geführt,
Schweigend, den Mund nicht öffnend, malträtiert,
Für unsere Übertretungen zerschlagen war Er,
Durch Seine Wunden sind wir geheilt, so schwer.

[Chorus]
Der leidende Knecht starb für uns,
Trug unsere Sünden und Schmerzen ohne Verdruss,
Was wir verdienten, trug Er,
Durch Sein Opfer sind wir gerettet, hör!

[Bridge]
Siebenhundert Jahre zuvor geschrieben stand,
Der Tod Christi, der uns segnen kann,
Jedes Detail erfüllt mit Präzision,
Gottes Plan, unsere Erlösung ohne Illusion.

[Outro]
Durch Seine Wunden... sind wir geheilt...
