SONG 33: "The Fire in the Cave"

Lied 17: Das Feuer in der Höhle

[Intro]

[Verse 1]
Gott versprach Wasser für ihren Durst,
Nicht nur für den Körper, auch die Seele zuerst,
Ströme lebendigen Wassers würden fließen,
Vom Retter, den alle wissen.

[Verse 2]
Vom Jordan zum Brunnen Jakobs,
Wasser des Lebens, wo Durstige ihren Platz,
Christus bietet, was nie versiegt,
Eine Quelle des Lebens, die immer siegt.

[Chorus]
Das Versprechen des Wassers, rein und wahr,
Vom Himmel fließend zu mir und dir, klar,
Niemals durstig, niemals trocken wieder,
Trinkend vom Retter, dem Freund der Glieder!

[Bridge]
Wasser wäscht, Wasser reinigt,
Wasser erfüllt alle unsere Träume vereinigt,
Getauft in Seinem heiligen Namen,
Wiedergeboren, nie mehr dieselben.

[Outro]
Wasser des Lebens... frei fließend...
