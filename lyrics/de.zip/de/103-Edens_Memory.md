SONG 103: "Edens Memory"

Lied 52: Edens Erinnerung

[Intro]

[Verse 1]
Elia floh vor Isebel mit Angst,
In eine Höhle versteckte er sich bang,
"Ich bin der Einzige, der übrig ist," er rief,
Aber Gott in Seiner Gnade antwortete tief.

[Verse 2]
Starker Wind, Erdbeben und Feuer kamen,
Aber in keinem von ihnen Gott sie nahmen,
Ein sanftes Säuseln, eine leise Stimme,
Gott sprach und alles war im Sinne.

[Chorus]
Die sanfte, stille Stimme Gottes,
Nicht im Lärm, sondern im Frieden des Gebotes,
In der Stille spricht Er noch,
Beruhige die Seele, um zu hören doch!

[Bridge]
Nicht immer im Großen ist Gott dabei,
Manchmal im Kleinen ist Er herbei,
Lerne Seine subtile Stimme zu hören,
In der Ruhe, im Sanften zu ehren.

[Outro]
Das sanfte Säuseln... Gott spricht...
