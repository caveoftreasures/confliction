SONG 47: "The Transgression"

Lied 24: Die Übertretung

[Intro]

[Verse 1]
In den Tagen Noahs war die Erde verderbt,
Jeder Gedanke des Menschen entstellt und vererbt,
Gewalt füllte jeden Ort,
Das Böse hatte allen Raum am Bord.

[Verse 2]
Aber Noah fand Gnade in Gottes Augen,
Ein gerechter Mann, heilig und zu glauben,
Er predigte Gerechtigkeit hundertzwanzig Jahre,
Aber niemand hörte seine Tränen, die wahre.

[Chorus]
Die Tage Noahs waren dunkel und voller Sünde,
Aber Gott hatte einen Plan von Anbeginn der Ründe,
Eine Arche der Rettung stellte Er bereit,
Für alle, die an Ihn glaubten in der Zeit.

[Bridge]
Wie es in den Tagen Noahs war,
So wird es sein, wenn Christus kommt, fürwahr,
Essend, trinkend, ohne Sorgen,
Bis das Gericht kommt am nächsten Morgen.

[Outro]
Die Tage Noahs... Zeichen der Zeit...
