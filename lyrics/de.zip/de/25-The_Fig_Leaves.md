SONG 25: "The Fig Leaves"

Lied 13: Die Feigenblätter

[Intro]

[Verse 1]
Feigenblätter nähten sie an diesem Tag,
Um ihre Schande zu bedecken, ihre Klag,
Der erste Versuch des Menschen, Sünde zu heilen,
Aber nur Gott kann das Innere ereilen.

[Verse 2]
Zerbrechliche Blätter, die bald welken würden,
Können nicht bedecken, was Sünde enthüllt mit Bürden,
Nur das Blut kann den Fleck waschen,
Nur Gott kann den Schmerz erlöschen.

[Chorus]
Feigenblätter können die Sünde nicht bedecken,
Unsere Bemühungen scheitern immer wieder, ohne zu erschrecken,
Nur Gott kann uns wieder kleiden,
Mit Gewändern der Gnade, gewaschen vom Leiden!

[Bridge]
Von Blättern zu Fellen kleidete Gott sie,
Ein Opfer gebracht, Blut vergossen, sieh,
Hinweisend auf das Lamm, das kommen würde,
Um alle zu kleiden, die an Ihn glaubten voll Würde.

[Outro]
Bedeckt von Gott... gekleidet in Gnade...
