SONG 16: "From Dust to Glory (Alt)"

Lied 08: Vom Staub zur Herrlichkeit

[Intro]

[Verse 1]
Aus dem Staub der Erde wurden wir gemacht,
Geformt von Gottes Händen mit Bedacht,
Lebensatem in unsere Formen,
Uns erhebend über alle Normen.

[Verse 2]
Im Garten wandelten wir mit Ihm,
Bevor die Sünde uns brachte zum Grimm,
Herrlichkeit bedeckte uns wie ein Kleid,
Leuchtende Natur, rein und geweiht.

[Chorus]
Vom Staub zur Herrlichkeit wurden wir erhoben,
Durch die Sünde wieder herabgeschoben,
Aber Gottes Versprechen bleibt wahr,
Vom Staub wird Er uns erneuern, wunderbar!

[Bridge]
Der Staub erinnert, woher wir kamen,
Die Herrlichkeit zeigt, was wir werden im Namen,
Zwischen Staub und Herrlichkeit warten wir,
Auf den Erlöser, der nicht spät ist hier.

[Outro]
Vom Staub... zur ewigen Herrlichkeit...
