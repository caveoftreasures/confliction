SONG 23: "The Sun and the Moon"

Lied 12: Die Sonne und der Mond

[Intro]

[Verse 1]
Drei goldene Stäbe aus dem Garten,
Weihrauch, Myrrhe, Schätze zum Warten,
Gebracht vom Engel in die Höhle,
Zeichen des Versprechens für unsere Seele.

[Verse 2]
Gold für die Königswürde dessen, der kommen würde,
Weihrauch für Seine Göttlichkeit, die Geburt,
Myrrhe für Seinen Tod und Sein Begräbnis,
Symbole von Gottes Plan, rein und gewiss.

[Chorus]
Goldene Stäbe glänzend in der Dunkelheit,
Versprechen der Hoffnung in jeder Zeit,
Vom Garten zur Höhle kamen sie,
Uns erinnernd, dass Gott immer ist, sieh!

[Bridge]
Diese Gaben würden eines Tages gegeben,
Dem Kind, geboren um uns zu erheben,
Weise Könige würden von weit kommen,
Seinem hellen Stern zu folgen, willkommen.

[Outro]
Gold, Weihrauch und Myrrhe... Gaben für den König...
