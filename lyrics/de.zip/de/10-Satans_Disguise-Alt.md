SONG 10: "Satans Disguise (Alt)"

Lied 05: Satans Verkleidung

[Intro]

[Verse 1]
Gekleidet in Roben hell wie der Tag,
Satan kam, um irrezuführen, Schlag für Schlag,
Stab des Lichts in seiner Hand,
Heilig aussehend, großartig und gewandt.

[Verse 2]
"Friede sei mit dir," sagte er,
"Gott hat mich gesandt, dein Helfer,
Komm mit mir ins Paradies,
Ich gebe dir alles, ohne Preis."

[Chorus]
Satan verwandelt sich in Licht,
Macht das Böse gut im Angesicht,
Aber Gottes Volk erkennt,
Den Betrüger, der sich verrennt!

[Bridge]
Achtzig Mal versuchte er zu betrügen,
Jeder Plan würde sie belügen,
Aber Gott war treu, immer nah,
Satan vertreibend mit heiliger Macht, ja.

[Outro]
Prüfe jeden Geist... kenne die Wahrheit...
