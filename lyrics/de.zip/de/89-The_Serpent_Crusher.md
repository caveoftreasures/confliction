SONG 89: "The Serpent Crusher"

Lied 45: Der Schlangenzertreter

[Intro]

[Verse 1]
Israel tat wieder Böses,
Vergaß Gott, suchte anderes Wesen,
Aber wenn sie in ihrer Not schrien,
Erweckte Gott einen Befreier, um zu ziehen.

[Verse 2]
Othniel, Ehud, Debora mutig,
Gideon mit dreihundert, Gott allmächtig,
Jephta, Simson mit Kraft ohne gleich,
Jeder Richter wies auf den ewigen König, so reich.

[Chorus]
Die Richter erheben sich, wenn Israel fällt,
Zeitweilige Retter, die Gott bestellt,
Aber ein vollkommener Richter würde kommen,
Christus Jesus, Richter und Messias, willkommen!

[Bridge]
Der Kreislauf der Sünde ging weiter,
Bis der wahre Richter kam, heiter,
Nicht nur um vom Feind zu befreien,
Sondern von der Sünde, immer dabei zu sein.

[Outro]
Die Richter kommen und gehen... der König bleibt...
