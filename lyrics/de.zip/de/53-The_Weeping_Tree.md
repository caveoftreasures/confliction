SONG 53: "The Weeping Tree"

Lied 27: Der Weinende Baum

[Intro]

[Verse 1]
Die Quellen der Tiefe öffneten sich an diesem Tag,
Die Fenster des Himmels ohne Unterlass, Schlag um Schlag,
Vierzig Tage und vierzig Nächte,
Der Regen fiel mit all seiner Mächte.

[Verse 2]
Die Wasser stiegen höher und höher,
Bedeckten Berge bis zum Himmel immer schöner,
Alles, was atmete, kam um im Wasser,
Außer denen in der Arche des Vaters, blasser.

[Chorus]
Die Flut kam, wie Gott gewarnt hatte,
Wegspülend alles, was verdorben war im Schatten,
Aber in der Arche war Frieden,
Noahs Familie fand ihre Basis hiernieden!

[Bridge]
Gottes Gericht ist sicher und wahr,
Aber Rettung ist für dich verfügbar, klar,
Die Arche war der Weg damals,
Christus ist der Weg jetzt und immer, falls.

[Outro]
Die Wasser bedeckten die Erde... aber die Arche schwamm...
