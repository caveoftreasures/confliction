SONG 62: "Strength in Weakness (Alt)"

Lied 31: Stärke in Schwachheit

[Intro]

[Verse 1]
Abraham versprach Gott einen Samen,
Zahlreich wie die Sterne im Namen,
Wie der Sand am Meer ohne Maß,
Segen für alle Nationen ohne Unterlass.

[Verse 2]
Durch Isaak würde die Verheißung kommen,
Der Sohn des Lachens, der Heilige, willkommen,
Jakob kämpfte und setzte sich durch,
Israel sein Name, nie gescheitert fürwahr.

[Chorus]
Der verheißene Same wächst und wächst,
Von Abraham zu David die Geschichte fließt,
Bis er in Bethlehem geboren wurde,
Der verheißene Retter, unser Eden der Würde!

[Bridge]
Jede Generation wartete,
Gottes Verheißung nie ermattete,
Der Same der Frau würde zertreten,
Den Kopf der Schlange, die betrogen.

[Outro]
Der verheißene Same... der Retter würde kommen...
