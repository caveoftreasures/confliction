SONG 106: "The Second Adam (Alt)"

Lied 53: Der Zweite Adam

[Intro]

[Verse 1]
Jesaja sah den Herrn erhöht,
Auf Seinem hohen Thron, verherrlicht und besteht,
Serafim riefen unaufhörlich,
"Heilig, Heilig, Heilig" herrlich.

[Verse 2]
"Wehe mir!" der Prophet schrie,
"Ich bin ein Mann unreiner Lippen," gestand er früh,
Ein Seraf flog mit glühender Kohle,
Berührte seine Lippen, er wurde rein und volle.

[Chorus]
Heilig, Heilig, Heilig ist der Herr,
Die ganze Erde ist voll Seiner Ehre schwer,
Wen soll ich senden? Gott fragte dann,
"Hier bin ich, sende mich," Jesaja begann.

[Bridge]
Die Vision Gottes verändert alles,
Vom Stolz zum Staub, in jeder Halles,
Wenn wir Seine Heiligkeit sehen,
Erkennen wir unsere Unwürdigkeit, verstehen.

[Outro]
Heilig, Heilig, Heilig... hier bin ich...
