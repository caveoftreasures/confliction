SONG 42: "The Jordan Flows (Alt)"

Lied 21: Der Jordan Fließt

[Intro]

[Verse 1]
Von Adam zu Seth, von Seth zu Enosch,
Generationen, die die Fackel weitertragen, frosch,
Jeder Vater lehrt seinen Sohn,
Die Verheißung der Erlösung für jedermann davon.

[Verse 2]
Kenan, Mahalalel, Jered auch,
Henoch, der mit Gott wandelte, nach Brauch,
Methusalah, der Älteste von allen,
Lamech und Noah, die dem Ruf nicht verfallen.

[Chorus]
Die Generationen kommen und gehen,
Aber Gottes Verheißung bleibt bestehen,
Von Vater zu Sohn erzählen wir die Geschichte,
Bis der Retter bricht den Zauber im Lichte!

[Bridge]
Jeder Name in der heiligen Linie,
Weist auf den göttlichen Retter hin,
Die Geschichte der Erlösung entfaltet sich,
Wie die alten Propheten es sahen, sicherlich.

[Outro]
Generation für Generation... die Verheißung geht weiter...
