SONG 65: "Seth the Replacement"

Lied 33: Seth der Ersatz

[Intro]

[Verse 1]
Josef träumte Träume von Größe,
Sonne, Mond und Sterne in Gewissheit und Blöße,
Seine Brüder hassten ihn dafür,
Verkauften ihn als Sklaven, hier.

[Verse 2]
Von der Grube nach Ägypten wurde er gebracht,
Vom Sklaven zum Gefangenen, verlacht,
Aber Gott war mit ihm in allem,
Träume deutend überall im Schallen.

[Chorus]
Josef der Träumer, verkauft und verraten,
Aber Gott führte ihn zur Erhöhung, zu beraten,
Was der Mensch zum Bösen dachte,
Gott nutzte es zum Guten, erwachte!

[Bridge]
Vom Gefängnis zum Palast stieg er auf,
Zweiter nach dem Pharao, Gottes Lauf,
Seine Familie vor der Hungersnot rettend,
Seinen Brüdern vergebend, immer wettend.

[Outro]
Träume träumend... Gott wird sie erfüllen...
