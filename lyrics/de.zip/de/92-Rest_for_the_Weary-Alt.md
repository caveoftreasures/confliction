SONG 92: "Rest for the Weary (Alt)"

Lied 46: Ruhe für die Müden

[Intro]

[Verse 1]
Ruth verließ ihr Land aus Liebe,
Folgte Naomi mit Eifer und Liebe,
"Dein Volk wird mein Volk sein," sagte sie,
"Dein Gott mein Gott," ihre Seele frei.

[Verse 2]
Auf den Feldern von Boas sammelte sie Ähren,
Ein Löser-Verwandter fand sie, zum Ehren,
Er nahm sie zur Frau mit Zärtlichkeit,
Bedeckte ihr Leben mit Süßigkeit.

[Chorus]
Ruth und Boas, Geschichte der Erlösung,
Der nahe Verwandte, unsere Rettung und Lösung,
Christus ist unser Boas heute,
Er erlöst uns, unsere Beute!

[Bridge]
Von Ruth wurde Obed geboren, Isais Vater,
Von Isai wurde David der König, so rather,
Die Linie des Messias ging weiter,
Von einer Moabiterin, die Gott folgte, heiter.

[Outro]
Erlöst durch Liebe... in der Linie des Königs...
