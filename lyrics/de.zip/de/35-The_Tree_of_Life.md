SONG 35: "The Tree of Life"

Lied 18: Der Baum des Lebens

[Intro]

[Verse 1]
Abel lag tot auf dem Feld,
Sein Blut schrie, sein Leben gefällt,
Der erste Mord, Bruder gegen Bruder,
Kain stand allein unter der Sonne, oh wunder.

[Verse 2]
"Wo ist dein Bruder?" Gott verlangte,
"Sein Blut schreit von der Erde, wo es tanzte,
Verflucht wirst du sein, wandernd ohne Rast,
Gottes Gericht auf deinem Haupt, so fast."

[Chorus]
Das Blut Abels schreit vom Boden,
Ein Ruf nach Gerechtigkeit, ein ernster Boten,
Aber ein besseres Blut würde eines Tages sprechen,
Das Blut Jesu, Erlösung zu versprechen!

[Bridge]
Von Abel zu Christus läuft die Linie,
Blut vergossen bis alles getan in Routine,
Aber Christi Blut schreit Vergebung,
Nicht Rache, sondern Leben ohne Bebung.

[Outro]
Das Blut schreit... aber Gnade antwortet...
