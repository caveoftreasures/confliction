SONG 96: "The Valley of Death (Alt)"

Lied 48: Das Tal des Todes

[Intro]

[Verse 1]
Goliath der Riese forderte heraus,
Vierzig Tage zitterte Israel im Haus,
Neun Ellen groß, Rüstung glänzend,
Aber ein junger Hirte trat vor, wissend.

[Verse 2]
"Du kommst mit Schwert und Speer,
Aber ich komme mit einer anderen Wehr,
Im Namen des Herrn der Heerscharen,
Heute werden alle von Gott erfahren."

[Chorus]
Goliath fiel durch einen Stein allein,
Nicht durch das Schwert, sondern durch Glauben fein,
Die Schlacht gehört dem Herrn,
Er kämpft für uns, so gern!

[Bridge]
Die Riesen von heute fallen gleich,
Wenn wir im Glauben kämpfen, so reich,
Nicht durch unsere Stärke oder Macht,
Sondern durch den Geist, wir überwinden die Nacht.

[Outro]
Der Riese fiel... Gott kämpfte...
