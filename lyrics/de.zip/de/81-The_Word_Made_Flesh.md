SONG 81: "The Word Made Flesh"

Lied 41: Das Wort Ward Fleisch

[Intro]

[Verse 1]
Gott befahl, eine Stiftshütte zu bauen,
Einen heiligen Ort, darauf zu schauen,
Damit Er unter Seinem Volk wohne,
Seine Herrlichkeit füllte den Thron ohne Hohn.

[Verse 2]
Vorhänge aus feinem Leinen und Blau,
Purpur und Scharlach, Licht und Tau,
Die Bundeslade im Allerheiligsten,
Wo Gott wohnte, am heiligsten.

[Chorus]
Die Stiftshütte, Gottes Wohnung,
Ein Vorgeschmack auf Emmanuel ohne Betonung,
Gott will bei uns sein,
In unseren Herzen will Er wohnen, fein!

[Bridge]
Jedes Detail wies auf Christus hin,
Der Vorhang, der Altar, alles im Sinn,
Der Weg zum Vater jetzt offen ist,
Durch das Blut Jesu, gewiss.

[Outro]
Die Wohnung Gottes... unter uns...
