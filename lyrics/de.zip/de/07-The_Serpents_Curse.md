SONG 7: "The Serpents Curse"

Lied 04: Der Fluch der Schlange

[Intro]

[Verse 1]
Die Schlange war die Schönste von allen,
Erhöht unter den Tieren, stolz in den Hallen,
Aber als Satan ihre Form wählte,
Gottes Fluch wie ein Sturm erzählte.

[Verse 2]
Vom aufrechten Gang zum Kriechen im Staub,
Von Schönheit zu Hässlichkeit, des Bösen Raub,
Verflucht, den Staub der Erde zu essen,
Die niedrigste Kreatur, nie zu vergessen.

[Chorus]
Die verfluchte Schlange, zum Kriechen verdammt,
Für die Lüge, die die Menschheit verbannt,
Rote Augen wie Blut, voller Hass,
Eine Erinnerung an Satans Spaß.

[Bridge]
Der Kopf der Schlange wird zertreten,
Eines Tages wird der Sieg vertreten,
Der Same der Frau wird treten,
Den Feind unter seinen Füßen kneten.

[Outro]
Verflucht aber nicht für immer... Erlösung kommt...
