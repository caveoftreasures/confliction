SONG 5: "The First Darkness"

Lied 03: Die Erste Finsternis

[Intro]

[Verse 1]
Als die Nacht zum ersten Mal fiel,
Adam und Eva zitterten viel,
Nie hatten sie Dunkelheit gekannt,
Nur ewiges Licht, Hand in Hand.

[Verse 2]
"Warum, Herr, plagst du uns so?"
Schrien sie in der schwarzen Nacht froh,
Dachten, Gott hätte sie verlassen,
Verloren in Schatten, nicht zu fassen.

[Chorus]
Die erste Dunkelheit fiel auf ihre Seelen,
Aber Gott versprach, das Licht zu wählen,
Zwölf Stunden Nacht, dann würde die Dämmerung scheinen,
Die Dunkelheit dauert nicht ewig, glaubt und vereint.

[Bridge]
Tag und Nacht, Nacht und Tag,
Der Zyklus dreht sich, was auch immer man sag,
Eine Zeit zu arbeiten, eine Zeit zu ruhen,
Gott weiß was am besten ist zu tun.

[Outro]
Warten auf die Dämmerung... das Licht kommt...
