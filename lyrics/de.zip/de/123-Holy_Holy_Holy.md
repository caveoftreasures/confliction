SONG 123: "Holy Holy Holy"

Lied 62: Heilig Heilig Heilig

[Intro]

[Verse 1]
In Bethlehem von Judäa wurde der König geboren,
Die Prophezeiung und das Gesetz erfüllend, erkoren,
Nicht in einem Palast, sondern in einem Stall,
Der Retter der Welt, demütig überall.

[Verse 2]
Maria wickelte ihn in Windeln ein,
Legte ihn in eine Krippe, ganz allein,
Hirten kamen, um anzubeten,
Das Kind, das kam, um zu retten.

[Chorus]
Geboren in Bethlehem, das Brot des Lebens,
Im Haus des Brotes, Ankunft des Segens,
Die Engel sangen Gott die Ehre,
Friede auf Erden, guter Wille und Lehre!

[Bridge]
Weise Männer folgten dem Stern,
Gold, Weihrauch und Myrrhe von fern,
Anbetend den neugeborenen König,
Den lang ersehnten Messias, wenigstens.

[Outro]
Geboren in Bethlehem... der Retter kam...
