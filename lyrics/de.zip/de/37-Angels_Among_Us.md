SONG 37: "Angels Among Us"

Lied 19: Engel Unter Uns

[Intro]

[Verse 1]
Kain wurde verflucht, die Erde zu wandern,
Gezeichnet von Gott, ein Leben zu ändern,
Flüchtling und Umherirrender würde er sein,
Von seiner Familie getrennt, nicht frei, allein.

[Verse 2]
Die Erde würde nicht mehr Frucht geben,
Für die Hände, die unschuldiges Blut vergaben,
Zitternd und stöhnend alle seine Tage,
Lebend in Furcht ohne Frage.

[Chorus]
Kains Strafe war streng aber gerecht,
Die Folge der Sünde, die alle treffen recht,
Aber Gott in Seiner Barmherzigkeit gab ein Zeichen,
Um ihn in der Dunkelheit zu erreichen.

[Bridge]
Selbst im Gericht zeigt Gott Gnade,
Barmherzigkeit scheint an jedem Pfade,
Sünde hat einen Preis zu zahlen,
Aber Gott bietet einen anderen Weg zu wählen.

[Outro]
Wandernd... aber nicht vergessen...
