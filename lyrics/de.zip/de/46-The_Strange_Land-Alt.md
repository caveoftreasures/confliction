SONG 46: "The Strange Land (Alt)"

Lied 23: Das Fremde Land

[Intro]

[Verse 1]
Henoch wandelte mit Gott jeden Tag,
Ein Mann des Glaubens in jeder Lag,
Dreihundert Jahre in Gemeinschaft,
Die Geheimnisse der Erlösung in Meisterschaft.

[Verse 2]
Gott zeigte ihm die Himmel droben,
Die Mysterien der Zeit und Liebe gehoben,
Die Engel, die Throne, die göttliche Herrlichkeit,
Visionen der Zukunft, Zeichen für die Zeit.

[Chorus]
Henoch wandelte mit Gott und war nicht mehr,
Denn Gott nahm ihn ans ewige Ufer schwer,
Ohne den Tod zu schmecken, wurde er genommen,
Ein Mann so treu, so willkommen!

[Bridge]
Mit Gott wandeln bedeutet im Licht zu gehen,
Das Richtige in Seinen Augen zu sehen,
Henoch zeigt uns den Weg,
Für Gott zu leben jeden Tag.

[Outro]
Mit Gott wandelnd... zur Ewigkeit...
