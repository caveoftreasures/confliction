SONG 132: "From Beginning to End (Alt)"

Lied 66: Vom Anfang bis zum Ende

[Intro]

[Verse 1]
Von Eden bis Golgatha wird die Geschichte erzählt,
Vom Fall zum Kreuz, die Verheißung, die zählt,
Adam fiel, aber Christus erhob,
Was der Erste verlor, stellte der Zweite her, gelobt.

[Verse 2]
Vom verbotenen Baum zum Baum des Kreuzes,
Von der Dunkelheit der Höhle zum herrlichen Licht des Beweises,
Vom Fluch der Schlange zum endgültigen Sieg,
Christus zertrat ihren Kopf, der Triumph besiegt.

[Chorus]
Vom Anfang bis zum Ende hatte Gott einen Plan,
Sein Volk zu erlösen, von Adam zu Abraham dann,
Von Mose zu David, von Propheten zum König,
Alles weist auf Christus hin, unser Leben, nicht wenig!

[Bridge]
Das verlorene Paradies wird wiederhergestellt,
Der Baum des Lebens geöffnet, Sünde vergeben, erhellt,
Die leuchtende Natur wird zurückkehren,
Wenn Christus kommt und alles wird erneuern.

[Verse 3]
Die Schatzhöhle leuchtet jetzt hell,
Denn Christus ist der Schatz, Licht so schnell,
Was Adam und Eva an jenem Tag verloren,
Gibt Christus reichlich zurück, neu geboren.

[Outro]
Vom Anfang bis zum Ende... Christus ist die Antwort...
Alpha und Omega... der Erste und der Letzte...
