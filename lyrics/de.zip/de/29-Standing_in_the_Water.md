SONG 29: "Standing in the Water"

Lied 15: Im Wasser Stehend

[Intro]

[Verse 1]
In der Mitte des Gartens stand,
Der Baum des Lebens, herrlich und bekannt,
Seine Früchte gaben ewiges Leben,
Aber jetzt war der Weg geschlossen, kein Streben.

[Verse 2]
Ein Cherub mit flammendem Schwert,
Bewachte den Weg, Gottes Wort gehört,
Kein sündiger Mensch konnte sich nähern,
Bis der Retter kam, die Furcht zu verzehren.

[Chorus]
Der Baum des Lebens, eines Tages kehren wir zurück,
Wenn der Retter Gottes Werk vollendet, Stück für Stück,
Aus dem Garten wurden wir vertrieben,
Aber durch Christus ist der Weg beschrieben!

[Bridge]
Das Kreuz wurde unser Baum des Lebens,
Wo Christus unseren Kampf beendete, des Strebens,
Sein Blut öffnete den Weg wieder,
Zum Paradies, wo wir herrschen, immer wieder.

[Outro]
Der Baum des Lebens... wartet auf uns...
