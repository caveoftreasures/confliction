SONG 76: "The Secret of the Cave (Alt)"

Lied 38: Das Geheimnis der Höhle

[Intro]

[Verse 1]
Israel kam ans Rote Meer gefangen,
Pharao verfolgte sie mit Verlangen,
Berge an den Seiten, Meer voraus,
"Brachtest du uns her, um zu sterben?" raus.

[Verse 2]
Mose streckte seinen Stab über das Meer,
Gott teilte die Wasser, so schwer,
Wasserwände links und rechts,
Israel ging auf trockenem Land, gerecht.

[Chorus]
Durchqueren des Roten Meeres auf trockenem Grund,
Gottes Macht, niemand macht sie unkund,
Pharao folgte zu seinem Verderben,
Die Wasser schlossen sich, Ende seines Erben!

[Bridge]
Wenn es keinen Weg gibt, öffnet Gott einen,
Wenn alles scheitert, ist Er der Rechte, der kleine,
Das Meer, das wir fürchten, wird unser Durchgang,
Sieg in Gott, kein Untergang!

[Outro]
Das Meer teilte sich... Israel ging hindurch...
