SONG 18: "The Cherub at the Gate (Alt)"

Lied 09: Der Cherub am Tor

[Intro]

[Verse 1]
Ein Cherub mit flammendem Schwert,
Vom Gartentor als Wächter begehrt,
Adam und Eva fielen, als sie ihn sahen,
Denkend, er würde sie erschlagen.

[Verse 2]
Aber der Engel stieg zum Himmel hoch,
Betend zu Gott: "Was mach ich doch?
Deine Diener liegen wie tot vor Angst,
Was sage ich ihnen, dass du sie bangst?"

[Chorus]
Der Cherub am Tor steht Wacht,
Bewacht den Weg zum Lebensbaum mit Macht,
Eines Tages wird das Schwert zurückgezogen,
Und wir werden eintreten, nicht mehr betrogen!

[Bridge]
Das flammende Schwert dreht und glänzt,
Erinnerung an die Sünde, die begrenzt,
Aber jenseits des Schwertes gibt es Hoffnung,
Ein Rückweg durch göttliche Liebe und Öffnung.

[Outro]
Das Tor bewachend... auf den Tag wartend...
