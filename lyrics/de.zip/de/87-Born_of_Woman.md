SONG 87: "Born of Woman"

Lied 44: Von einer Frau Geboren

[Intro]

[Verse 1]
Jericho war verschlossen und befestigt,
Hohe Mauern, das Volk eingeengt,
Aber Gott hatte einen anderen Plan,
Nicht durch das Schwert, sondern gehorsam dann.

[Verse 2]
Sieben Tage marschierten sie herum,
Sieben Priester mit Posaunen, nicht stumm,
Am siebten Tag sieben Runden sie gaben,
Sie schrien und die Mauern fielen, begraben.

[Chorus]
Die Mauern von Jericho fielen zu Boden,
Nicht durch Kraft, sondern durch Glauben, Gottes Boten,
Die Schlacht gehört dem Herrn,
Sieg durch Gnade, nicht durch Wert, gern!

[Bridge]
Die Mauern, denen wir heute begegnen,
Fallen, wenn wir dem Führer begegnen,
Gehorsam und Glaube an Gott,
Reißen Hindernisse nieder, ohne Spott.

[Outro]
Die Mauern fielen... durch Glauben...
