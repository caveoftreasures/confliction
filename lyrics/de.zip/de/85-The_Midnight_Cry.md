SONG 85: "The Midnight Cry"

Lied 43: Der Mitternachtsruf

[Intro]

[Verse 1]
Vierzig Jahre in der Wüste vergingen,
Die alte Generation ging, die Jungen dringen,
Josua führte das Volk vorwärts,
Den Jordan zu überqueren, mächtig und wärts.

[Verse 2]
Die Priester mit der Lade traten ein,
Die Wasser hielten an, standen wie Stein,
Israel ging auf trockenem Boden,
Ins verheißene Land, zu Ehren Gottes Boden.

[Chorus]
Den Jordan überquerend ins neue Land,
Von der Knechtschaft zur Verheißung, von Gottes Hand,
Gott erfüllt, was Er versprochen hat,
Das Erbe, das Er Abraham zusagt!

[Bridge]
Zwölf Steine aus dem Fluss nahmen sie,
Ein Denkmal der Überquerung, nie zu vergessen sie,
Damit die Generationen wissen,
Dass Gott Wunder tut, nie zu vermissen.

[Outro]
Überquerend zur Verheißung... das Erbe empfangen...
